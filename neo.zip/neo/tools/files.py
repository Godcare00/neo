# tools/files.py — file read / write / append tools
#
# write_file and append_file default to saving inside WORKSPACE when a
# bare filename (no leading / or ./) is given. Absolute paths are used as-is.

import os
from config import c, WORKSPACE


def _resolve_path(path: str) -> str:
    """
    Resolve a file path:
      - Absolute paths are used as-is.
      - Relative paths are anchored to WORKSPACE so agents that write
        bare filenames like 'report.md' land in the right place.
    """
    if os.path.isabs(path):
        return path
    return os.path.join(WORKSPACE, path)


# ── Schemas ───────────────────────────────────────────────────────────────────

READ_FILE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "read_file",
        "description": (
            "Read the contents of a file and return them as a string. "
            "Optionally read only a range of lines. Use for inspecting source code, "
            "configs, logs, data files, or any text file on disk."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute path, or a filename/relative path resolved inside the workspace.",
                },
                "start_line": {
                    "type": "integer",
                    "description": "First line to return, 1-indexed (optional, default: 1).",
                },
                "end_line": {
                    "type": "integer",
                    "description": "Last line to return, inclusive (optional, default: all).",
                },
            },
            "required": ["path"],
        },
    },
}

WRITE_FILE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "write_file",
        "description": (
            "Write content to a file, creating it (and any parent directories) if needed. "
            "Relative paths are saved inside the workspace. "
            "Use absolute paths to write outside the workspace."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path":    {"type": "string", "description": "Destination path. Relative paths land in the workspace."},
                "content": {"type": "string", "description": "Full content to write."},
            },
            "required": ["path", "content"],
        },
    },
}

APPEND_FILE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "append_file",
        "description": (
            "Append content to a file, creating it if needed. "
            "Relative paths are resolved inside the workspace."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path":    {"type": "string", "description": "File path. Relative paths land in the workspace."},
                "content": {"type": "string", "description": "Content to append."},
            },
            "required": ["path", "content"],
        },
    },
}

# ── Executors ─────────────────────────────────────────────────────────────────

def read_file(args: dict) -> str:
    path       = _resolve_path(args.get("path", ""))
    start_line = args.get("start_line", 1)
    end_line   = args.get("end_line", None)
    print(f"  {c('tool', 'read_file')}: {c('dim', path)}")
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        s        = max(1, start_line) - 1
        e        = end_line if end_line is not None else len(lines)
        selected = lines[s:e]
        result   = "".join(selected)
        preview  = "".join(f"    {l}" for l in selected[:20])
        if len(selected) > 20:
            preview += f"\n    {c('dim', f'... ({len(selected) - 20} more lines)')}"
        print(c("out", preview.rstrip()) + "\n")
        return result
    except FileNotFoundError:
        msg = f"File not found: {path}"
        print(c("red", f"    {msg}\n"))
        return msg
    except Exception as e:
        msg = f"Error reading {path}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def write_file(args: dict) -> str:
    path    = _resolve_path(args.get("path", ""))
    content = args.get("content", "")
    print(f"  {c('tool', 'write_file')}: {c('dim', path)}")
    try:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        size = os.path.getsize(path)
        msg  = f"Written {size} bytes to {path}"
        print(c("out", f"    {msg}") + "\n")
        return msg
    except Exception as e:
        msg = f"Error writing {path}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def append_file(args: dict) -> str:
    path    = _resolve_path(args.get("path", ""))
    content = args.get("content", "")
    print(f"  {c('tool', 'append_file')}: {c('dim', path)}")
    try:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(content)
        size = os.path.getsize(path)
        msg  = f"Appended to {path} (total size: {size} bytes)"
        print(c("out", f"    {msg}") + "\n")
        return msg
    except Exception as e:
        msg = f"Error appending to {path}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg
