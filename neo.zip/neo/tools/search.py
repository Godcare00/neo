# tools/search.py — web search via SerpAPI

import json
import urllib.request
import urllib.parse
from config import c, SERPAPI_KEY

SCHEMA = {
    "type": "function",
    "function": {
        "name": "web_search",
        "description": (
            "Search the web using SerpAPI and return the top results. "
            "Use for current information, news, documentation lookups, research, "
            "or anything that requires up-to-date knowledge beyond your training. "
            "Returns titles, URLs, and snippets for each result."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query.",
                },
                "num_results": {
                    "type": "integer",
                    "description": "Number of results to return (default: 5, max: 10).",
                    "default": 5,
                },
            },
            "required": ["query"],
        },
    },
}


def execute(args: dict) -> str:
    query       = args.get("query", "").strip()
    num_results = min(int(args.get("num_results", 5)), 10)

    print(f"  {c('tool', 'web_search')}: {c('dim', query)}")

    if not SERPAPI_KEY:
        msg = "SERPAPI_KEY is not set. Add it to your .env file."
        print(c("red", f"    {msg}\n"))
        return msg

    if not query:
        return "No query provided."

    try:
        params = urllib.parse.urlencode({
            "q":       query,
            "api_key": SERPAPI_KEY,
            "num":     num_results,
            "engine":  "google",
        })
        url = f"https://serpapi.com/search?{params}"
        req = urllib.request.Request(url, headers={"User-Agent": "neo-agent/1.0"})

        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        results     = data.get("organic_results", [])
        answer_box  = data.get("answer_box", {})
        knowledge   = data.get("knowledge_graph", {})

        lines = []
        if answer_box.get("answer"):
            lines.append(f"Answer: {answer_box['answer']}\n")
        elif knowledge.get("description"):
            lines.append(f"Overview: {knowledge['description']}\n")

        for i, r in enumerate(results[:num_results], 1):
            title   = r.get("title", "(no title)")
            link    = r.get("link", "")
            snippet = r.get("snippet", "")
            lines.append(f"{i}. {title}")
            if link:
                lines.append(f"   {link}")
            if snippet:
                lines.append(f"   {snippet}")
            lines.append("")

        result = "\n".join(lines).strip() or "No results found."

        preview_lines = result.splitlines()
        preview = "\n".join(f"    {l}" for l in preview_lines[:12])
        if len(preview_lines) > 12:
            preview += f"\n    {c('dim', f'... ({len(preview_lines)-12} more lines)')}"
        print(c("out", preview) + "\n")
        return result

    except Exception as e:
        msg = f"Search error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg
