# archive.py — Archive singleton
#
# Maintains a live JSON record of Neo's entire infrastructure:
#   - agents:       name, description, file path, system prompt, last modified
#   - tools:        static tools (WORKER_TOOLS) and dynamic registry tools
#   - source_files: all .py files with checksums (detects self-modifications)
#   - history:      timestamped log of all mutations (tool created, file changed, etc.)
#
# Persisted to archive.json next to this file.
# Called by the Archivist agent and by Neo's self-modification workflow.

import os
import json
import hashlib
import datetime

ARCHIVE_FILE = os.path.join(os.path.dirname(__file__), "archive.json")
PROJECT_ROOT = os.path.dirname(__file__)


def _now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def _checksum(path: str) -> str:
    try:
        with open(path, "rb") as f:
            return hashlib.md5(f.read()).hexdigest()
    except Exception:
        return "unreadable"


def _collect_source_files(root: str) -> dict:
    """Walk the project and record all .py files with their checksums."""
    files = {}
    for dirpath, dirnames, filenames in os.walk(root):
        # Skip caches and hidden dirs
        dirnames[:] = [d for d in dirnames if not d.startswith((".", "__pycache__"))]
        for fn in sorted(filenames):
            if fn.endswith(".py"):
                full = os.path.join(dirpath, fn)
                rel  = os.path.relpath(full, root)
                files[rel] = {
                    "checksum": _checksum(full),
                    "size":     os.path.getsize(full),
                    "modified": datetime.datetime.fromtimestamp(
                        os.path.getmtime(full)
                    ).isoformat(timespec="seconds"),
                }
    return files


class Archive:
    """
    The living record of Neo's infrastructure.
    All methods return plain strings suitable for tool output.
    """

    def __init__(self):
        self._data = self._empty()
        self._load()

    def _empty(self) -> dict:
        return {
            "meta":         {"created": _now(), "last_updated": _now(), "version": 1},
            "agents":       {},
            "tools":        {"static": [], "dynamic": []},
            "source_files": {},
            "history":      [],
        }

    # ── Persistence ───────────────────────────────────────────────────────────

    def _load(self):
        if os.path.exists(ARCHIVE_FILE):
            try:
                with open(ARCHIVE_FILE) as f:
                    self._data = json.load(f)
            except Exception:
                self._data = self._empty()

    def _save(self):
        self._data["meta"]["last_updated"] = _now()
        with open(ARCHIVE_FILE, "w") as f:
            json.dump(self._data, f, indent=2)

    def _log(self, event: str, detail: str = ""):
        self._data["history"].append({
            "timestamp": _now(),
            "event":     event,
            "detail":    detail,
        })
        # Keep last 500 events
        self._data["history"] = self._data["history"][-500:]

    # ── Snapshot ──────────────────────────────────────────────────────────────

    def snapshot(self, agents: dict, static_tool_names: list) -> str:
        """
        Full infrastructure snapshot. Call on startup and after modifications.
        agents: the live team dict {name: Agent}
        static_tool_names: list of built-in tool names
        """
        from tool_registry import registry

        # Agents
        agent_records = {}
        for name, agent in agents.items():
            # Find source file
            import inspect
            try:
                src_file = os.path.relpath(inspect.getfile(type(agent)), PROJECT_ROOT)
            except Exception:
                src_file = "unknown"

            try:
                prompt_preview = agent.system_prompt[:300]
            except Exception:
                prompt_preview = "(unavailable)"

            agent_records[name] = {
                "description":     agent.description,
                "source_file":     src_file,
                "color":           getattr(agent, "color", "dim"),
                "prompt_preview":  prompt_preview,
                "snapshotted_at":  _now(),
            }

        self._data["agents"] = agent_records

        # Tools
        self._data["tools"] = {
            "static":  static_tool_names,
            "dynamic": [
                {"name": n, "description": t["description"], "code": t["code"]}
                for n, t in registry._tools.items()
            ],
        }

        # Source files
        self._data["source_files"] = _collect_source_files(PROJECT_ROOT)

        self._log("snapshot", f"{len(agents)} agents, {len(static_tool_names)} static tools, "
                               f"{len(registry._tools)} dynamic tools")
        self._save()
        return f"Snapshot complete: {len(agents)} agents, {len(registry._tools)} dynamic tools, " \
               f"{len(self._data['source_files'])} source files indexed."

    # ── Queries ───────────────────────────────────────────────────────────────

    def status(self) -> str:
        """High-level summary of current infrastructure."""
        d = self._data
        agents  = list(d["agents"].keys())
        static  = d["tools"].get("static", [])
        dynamic = d["tools"].get("dynamic", [])
        files   = d["source_files"]
        last    = d["meta"].get("last_updated", "never")

        lines = [
            f"Last updated:   {last}",
            f"Agents ({len(agents)}):  {', '.join(agents) or 'none'}",
            f"Static tools:   {len(static)}",
            f"Dynamic tools:  {len(dynamic)} — {', '.join(t['name'] for t in dynamic) or 'none'}",
            f"Source files:   {len(files)}",
            f"History events: {len(d['history'])}",
        ]
        return "\n".join(lines)

    def get_agent(self, name: str) -> str:
        agents = self._data["agents"]
        if name not in agents:
            return f"Agent '{name}' not in archive. Known: {', '.join(agents)}"
        a = agents[name]
        lines = [f"Agent: {name}"]
        for k, v in a.items():
            lines.append(f"  {k}: {v}")
        return "\n".join(lines)

    def get_source_file(self, path: str) -> str:
        files = self._data["source_files"]
        # Allow partial match
        matches = [k for k in files if path in k]
        if not matches:
            return f"No source file matching '{path}'. Known: {', '.join(sorted(files))}"
        results = []
        for m in matches:
            f = files[m]
            results.append(f"{m}: checksum={f['checksum']}, size={f['size']}B, modified={f['modified']}")
        return "\n".join(results)

    def diff_source_files(self) -> str:
        """Compare archived checksums against current disk state. Returns changed files."""
        archived = self._data["source_files"]
        current  = _collect_source_files(PROJECT_ROOT)
        changed, added, removed = [], [], []

        for path, info in current.items():
            if path not in archived:
                added.append(path)
            elif info["checksum"] != archived[path]["checksum"]:
                changed.append(path)
        for path in archived:
            if path not in current:
                removed.append(path)

        if not (changed or added or removed):
            return "No source file changes detected since last snapshot."

        lines = []
        if changed: lines += [f"MODIFIED: {p}" for p in changed]
        if added:   lines += [f"ADDED:    {p}" for p in added]
        if removed: lines += [f"REMOVED:  {p}" for p in removed]
        return "\n".join(lines)

    def get_history(self, last_n: int = 20) -> str:
        history = self._data["history"][-last_n:]
        if not history:
            return "No history recorded yet."
        lines = [f"[{e['timestamp']}] {e['event']}: {e['detail']}" for e in reversed(history)]
        return "\n".join(lines)

    def get_dynamic_tools(self) -> str:
        tools = self._data["tools"].get("dynamic", [])
        if not tools:
            return "No dynamic tools registered."
        lines = [f"- {t['name']}: {t['description']}" for t in tools]
        return "\n".join(lines)

    def full_dump(self) -> str:
        """Return the full archive as pretty JSON."""
        return json.dumps(self._data, indent=2)

    # ── Mutation logging (called externally after changes) ────────────────────

    def log_tool_created(self, name: str, description: str):
        self._log("tool_created", f"{name}: {description}")
        self._save()

    def log_tool_upgraded(self, name: str):
        self._log("tool_upgraded", name)
        self._save()

    def log_file_modified(self, path: str, reason: str = ""):
        self._log("file_modified", f"{path} — {reason}")
        # Re-index just this file
        abs_path = os.path.join(PROJECT_ROOT, path)
        if os.path.exists(abs_path):
            self._data["source_files"][path] = {
                "checksum": _checksum(abs_path),
                "size":     os.path.getsize(abs_path),
                "modified": _now(),
            }
        self._save()

    def log_agent_added(self, name: str, description: str, file_path: str):
        self._log("agent_added", f"{name} ({file_path}): {description}")
        self._save()

    def log_custom(self, event: str, detail: str = ""):
        self._log(event, detail)
        self._save()


# Singleton
archive = Archive()
