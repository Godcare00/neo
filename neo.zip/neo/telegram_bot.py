#!/usr/bin/env python3
# telegram_bot.py — Telegram entry point for Neo
#
# Usage:   python telegram_bot.py
# Requires: pip install python-telegram-bot
#
# .env keys:
#   TELEGRAM_BOT_TOKEN   — from @BotFather
#   TELEGRAM_ALLOWED_IDS — comma-separated Telegram user IDs

import os
import sys
import asyncio
import logging
import re
import urllib.error

sys.path.insert(0, os.path.dirname(__file__))

from config import WORKSPACE

UPLOADS_DIR = os.path.join(WORKSPACE, "uploads")

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("neo.telegram")

# ── Auth ──────────────────────────────────────────────────────────────────────

def _load_allowed_ids() -> set[int]:
    raw = os.environ.get("TELEGRAM_ALLOWED_IDS", "").strip()
    ids = set()
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            ids.add(int(part))
    return ids

# ── File path detection ───────────────────────────────────────────────────────

# Matches absolute and workspace-relative paths appearing after any common
# delimiter (space, colon, backtick, quote, bracket, paren, line start).
# Post-strips trailing punctuation so paths like "/file.py." resolve cleanly.
_PATH_RE = re.compile(
    r"""(?:^|[\s:('",\[`])(/[\w./\-]+|workspace/[\w./\-]+)""",
    re.MULTILINE,
)

def _extract_sendable_files(text: str) -> list[str]:
    """
    Find all file paths in text that exist on disk and are under 50 MB.
    Resolves workspace-relative paths. Deduplicates. Safe to call on any reply.
    """
    found = []
    for m in _PATH_RE.finditer(text):
        candidate = m.group(1).rstrip('.,;:)')  # strip trailing punctuation
        if not candidate:
            continue
        if not candidate.startswith("/"):
            candidate = os.path.join(os.path.dirname(__file__), candidate)
        candidate = os.path.abspath(candidate)
        if (os.path.isfile(candidate)
                and os.path.getsize(candidate) < 50 * 1024 * 1024
                and candidate not in found):
            found.append(candidate)
    return found

# ── Message splitting ─────────────────────────────────────────────────────────

TELEGRAM_LIMIT = 4096

def _split_message(text: str) -> list[str]:
    if len(text) <= TELEGRAM_LIMIT:
        return [text]
    chunks = []
    while text:
        if len(text) <= TELEGRAM_LIMIT:
            chunks.append(text)
            break
        split_at = text.rfind("\n", 0, TELEGRAM_LIMIT)
        if split_at == -1:
            split_at = TELEGRAM_LIMIT
        chunks.append(text[:split_at])
        text = text[split_at:].lstrip("\n")
    return chunks

# ── Bot ───────────────────────────────────────────────────────────────────────

class NeoBot:
    def __init__(self):
        from main import build_team, init_workspace, initial_snapshot, init_task_pool

        api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
        if not api_key:
            log.error("OPENROUTER_API_KEY not set.")
            sys.exit(1)

        self.token       = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
        self.allowed_ids = _load_allowed_ids()

        if not self.token:
            log.error("TELEGRAM_BOT_TOKEN not set.")
            sys.exit(1)
        if not self.allowed_ids:
            log.warning("TELEGRAM_ALLOWED_IDS not set — no one can message Neo!")

        log.info(f"Authorized users: {self.allowed_ids}")

        init_workspace()
        os.makedirs(UPLOADS_DIR, exist_ok=True)

        self.neo = build_team(api_key)
        initial_snapshot(self.neo)

        # Task pool: notify all authorized users when a background task finishes
        self._app = None   # set in run() after ApplicationBuilder
        self._loop = None  # set in run()

        def on_task_done(task):
            """Push task completion to all authorized Telegram users."""
            if not self._app or not self._loop:
                return
            icon   = "✅" if task.status.value == "done" else "❌"
            status = task.status.value.upper()
            text   = (
                f"{icon} *Task {task.id}* — {status}\n"
                f"Agent: {task.assigned_agent}\n"
                f"Task: {task.description[:120]}\n\n"
                f"Use /task\\_result {task.id} to see the full output."
            )
            async def _push():
                for uid in self.allowed_ids:
                    try:
                        await self._app.bot.send_message(
                            chat_id=uid, text=text, parse_mode="Markdown"
                        )
                    except Exception as e:
                        log.warning(f"Could not notify {uid}: {e}")
            asyncio.run_coroutine_threadsafe(_push(), self._loop)

        init_task_pool(self.neo, notify_fn=on_task_done, api_key=api_key)

        # Per-user conversation histories and sent-file dedup sets
        self._histories:  dict[int, list[dict]] = {}
        self._sent_files: dict[int, set]         = {}  # prevents re-sending same file

    # ── Conversation state ────────────────────────────────────────────────────

    def _get_history(self, user_id: int) -> list[dict]:
        if user_id not in self._histories:
            self._histories[user_id] = [
                {"role": "system", "content": self.neo.system_prompt}
            ]
        return self._histories[user_id]

    def _reset_history(self, user_id: int):
        self._histories[user_id]  = [
            {"role": "system", "content": self.neo.system_prompt}
        ]
        self._sent_files[user_id] = set()  # clear dedup on reset

    def _rollback(self, user_id: int):
        history = self._get_history(user_id)
        while history and history[-1].get("role") != "user":
            history.pop()
        if history:
            history.pop()

    async def _neo_reply(self, user_id: int, user_content: str) -> str:
        history = self._get_history(user_id)
        history.append({"role": "user", "content": user_content})
        loop = asyncio.get_event_loop()
        try:
            reply = await loop.run_in_executor(None, self.neo.chat, history)
            history.append({"role": "assistant", "content": reply})
            return reply
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            self._rollback(user_id)
            return f"API error {e.code}: {body}"
        except Exception as e:
            self._rollback(user_id)
            return f"Error: {e}"

    async def _send_reply(self, update, context, reply: str,
                          already_sent: set = None):
        """
        Send text chunks, then auto-detect and send any files Neo produced.
        already_sent: optional set of abs paths already sent this session,
                      prevents sending the same file twice across turns.
        """
        chat_id = update.effective_chat.id

        for chunk in _split_message(reply):
            await update.message.reply_text(chunk)

        files = _extract_sendable_files(reply)
        if not files:
            return

        for fpath in files:
            if already_sent is not None:
                if fpath in already_sent:
                    log.info(f"Skipping already-sent file: {fpath}")
                    continue
                already_sent.add(fpath)
            try:
                # Read file bytes off the event loop to avoid blocking
                file_bytes = await asyncio.get_event_loop().run_in_executor(
                    None, lambda p=fpath: open(p, "rb").read()
                )
                await context.bot.send_document(
                    chat_id=chat_id,
                    document=file_bytes,
                    filename=os.path.basename(fpath),
                    caption=f"📎 {os.path.basename(fpath)}",
                )
                log.info(f"Sent file: {fpath}")
            except Exception as e:
                log.warning(f"Could not send file {fpath}: {e}")

    # ── Handlers ──────────────────────────────────────────────────────────────

    async def on_message(self, update, context):
        from telegram.constants import ChatAction
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        text = (update.message.text or "").strip()
        if not text:
            return
        log.info(f"[{user.id}] {text[:80]}")
        await context.bot.send_chat_action(chat_id=update.effective_chat.id, action=ChatAction.TYPING)
        reply = await self._neo_reply(user.id, text)
        sent = self._sent_files.setdefault(user.id, set())
        await self._send_reply(update, context, reply, already_sent=sent)

    async def on_attachment(self, update, context):
        from telegram.constants import ChatAction
        user = update.effective_user
        msg  = update.message
        if user.id not in self.allowed_ids:
            await msg.reply_text("Unauthorized.")
            return
        await context.bot.send_chat_action(chat_id=update.effective_chat.id, action=ChatAction.TYPING)

        tg_file = None
        label   = "file"
        caption = (msg.caption or "").strip()

        if msg.document:
            tg_file = await msg.document.get_file()
            label   = msg.document.file_name or "document"
        elif msg.photo:
            tg_file = await msg.photo[-1].get_file()
            label   = "photo.jpg"
        elif msg.audio:
            tg_file = await msg.audio.get_file()
            label   = msg.audio.file_name or "audio"
        elif msg.video:
            tg_file = await msg.video.get_file()
            label   = msg.video.file_name or "video"
        elif msg.voice:
            tg_file = await msg.voice.get_file()
            label   = "voice.ogg"
        else:
            await msg.reply_text("Unsupported attachment type.")
            return

        user_upload_dir = os.path.join(UPLOADS_DIR, str(user.id))
        os.makedirs(user_upload_dir, exist_ok=True)
        dest = os.path.join(user_upload_dir, label)
        if os.path.exists(dest):
            base, ext = os.path.splitext(label)
            i = 1
            while os.path.exists(dest):
                dest = os.path.join(user_upload_dir, f"{base}_{i}{ext}")
                i += 1

        await tg_file.download_to_drive(dest)
        log.info(f"[{user.id}] saved attachment -> {dest}")

        user_content = (
            f"I just sent you a file saved at: {dest}\n"
            + (f"Caption: {caption}" if caption else "Please process or acknowledge it.")
        )
        reply = await self._neo_reply(user.id, user_content)
        sent = self._sent_files.setdefault(user.id, set())
        await self._send_reply(update, context, reply, already_sent=sent)

    async def on_start(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        await update.message.reply_text(
            "Neo online.\n\n"
            "/reset  — clear conversation history\n"
            "/status — system + task pool status\n"
            "/tasks  — list recent tasks\n"
        )

    async def on_reset(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        self._reset_history(user.id)
        await update.message.reply_text("Conversation reset.")

    async def on_status(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        from archive import archive
        from task_pool import task_pool
        arch   = archive.status()
        pool   = task_pool.status_summary()
        busy   = ", ".join(sorted(task_pool._busy)) or "none"
        turns  = len(self._get_history(user.id))
        text   = f"*Neo Status*\n```\n{arch}\n\nTask pool: {pool}\nBusy agents: {busy}\nConversation turns: {turns}\n```"
        await update.message.reply_text(text, parse_mode="Markdown")

    async def on_tasks(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        from task_pool import task_pool
        tasks = task_pool.list_tasks(last_n=10)
        if not tasks:
            await update.message.reply_text("No tasks yet.")
            return
        lines = []
        for t in tasks:
            icon = {"pending":"⏳","running":"⚙️","done":"✅","failed":"❌","cancelled":"⊘"}.get(t.status.value,"?")
            lines.append(f"{icon} `{t.id}` {t.status.value} — {t.description[:60]}")
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    # ── Run ───────────────────────────────────────────────────────────────────

    def run(self):
        try:
            from telegram.ext import (
                ApplicationBuilder, CommandHandler, MessageHandler, filters,
            )
        except ImportError:
            log.error("python-telegram-bot not installed. Run: pip install python-telegram-bot")
            sys.exit(1)

        self._app  = ApplicationBuilder().token(self.token).build()
        self._loop = asyncio.get_event_loop()

        self._app.add_handler(CommandHandler("start",  self.on_start))
        self._app.add_handler(CommandHandler("reset",  self.on_reset))
        self._app.add_handler(CommandHandler("status", self.on_status))
        self._app.add_handler(CommandHandler("tasks",  self.on_tasks))
        self._app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.on_message))
        self._app.add_handler(MessageHandler(
            filters.Document.ALL | filters.PHOTO | filters.AUDIO | filters.VIDEO | filters.VOICE,
            self.on_attachment,
        ))

        log.info("Neo Telegram bot starting (long-polling)...")
        self._app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    NeoBot().run()
