# tools.py — tool definitions (schemas) and their executors

import subprocess
from config import c

# ── Shell tool ────────────────────────────────────────────────────────────────

SHELL_TOOL = {
    "type": "function",
    "function": {
        "name": "shell",
        "description": (
            "Execute a shell command on the user's machine and return stdout + stderr. "
            "Use for file operations, running scripts, checking system state, "
            "installing packages, or anything that benefits from real command execution."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to run (via /bin/sh).",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Max seconds to wait (default 30).",
                    "default": 30,
                },
            },
            "required": ["command"],
        },
    },
}


def run_shell(command: str, timeout: int = 30) -> str:
    print(f"  {c('tool', '⚙ shell')}: {c('dim', command)}")
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        output = ((result.stdout or "") + (result.stderr or "")).strip() or "(no output)"

        lines   = output.splitlines()
        preview = "\n".join(f"    {l}" for l in lines[:20])
        if len(lines) > 20:
            preview += f"\n    {c('dim', f'… ({len(lines) - 20} more lines)')}"
        print(c("out", preview) + "\n")

        return output
    except subprocess.TimeoutExpired:
        msg = f"Command timed out after {timeout}s"
        print(c("red", f"    {msg}\n"))
        return msg
    except Exception as e:
        msg = f"Error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


# ── Delegate-to-agent tool (injected by Neo at runtime) ───────────────────────

def make_delegate_tool(agents: dict) -> dict:
    """
    Builds the 'delegate' tool schema from the currently registered agents.
    agents: { name: Agent }
    """
    agent_descriptions = "\n".join(
        f"- {name}: {ag.description}" for name, ag in agents.items()
    )
    return {
        "type": "function",
        "function": {
            "name": "delegate",
            "description": (
                "Assign a task to one of your specialist sub-agents and get back their response.\n"
                f"Available agents:\n{agent_descriptions}"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "agent": {
                        "type": "string",
                        "enum": list(agents.keys()),
                        "description": "The name of the agent to delegate to.",
                    },
                    "task": {
                        "type": "string",
                        "description": "The full task or question to hand off.",
                    },
                },
                "required": ["agent", "task"],
            },
        },
    }


# ── Executor registry ─────────────────────────────────────────────────────────

def execute_tool(name: str, args: dict, agents: dict) -> str:
    if name == "shell":
        return run_shell(args.get("command", ""), args.get("timeout", 30))

    if name == "delegate":
        agent_name = args.get("agent", "")
        task       = args.get("task", "")
        agent      = agents.get(agent_name)
        if not agent:
            return f"Unknown agent: {agent_name}"
        print(f"  {c('tool', '↪ delegate')} → {c(agent_name.lower(), agent_name)}: {c('dim', task)}\n")
        return agent.run(task)

    return f"Unknown tool: {name}"
