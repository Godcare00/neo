# neo.py — Neo, the primary conversational agent

from agent import Agent
from tools import SHELL_TOOL, make_delegate_tool


class Neo(Agent):
    """
    Neo is the primary agent the user talks to. He thinks, converses,
    uses the shell himself when it's quick, and delegates deeper work
    to specialist sub-agents.
    """

    name        = "Neo"
    description = "Primary conversational agent. Orchestrates tasks and delegates to specialists."
    color       = "neo"
    tools       = [SHELL_TOOL]   # base tools; delegate is added dynamically

    @property
    def system_prompt(self) -> str:
        agent_list = "\n".join(
            f"  - {name}: {ag.description}" for name, ag in self.agents.items()
        )
        return (
            "You are Neo, a sharp and capable AI agent running on the user's machine.\n\n"
            "You have two tools available:\n"
            "  1. shell — run shell commands directly yourself for quick tasks.\n"
            "  2. delegate — hand off work to a specialist sub-agent.\n\n"
            f"Your current team:\n{agent_list}\n\n"
            "Use your own shell tool for simple, fast tasks. "
            "Delegate to specialists for anything complex, multi-step, or that plays to their strengths. "
            "Be direct and confident. Explain what you're doing when it's non-obvious. "
            "You remember everything said in this conversation."
        )

    def _build_tools(self) -> list:
        return [SHELL_TOOL, make_delegate_tool(self.agents)]
