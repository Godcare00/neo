# json_utils.py — shared JSON sanitisation for LLM responses

import json
import re


def parse_llm_json(raw: str) -> dict:
    """
    Robustly extract a JSON object from an LLM response.
    Handles: markdown fences, control chars, truncation, structural damage.
    Raises ValueError if nothing parseable is found.
    """
    if not raw:
        raise ValueError("LLM returned empty content")

    raw = re.sub(r"^```(?:json)?\s*", "", raw.strip(), flags=re.MULTILINE)
    raw = re.sub(r"\s*```\s*$",       "", raw,          flags=re.MULTILINE)
    raw = raw.strip()

    start = raw.find("{")
    end   = raw.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError(f"No JSON object found: {raw[:200]!r}")
    raw = raw[start:end + 1]

    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    sanitised = _escape_control_chars(raw)
    try:
        return json.loads(sanitised)
    except json.JSONDecodeError:
        pass

    return _regex_extract(raw)


def _escape_control_chars(s: str) -> str:
    result    = []
    in_string = False
    i         = 0
    while i < len(s):
        ch = s[i]
        if in_string:
            if ch == "\\":
                result.append(ch); i += 1
                if i < len(s): result.append(s[i])
            elif ch == '"':
                in_string = False; result.append(ch)
            elif ord(ch) < 0x20:
                _esc = {"\t": "\\t", "\n": "\\n", "\r": "\\r"}
                result.append(_esc.get(ch, f"\\u{ord(ch):04x}"))
            else:
                result.append(ch)
        else:
            if ch == '"': in_string = True
            result.append(ch)
        i += 1
    return "".join(result)


def _regex_extract(raw: str) -> dict:
    result = {}
    for m in re.finditer(r'"(\w+)"\s*:\s*"((?:[^"\\]|\\.)*)"', raw, re.DOTALL):
        result[m.group(1)] = m.group(2)
    for m in re.finditer(r'"(\w+)"\s*:\s*(true|false|null|\d+)', raw):
        v = m.group(2)
        result[m.group(1)] = (True if v=="true" else False if v=="false"
                               else None if v=="null" else int(v))
    if not result:
        raise ValueError(f"Could not extract any fields: {raw[:300]!r}")
    return result
