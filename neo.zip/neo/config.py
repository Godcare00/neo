# config.py — configuration loader and shared constants

import os

def _load_env(path: str):
    if not os.path.exists(path):
        return
    with open(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = val

_load_env(os.path.join(os.path.dirname(__file__), ".env"))

API_URL     = "https://openrouter.ai/api/v1/chat/completions"
MODEL       = os.environ.get("NEO_MODEL", "arcee-ai/trinity-large-preview:free")
SERPAPI_KEY = os.environ.get("SERPAPI_KEY", "")
STREAMING   = os.environ.get("NEO_STREAMING", "true").lower() not in ("false", "0", "no")

WORKSPACE = os.path.abspath(
    os.environ.get(
        "NEO_WORKSPACE",
        os.path.join(os.path.dirname(__file__), "workspace"),
    )
)

COLORS = {
    "neo":       "\033[96m",   # Bright Cyan    — Neo
    "morpheus":  "\033[95m",   # Bright Magenta — Morpheus
    "alpha":     "\033[94m",   # Bright Blue    — Alpha
    "beta":      "\033[33m",   # Yellow         — Beta   (was duplicate cyan)
    "cipher":    "\033[92m",   # Bright Green   — Cipher
    "architect": "\033[93m",   # Bright Yellow  — Architect
    "ghost":     "\033[91m",   # Bright Red     — Ghost
    "browser":   "\033[36m",   # Cyan           — Browser (was duplicate neo)
    "archivist": "\033[35m",   # Magenta        — Archivist
    "user":      "\033[92m",   # Bright Green   — user input
    "tool":      "\033[93m",   # Bright Yellow  — tool calls
    "out":       "\033[2m",    # Dim            — tool output
    "dim":       "\033[2m",    # Dim
    "bold":      "\033[1m",    # Bold
    "reset":     "\033[0m",    # Reset
    "red":       "\033[91m",   # Bright Red     — errors
}

def c(color: str, text: str) -> str:
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"
