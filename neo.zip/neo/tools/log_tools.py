# tools/log_tools.py — tool call log query tools

from config import c

TAIL_LOG_SCHEMA = {
    "type": "function",
    "function": {
        "name": "tail_tool_log",
        "description": (
            "Show the most recent tool calls from the persistent audit log. "
            "Useful for debugging what an agent did in a previous run or task."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "n": {
                    "type": "integer",
                    "description": "Number of recent entries to show (default: 30, max: 200).",
                    "default": 30,
                },
            },
            "required": [],
        },
    },
}

ALL_SCHEMAS = [TAIL_LOG_SCHEMA]


def execute(name: str, args: dict) -> str:
    print(f"  {c('tool', name)}: {c('dim', str(args)[:60])}")
    if name == "tail_tool_log":
        from tool_log import tail
        result = tail(min(int(args.get("n", 30)), 200))
    else:
        result = f"Unknown log tool: {name}"
    lines   = result.splitlines()
    preview = "\n".join(f"    {l}" for l in lines[:10])
    if len(lines) > 10:
        preview += f"\n    {c('dim', f'... ({len(lines)-10} more lines)')}"
    print(c("out", preview) + "\n")
    return result
