# tools/taskpool_tools.py — Neo's interface to the task pool

from config import c

TASK_SUBMIT_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task_submit",
        "description": (
            "Submit a task to the background task pool. Neo will autonomously select "
            "the best agent for the job, write a complete brief for them, and dispatch "
            "the task concurrently — so you stay responsive while it runs. "
            "Write a rich description: include file paths, expected outputs, constraints, "
            "and any context the agent will need. The richer, the better the brief Neo writes."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "description": {
                    "type": "string",
                    "description": (
                        "Full task description with all context: file paths, expected output, "
                        "constraints, dependencies, and any nuance the agent needs to know."
                    ),
                },
                "priority": {
                    "type": "integer",
                    "description": "Priority 1 (highest) to 10 (lowest). Default: 5.",
                    "default": 5,
                },
            },
            "required": ["description"],
        },
    },
}

TASK_PAUSE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task_pause",
        "description": (
            "Pause a running or pending task. You must provide a detailed pause note "
            "describing: what has been accomplished so far, what files were produced, "
            "what still needs to be done, and any context the agent will need on resume. "
            "This note becomes the foundation of the resume brief."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "The task ID to pause.",
                },
                "pause_note": {
                    "type": "string",
                    "description": (
                        "Detailed status note: what was done, what files exist, "
                        "what remains, and any blockers or context for resumption."
                    ),
                },
            },
            "required": ["task_id", "pause_note"],
        },
    },
}

TASK_RESUME_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task_resume",
        "description": (
            "Resume a paused task. Neo will re-evaluate which agent is best suited "
            "to continue (may differ from the original) and write a resume brief "
            "that picks up from where the task was paused. "
            "Optionally provide additional context to inject into the resume brief."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "task_id": {
                    "type": "string",
                    "description": "The task ID to resume.",
                },
                "additional_context": {
                    "type": "string",
                    "description": "Optional extra context or updated instructions for the resuming agent.",
                },
            },
            "required": ["task_id"],
        },
    },
}

TASK_CHECKPOINT_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task_checkpoint",
        "description": (
            "Save an intermediate progress checkpoint for a running task. "
            "Use this to record partial results so a resumed task can continue "
            "from a known-good state rather than starting over."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "task_id":    {"type": "string", "description": "The task ID."},
                "checkpoint": {"type": "string", "description": "Description of current state and any partial results."},
            },
            "required": ["task_id", "checkpoint"],
        },
    },
}

TASK_STATUS_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task_status",
        "description": "Get status, agent assignment, rationale, and progress log for a specific task.",
        "parameters": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "The task ID."},
            },
            "required": ["task_id"],
        },
    },
}

TASK_RESULT_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task_result",
        "description": "Get the full output of a completed or failed task, including the brief that was sent to the agent.",
        "parameters": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "The task ID."},
            },
            "required": ["task_id"],
        },
    },
}

TASK_LIST_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task_list",
        "description": "List tasks. Optionally filter by status. Shows agent assignment and rationale.",
        "parameters": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["pending", "assigning", "running", "paused",
                             "done", "failed", "cancelled"],
                    "description": "Filter by status (optional).",
                },
                "last_n": {
                    "type": "integer",
                    "description": "Max tasks to return (default: 10).",
                    "default": 10,
                },
            },
            "required": [],
        },
    },
}

TASK_CANCEL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task_cancel",
        "description": "Cancel a pending or paused task. Running tasks must be paused first.",
        "parameters": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "The task ID to cancel."},
            },
            "required": ["task_id"],
        },
    },
}

TASK_POOL_STATUS_SCHEMA = {
    "type": "function",
    "function": {
        "name": "task_pool_status",
        "description": "High-level summary: task counts by status and currently busy agents.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

ALL_SCHEMAS = [
    TASK_SUBMIT_SCHEMA,
    TASK_PAUSE_SCHEMA,
    TASK_RESUME_SCHEMA,
    TASK_CHECKPOINT_SCHEMA,
    TASK_STATUS_SCHEMA,
    TASK_RESULT_SCHEMA,
    TASK_LIST_SCHEMA,
    TASK_CANCEL_SCHEMA,
    TASK_POOL_STATUS_SCHEMA,
]


def execute(name: str, args: dict) -> str:
    from task_pool import task_pool

    print(f"  {c('tool', name)}: {c('dim', str(args)[:80])}")

    if name == "task_submit":
        task = task_pool.submit(
            description  = args["description"],
            submitted_by = args.get("submitted_by", "neo"),
            priority     = args.get("priority", 5),
        )
        result = (
            f"Task submitted — Neo is selecting the best agent and writing a brief.\n"
            f"  ID:       {task.id}\n"
            f"  Status:   {task.status.value}\n"
            f"  Priority: {task.priority}\n"
            f"  Files detected: {len(task.file_refs)}"
            + (f"\n  Files: {', '.join(task.file_refs)}" if task.file_refs else "")
        )

    elif name == "task_pause":
        result = task_pool.pause(args["task_id"], args["pause_note"])

    elif name == "task_resume":
        result = task_pool.resume(args["task_id"], args.get("additional_context", ""))

    elif name == "task_checkpoint":
        result = task_pool.add_checkpoint(args["task_id"], args["checkpoint"])

    elif name == "task_status":
        task = task_pool.get(args["task_id"])
        result = task_pool.format_task(task, full=False) if task else f"Task '{args['task_id']}' not found."

    elif name == "task_result":
        task = task_pool.get(args["task_id"])
        if not task:
            result = f"Task '{args['task_id']}' not found."
        elif task.status.value not in ("done", "failed"):
            result = f"Task {task.id} is still {task.status.value}."
        else:
            result = task_pool.format_task(task, full=True)

    elif name == "task_list":
        tasks = task_pool.list_tasks(status=args.get("status"), last_n=args.get("last_n", 10))
        result = "\n\n".join(task_pool.format_task(t) for t in tasks) if tasks else "No tasks found."

    elif name == "task_cancel":
        result = task_pool.cancel(args["task_id"])

    elif name == "task_pool_status":
        busy   = ", ".join(sorted(task_pool._busy)) or "none"
        result = f"Pool: {task_pool.status_summary()}\nBusy agents: {busy}"

    else:
        result = f"Unknown task pool tool: {name}"

    lines   = result.splitlines()
    preview = "\n".join(f"    {l}" for l in lines[:12])
    if len(lines) > 12:
        preview += f"\n    {c('dim', f'... ({len(lines)-12} more lines)')}"
    print(c("out", preview) + "\n")
    return result
