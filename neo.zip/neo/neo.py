# neo.py — Neo, the primary conversational agent

from agent import Agent
from tools import (WORKER_TOOLS, ARCHIVE_SCHEMAS, CREATE_TOOL_SCHEMA, UPGRADE_TOOL_SCHEMA,
                   make_delegate_schema, make_parallel_delegate_schema)


class Neo(Agent):
    name        = "Neo"
    description = "Primary conversational agent. Orchestrates, delegates, searches, manages files, uses the browser, and builds tools."
    color       = "neo"
    tools       = WORKER_TOOLS + ARCHIVE_SCHEMAS

    @property
    def system_prompt(self) -> str:
        from tool_registry import registry
        from archive import archive
        from config import WORKSPACE

        agent_list = "\n".join(
            f"  - {name}: {ag.description}" for name, ag in self.agents.items()
        )
        dynamic = registry.summary()

        return (
            "You are Neo, a sharp and capable AI agent running on the user's machine.\n\n"
            f"Your workspace: {WORKSPACE}\n"
            "  This is your dedicated working directory. Save all generated files, "
            "scripts, outputs, and downloads here unless told otherwise.\n\n"
            "Your tools:\n"
            "  Core:      shell, web_search\n"
            "  Files:     read_file, write_file, append_file\n"
            "  Dirs:      list_dir, make_dir, delete_path, move_path, copy_path\n"
            "  Archive:   archive_snapshot, archive_status, archive_diff, archive_history,\n"
            "             archive_get_agent, archive_get_source, archive_get_tools, archive_log\n"
            "  Meta:      create_tool, upgrade_tool\n"
            "  Agents:    delegate, parallel_delegate\n"
            "  + any dynamic tools you've created (listed below)\n\n"
            f"Your team:\n{agent_list}\n\n"
            f"Dynamic tools:\n{dynamic}\n\n"
            "Guidelines:\n"
            "  - Use parallel_delegate for independent tasks — it saves significant time.\n"
            "  - Delegate browser tasks to Browser; infrastructure/code changes to Archivist.\n"
            "  - After any structural change (new tool, new file, modified agent), ask Archivist\n"
            "    to snapshot, or call archive_snapshot yourself.\n"
            "  - Use archive_diff to check if your code has drifted from the last snapshot.\n"
            "  - Be direct, confident, and explain non-obvious actions.\n"
            "  - You remember everything said in this conversation."
        )

    def _build_tools(self) -> list:
        from tool_registry import registry
        return [
            *WORKER_TOOLS,
            *ARCHIVE_SCHEMAS,
            make_delegate_schema(self.agents),
            make_parallel_delegate_schema(self.agents),
            CREATE_TOOL_SCHEMA,
            UPGRADE_TOOL_SCHEMA,
            *registry.schemas(),
        ]
