# config.py — configuration loader and shared constants

import os

def _load_env(path: str):
    if not os.path.exists(path):
        return
    with open(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = val

_load_env(os.path.join(os.path.dirname(__file__), ".env"))

API_URL     = "https://openrouter.ai/api/v1/chat/completions"
MODEL       = os.environ.get("NEO_MODEL", "arcee-ai/trinity-large-preview:free")
SERPAPI_KEY = os.environ.get("SERPAPI_KEY", "")

# Workspace — dedicated directory for all of Neo's working files.
# Defaults to a `workspace/` folder next to this file.
# Override via NEO_WORKSPACE in .env or environment.
WORKSPACE = os.path.abspath(
    os.environ.get(
        "NEO_WORKSPACE",
        os.path.join(os.path.dirname(__file__), "workspace"),
    )
)

COLORS = {
    "neo":       "\033[96m",   # Cyan
    "morpheus":  "\033[95m",   # Magenta
    "alpha":     "\033[94m",   # Blue
    "beta":      "\033[36m",   # Dark Cyan
    "cipher":    "\033[92m",   # Green
    "architect": "\033[93m",   # Yellow
    "ghost":     "\033[91m",   # Red
    "browser":   "\033[96m",   # Cyan
    "archivist": "\033[35m",   # Purple
    "user":      "\033[92m",   # Green
    "tool":      "\033[93m",   # Yellow
    "out":       "\033[2m",    # Dim
    "dim":       "\033[2m",    # Dim
    "bold":      "\033[1m",    # Bold
    "reset":     "\033[0m",    # Reset
    "red":       "\033[91m",   # Red
}

def c(color: str, text: str) -> str:
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"
