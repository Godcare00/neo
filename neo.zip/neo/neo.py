# neo.py — Neo, the primary conversational agent

from agent import Agent
from tools import (WORKER_TOOLS, ARCHIVE_SCHEMAS, TASKPOOL_SCHEMAS,
                   CREATE_TOOL_SCHEMA, UPGRADE_TOOL_SCHEMA,
                   make_delegate_schema, make_parallel_delegate_schema)


class Neo(Agent):
    name        = "Neo"
    description = "Primary conversational agent. Orchestrates, delegates, runs background tasks, searches, manages files, and builds tools."
    color       = "neo"
    tools       = WORKER_TOOLS + ARCHIVE_SCHEMAS + TASKPOOL_SCHEMAS

    @property
    def system_prompt(self) -> str:
        from tool_registry import registry
        from config import WORKSPACE

        agent_list = "\n".join(
            f"  - {name}: {ag.description}" for name, ag in self.agents.items()
        )
        dynamic = registry.summary()

        return (
            "You are Neo, a sharp and capable AI agent running on the user's machine.\n\n"
            f"Your workspace: {WORKSPACE}\n"
            "  Save all generated files, scripts, outputs, and downloads here unless told otherwise.\n\n"
            "Your tools:\n"
            "  Core:       shell, web_search\n"
            "  Files:      read_file, write_file, append_file\n"
            "  Dirs:       list_dir, make_dir, delete_path, move_path, copy_path\n"
            "  Archive:    archive_snapshot, archive_status, archive_diff, archive_history,\n"
            "              archive_get_agent, archive_get_source, archive_get_tools, archive_log\n"
            "  Task Pool:  task_submit, task_pause, task_resume, task_checkpoint,\n"
            "              task_status, task_result, task_list, task_cancel, task_pool_status\n"
            "  Meta:       create_tool, upgrade_tool\n"
            "  Agents:     delegate, parallel_delegate\n"
            "  + any dynamic tools you've created (listed below)\n\n"
            f"Your team:\n{agent_list}\n\n"
            f"Dynamic tools:\n{dynamic}\n\n"
            "Task Pool guidelines:\n"
            "  - task_submit: you autonomously select the best agent and write the brief.\n"
            "    Write a rich description — the more context you provide, the better brief\n"
            "    you'll produce for the agent. Include file paths, expected output, constraints.\n"
            "  - task_pause: pause a task with a detailed note on what was done and what remains.\n"
            "    This note is what you'll use to resume — be thorough.\n"
            "  - task_resume: re-evaluate the best agent and resume with a fresh brief built\n"
            "    from the pause note. You may reassign to a different agent if appropriate.\n"
            "  - task_checkpoint: save intermediate results mid-task so resumption is lossless.\n"
            "  - Use task_list/task_status to stay aware of what's running.\n"
            "  - Completed tasks notify the user automatically.\n\n"
            "General guidelines:\n"
            "  - Use parallel_delegate for quick coordinated work; task_submit for longer jobs.\n"
            "  - Delegate browser tasks to Browser; code changes to Cipher; infra to Archivist.\n"
            "  - Be direct, confident, and explain your reasoning when making decisions.\n"
            "  - You remember everything said in this conversation."
        )

    def _build_tools(self) -> list:
        from tool_registry import registry
        return [
            *WORKER_TOOLS,
            *ARCHIVE_SCHEMAS,
            *TASKPOOL_SCHEMAS,
            make_delegate_schema(self.agents),
            make_parallel_delegate_schema(self.agents),
            CREATE_TOOL_SCHEMA,
            UPGRADE_TOOL_SCHEMA,
            *registry.schemas(),
        ]
