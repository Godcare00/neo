# atomic_write.py — crash-safe file writes
#
# Uses write-to-temp + os.replace() which is atomic on POSIX and
# functionally atomic on Windows (os.replace is documented as such).
# A crash mid-write leaves the original file intact.

import os
import json
import tempfile


def atomic_json(path: str, data, indent: int = 2):
    """Serialize `data` to JSON and atomically replace `path`."""
    dir_  = os.path.dirname(os.path.abspath(path))
    os.makedirs(dir_, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=dir_, prefix=".tmp_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent)
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def atomic_text(path: str, text: str):
    """Write `text` to a file atomically."""
    dir_  = os.path.dirname(os.path.abspath(path))
    os.makedirs(dir_, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=dir_, prefix=".tmp_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
