# tools/__init__.py — unified tool export and executor

from tools.shell         import SCHEMA             as SHELL_SCHEMA
from tools.files         import (READ_FILE_SCHEMA, WRITE_FILE_SCHEMA, APPEND_FILE_SCHEMA)
from tools.directory     import (LIST_DIR_SCHEMA, MAKE_DIR_SCHEMA, DELETE_PATH_SCHEMA,
                                 MOVE_PATH_SCHEMA, COPY_PATH_SCHEMA)
from tools.search        import SCHEMA             as WEB_SEARCH_SCHEMA
from tools.meta          import CREATE_TOOL_SCHEMA, UPGRADE_TOOL_SCHEMA
from tools.delegate      import (make_delegate_schema, make_parallel_delegate_schema,
                                 run_delegate, run_parallel_delegate)
from tools.browser       import ALL_SCHEMAS        as BROWSER_SCHEMAS, EXECUTORS as BROWSER_EXECUTORS
from tools.archive_tools import ALL_SCHEMAS        as ARCHIVE_SCHEMAS
from tools.taskpool_tools import ALL_SCHEMAS       as TASKPOOL_SCHEMAS
from tools.pipeline_tools import ALL_SCHEMAS       as PIPELINE_SCHEMAS
from tools.safe_write_tools import ALL_SCHEMAS     as SAFE_WRITE_SCHEMAS
from tools.log_tools        import ALL_SCHEMAS     as LOG_SCHEMAS

# Standard tools every worker agent gets
WORKER_TOOLS = [
    SHELL_SCHEMA,
    READ_FILE_SCHEMA,
    WRITE_FILE_SCHEMA,
    APPEND_FILE_SCHEMA,
    LIST_DIR_SCHEMA,
    MAKE_DIR_SCHEMA,
    DELETE_PATH_SCHEMA,
    MOVE_PATH_SCHEMA,
    COPY_PATH_SCHEMA,
    WEB_SEARCH_SCHEMA,
]

_BROWSER_TOOL_NAMES   = {s["function"]["name"] for s in BROWSER_SCHEMAS}
_ARCHIVE_TOOL_NAMES   = {s["function"]["name"] for s in ARCHIVE_SCHEMAS}
_TASKPOOL_TOOL_NAMES    = {s["function"]["name"] for s in TASKPOOL_SCHEMAS}
_PIPELINE_TOOL_NAMES    = {s["function"]["name"] for s in PIPELINE_SCHEMAS}
_SAFE_WRITE_TOOL_NAMES  = {s["function"]["name"] for s in SAFE_WRITE_SCHEMAS}


def execute_tool(name: str, args: dict, agents: dict) -> str:
    from tool_registry import registry
    import tools.shell         as _shell
    import tools.files         as _files
    import tools.directory     as _dir
    import tools.search        as _search
    import tools.archive_tools as _archive
    import tools.taskpool_tools as _taskpool

    if name == "shell":             return _shell.execute(args)
    if name == "read_file":         return _files.read_file(args)
    if name == "write_file":
        # Intercept writes to .py source files — redirect through safe_write
        _path = args.get("path", "")
        if _path.endswith(".py"):
            import tools.safe_write_tools as _sw
            return _sw.execute("safe_write_file", args)
        return _files.write_file(args)
    if name == "append_file":       return _files.append_file(args)
    if name == "list_dir":          return _dir.list_dir(args)
    if name == "make_dir":          return _dir.make_dir(args)
    if name == "delete_path":       return _dir.delete_path(args)
    if name == "move_path":         return _dir.move_path(args)
    if name == "copy_path":         return _dir.copy_path(args)
    if name == "web_search":        return _search.execute(args)
    if name == "delegate":          return run_delegate(args, agents)
    if name == "parallel_delegate": return run_parallel_delegate(args, agents)

    if name in _BROWSER_TOOL_NAMES:
        fn = BROWSER_EXECUTORS.get(name)
        return fn(args) if fn else f"Browser executor missing: {name}"

    if name in _ARCHIVE_TOOL_NAMES:
        return _archive.execute(name, args, agents)

    if name in _PIPELINE_TOOL_NAMES:
        import tools.pipeline_tools as _pipeline
        return _pipeline.execute(name, args)

    if name in _SAFE_WRITE_TOOL_NAMES:
        import tools.safe_write_tools as _safe
        return _safe.execute(name, args)

    if name in {s['function']['name'] for s in LOG_SCHEMAS}:
        import tools.log_tools as _log
        return _log.execute(name, args)

    if name in _TASKPOOL_TOOL_NAMES:
        return _taskpool.execute(name, args)

    if name == "create_tool":
        try:
            result = registry.create(
                name=args["name"], description=args["description"],
                parameters=args["parameters"], code=args["code"],
            )
            from archive import archive
            archive.log_tool_created(args["name"], args["description"])
            return result
        except Exception as e:
            return f"create_tool failed: {e}"

    if name == "upgrade_tool":
        try:
            result = registry.upgrade(
                name=args["name"], description=args.get("description"),
                parameters=args.get("parameters"), code=args.get("code"),
            )
            from archive import archive
            archive.log_tool_upgraded(args["name"])
            return result
        except Exception as e:
            return f"upgrade_tool failed: {e}"

    if name in registry.names():
        return registry.execute(name, args)

    return f"Unknown tool: {name}"
