#!/usr/bin/env python3
# main.py — CLI entry point for the Neo agent system
#
# Usage: python main.py [options]
#   --workspace PATH   Override workspace directory
#   --model     MODEL  Override LLM model
#   --no-stream        Disable streaming output
#   --no-snapshot      Skip initial archive snapshot

import os
import sys
import argparse
import signal
import urllib.error

# ── CLI argument parsing ──────────────────────────────────────────────────────

def _parse_args():
    parser = argparse.ArgumentParser(description="Neo — multi-agent AI system")
    parser.add_argument("--workspace",   help="Workspace directory path")
    parser.add_argument("--model",       help="LLM model override")
    parser.add_argument("--no-stream",   action="store_true", help="Disable streaming")
    parser.add_argument("--no-snapshot", action="store_true", help="Skip initial snapshot")
    return parser.parse_args()

args = _parse_args()

# Apply overrides before config is imported by anything else
if args.workspace:
    os.environ["NEO_WORKSPACE"] = args.workspace
if args.model:
    os.environ["NEO_MODEL"] = args.model
if args.no_stream:
    os.environ["NEO_STREAMING"] = "false"

# ── Now import everything ─────────────────────────────────────────────────────

from config import c, STREAMING
from neo import Neo
from agents import Morpheus, Alpha, Beta, Cipher, Architect, Ghost, Browser, Archivist
import conversation_store


def build_team(api_key: str) -> Neo:
    team = {
        "Morpheus":  Morpheus (api_key=api_key),
        "Alpha":     Alpha    (api_key=api_key),
        "Beta":      Beta     (api_key=api_key),
        "Cipher":    Cipher   (api_key=api_key),
        "Architect": Architect(api_key=api_key),
        "Ghost":     Ghost    (api_key=api_key),
        "Browser":   Browser  (api_key=api_key),
        "Archivist": Archivist(api_key=api_key),
    }
    return Neo(api_key=api_key, agents=team)


def init_workspace():
    from config import WORKSPACE
    os.makedirs(WORKSPACE, exist_ok=True)
    print(c("dim", f"  workspace: {WORKSPACE}\n"))


def initial_snapshot(neo: Neo):
    from archive import archive
    from tools import WORKER_TOOLS
    static_names = [t["function"]["name"] for t in WORKER_TOOLS]
    try:
        result = archive.snapshot(neo.agents, static_names, background=True)
        print(c("dim", f"  archive: {result}\n"))
    except Exception as e:
        print(c("dim", f"  archive: snapshot skipped ({e})\n"))


def init_task_pool(neo: Neo, notify_fn=None, api_key: str = ""):
    from task_pool import task_pool
    task_pool.set_agents(neo.agents)
    task_pool.set_api_key(api_key)
    if notify_fn:
        task_pool.set_on_done(notify_fn)
    print(c("dim", f"  task pool: ready ({len(neo.agents)} agents)\n"))


def rollback(messages: list):
    while messages and messages[-1].get("role") != "user":
        messages.pop()
    if messages:
        messages.pop()


def shutdown():
    from task_pool import task_pool
    task_pool.shutdown(wait=False)


def main():
    api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not api_key:
        print(c("red", "\n  Error: OPENROUTER_API_KEY not set."))
        print(c("dim",  "  Add it to your .env file or export it in your shell.\n"))
        sys.exit(1)

    neo = build_team(api_key)
    init_workspace()

    if not args.no_snapshot:
        initial_snapshot(neo)

    def on_task_done(task):
        icon   = "✓" if task.status.value == "done" else "✗"
        status = task.status.value.upper()
        print(f"\n  {c('dim', f'[task {task.id}]')} {icon} {status} "
              f"({task.assigned_agent}) — {task.description[:60]}\n"
              f"  {c('dim', 'Use: task_result ' + task.id + ' for full output')}\n")

        # Inject task result into Neo's conversation so he knows about it.
        # Uses a 'system' role injection so it doesn't look like a user message.
        try:
            summary = (
                f"[BACKGROUND TASK COMPLETED]\n"
                f"Task ID:  {task.id}\n"
                f"Agent:    {task.assigned_agent}\n"
                f"Status:   {status}\n"
                f"Task:     {task.description[:200]}\n"
                + (f"Result preview:\n{(task.result or '')[:600]}" if task.result
                   else f"Error: {task.error or 'unknown'}")
            )
            # messages is captured from the enclosing main() scope
            messages.append({"role": "assistant", "content": summary})
            conversation_store.save("cli", messages)
        except Exception:
            pass   # never crash the callback

    init_task_pool(neo, notify_fn=on_task_done, api_key=api_key)

    # ── Graceful shutdown on Ctrl+C / SIGTERM ─────────────────────────────────
    def _shutdown_handler(sig, frame):
        print(c("dim", "\n\n  Shutting down...\n"))
        conversation_store.save("cli", messages)
        shutdown()
        sys.exit(0)

    signal.signal(signal.SIGTERM, _shutdown_handler)

    # ── Load or start conversation ────────────────────────────────────────────
    messages = conversation_store.load("cli", neo.system_prompt)
    resumed  = len(messages) > 1
    stream   = STREAMING

    print()
    print(c("bold", "  Neo") + c("dim", " -- multi-agent system"))
    print("  " + "  ".join(c(name.lower(), f"+ {name}") for name in neo.agents))
    if resumed:
        print(c("dim", f"  resumed conversation ({len(messages)-1} turns)\n"))
    print(c("dim", "  Type 'exit' or Ctrl+C to quit\n"))

    while True:
        try:
            user_input = input(c("user", "  You: ")).strip()
        except (KeyboardInterrupt, EOFError):
            print(c("dim", "\n\n  Goodbye.\n"))
            conversation_store.save("cli", messages)
            shutdown()
            break

        if not user_input:
            continue

        if user_input.lower() in {"exit", "quit", "bye"}:
            print(c("dim", "\n  Goodbye.\n"))
            conversation_store.save("cli", messages)
            shutdown()
            break

        if user_input.lower() == "/clear":
            messages = conversation_store.clear("cli", neo.system_prompt)
            print(c("dim", "  Conversation cleared.\n"))
            continue

        messages.append({"role": "user", "content": user_input})

        try:
            if stream:
                # Agent prints "Neo: " + text tokens as they arrive.
                # No prefix printed here — agent does it at first token.
                reply = neo.chat(messages, stream=True)
                if not reply:
                    reply = ""
            else:
                reply = neo.chat(messages)
                print(f"  {c('neo', 'Neo')}: {reply}\n")

            if reply:
                messages.append({"role": "assistant", "content": reply})
            conversation_store.save("cli", messages)

        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            print(c("red", f"\n  API error {e.code}: {body}\n"))
            rollback(messages)

        except Exception as e:
            print(c("red", f"\n  Error: {e}\n"))
            rollback(messages)


if __name__ == "__main__":
    main()
