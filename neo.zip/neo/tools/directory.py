# tools/directory.py — directory listing, creation, deletion, move/copy

import os
import shutil
from config import c

# ── Schemas ───────────────────────────────────────────────────────────────────

LIST_DIR_SCHEMA = {
    "type": "function",
    "function": {
        "name": "list_dir",
        "description": (
            "List the contents of a directory. Returns file names, types, and sizes. "
            "Optionally recurse into subdirectories. Use to explore project structure, "
            "find files, or understand what's on disk."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path":    {"type": "string", "description": "Directory path to list (default: current dir)."},
                "recurse": {"type": "boolean", "description": "Recurse into subdirectories (default: false)."},
                "max_depth": {"type": "integer", "description": "Max recursion depth when recurse=true (default: 3)."},
            },
            "required": [],
        },
    },
}

MAKE_DIR_SCHEMA = {
    "type": "function",
    "function": {
        "name": "make_dir",
        "description": "Create a directory (and any missing parents). Safe to call if it already exists.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Directory path to create."},
            },
            "required": ["path"],
        },
    },
}

DELETE_PATH_SCHEMA = {
    "type": "function",
    "function": {
        "name": "delete_path",
        "description": (
            "Delete a file or directory. Directories are removed recursively. "
            "Use with care — this is permanent."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "File or directory path to delete."},
            },
            "required": ["path"],
        },
    },
}

MOVE_PATH_SCHEMA = {
    "type": "function",
    "function": {
        "name": "move_path",
        "description": "Move or rename a file or directory from src to dst.",
        "parameters": {
            "type": "object",
            "properties": {
                "src": {"type": "string", "description": "Source path."},
                "dst": {"type": "string", "description": "Destination path."},
            },
            "required": ["src", "dst"],
        },
    },
}

COPY_PATH_SCHEMA = {
    "type": "function",
    "function": {
        "name": "copy_path",
        "description": "Copy a file or directory from src to dst.",
        "parameters": {
            "type": "object",
            "properties": {
                "src": {"type": "string", "description": "Source path."},
                "dst": {"type": "string", "description": "Destination path."},
            },
            "required": ["src", "dst"],
        },
    },
}

# ── Executors ─────────────────────────────────────────────────────────────────

def list_dir(args: dict) -> str:
    path      = args.get("path", ".") or "."
    recurse   = args.get("recurse", False)
    max_depth = args.get("max_depth", 3)
    print(f"  {c('tool', 'list_dir')}: {c('dim', path)}")
    try:
        lines = []

        def _walk(current: str, depth: int):
            try:
                entries = sorted(os.scandir(current), key=lambda e: (not e.is_dir(), e.name))
            except PermissionError:
                return
            for entry in entries:
                indent = "  " * depth
                if entry.is_dir(follow_symlinks=False):
                    lines.append(f"{indent}{entry.name}/")
                    if recurse and depth < max_depth:
                        _walk(entry.path, depth + 1)
                else:
                    try:
                        size = entry.stat().st_size
                        size_str = f"{size:,} B" if size < 1024 else f"{size // 1024:,} KB"
                    except OSError:
                        size_str = "?"
                    lines.append(f"{indent}{entry.name}  ({size_str})")

        _walk(os.path.abspath(path), 0)
        result = "\n".join(lines) or "(empty)"
        preview = "\n".join(f"    {l}" for l in lines[:30])
        if len(lines) > 30:
            preview += f"\n    {c('dim', f'... ({len(lines) - 30} more entries)')}"
        print(c("out", preview) + "\n")
        return result
    except FileNotFoundError:
        msg = f"Directory not found: {path}"
        print(c("red", f"    {msg}\n"))
        return msg
    except Exception as e:
        msg = f"Error listing {path}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def make_dir(args: dict) -> str:
    path = args.get("path", "")
    print(f"  {c('tool', 'make_dir')}: {c('dim', path)}")
    try:
        os.makedirs(path, exist_ok=True)
        msg = f"Directory ready: {os.path.abspath(path)}"
        print(c("out", f"    {msg}") + "\n")
        return msg
    except Exception as e:
        msg = f"Error creating {path}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def delete_path(args: dict) -> str:
    path = args.get("path", "")
    print(f"  {c('tool', 'delete_path')}: {c('dim', path)}")
    try:
        if os.path.isdir(path):
            shutil.rmtree(path)
            msg = f"Deleted directory: {path}"
        elif os.path.isfile(path):
            os.remove(path)
            msg = f"Deleted file: {path}"
        else:
            msg = f"Path not found: {path}"
        print(c("out", f"    {msg}") + "\n")
        return msg
    except Exception as e:
        msg = f"Error deleting {path}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def move_path(args: dict) -> str:
    src, dst = args.get("src", ""), args.get("dst", "")
    print(f"  {c('tool', 'move_path')}: {c('dim', f'{src} -> {dst}')}")
    try:
        os.makedirs(os.path.dirname(os.path.abspath(dst)), exist_ok=True)
        shutil.move(src, dst)
        msg = f"Moved {src} -> {dst}"
        print(c("out", f"    {msg}") + "\n")
        return msg
    except Exception as e:
        msg = f"Error moving {src} -> {dst}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def copy_path(args: dict) -> str:
    src, dst = args.get("src", ""), args.get("dst", "")
    print(f"  {c('tool', 'copy_path')}: {c('dim', f'{src} -> {dst}')}")
    try:
        os.makedirs(os.path.dirname(os.path.abspath(dst)), exist_ok=True)
        if os.path.isdir(src):
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)
        msg = f"Copied {src} -> {dst}"
        print(c("out", f"    {msg}") + "\n")
        return msg
    except Exception as e:
        msg = f"Error copying {src} -> {dst}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg
