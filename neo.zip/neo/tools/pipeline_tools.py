# tools/pipeline_tools.py — DAG pipeline tool for Neo

from config import c

PIPELINE_SUBMIT_SCHEMA = {
    "type": "function",
    "function": {
        "name": "pipeline_submit",
        "description": (
            "Submit a multi-stage pipeline where stages run in dependency order. "
            "Independent stages run in parallel; dependent stages wait for their inputs. "
            "Each stage gets the full results of its upstream stages injected into its brief. "
            "Use this for structured multi-step work where outputs feed into inputs — "
            "e.g. Cipher writes code -> Ghost audits it -> Architect documents it. "
            "Unlike parallel_delegate (fire-and-forget) or task_submit_coordinated "
            "(LLM-managed rounds), pipelines give you explicit control over data flow."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "goal": {
                    "type": "string",
                    "description": "The overall goal of the pipeline. Shared context for all stages.",
                },
                "stages": {
                    "type": "array",
                    "description": "Ordered list of pipeline stages (DAG nodes).",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {
                                "type": "string",
                                "description": "Unique stage name within this pipeline (e.g. 'write_code', 'audit', 'document').",
                            },
                            "description": {
                                "type": "string",
                                "description": "What this stage must produce. Be specific — this is the agent's task.",
                            },
                            "agent": {
                                "type": "string",
                                "description": "Agent to run this stage (Morpheus/Alpha/Beta/Cipher/Architect/Ghost/Browser/Archivist).",
                            },
                            "depends_on": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Names of stages that must complete before this one starts (optional).",
                            },
                        },
                        "required": ["name", "description", "agent"],
                    },
                    "minItems": 2,
                    "maxItems": 12,
                },
                "priority": {
                    "type": "integer",
                    "description": "Priority 1 (highest) to 10 (lowest). Default: 5.",
                    "default": 5,
                },
            },
            "required": ["goal", "stages"],
        },
    },
}

ALL_SCHEMAS = [PIPELINE_SUBMIT_SCHEMA]


def execute(name: str, args: dict) -> str:
    if name != "pipeline_submit":
        return f"Unknown pipeline tool: {name}"

    from task_pool import task_pool
    from pipeline import _validate_dag, PipelineStage

    goal       = args["goal"]
    stages_def = args["stages"]
    priority   = args.get("priority", 5)

    print(f"  {c('tool', 'pipeline_submit')}: {c('dim', goal[:60])}")

    # Validate DAG before queuing
    try:
        stages = [
            PipelineStage(
                name        = s["name"],
                description = s["description"],
                agent       = s.get("agent", ""),
                depends_on  = s.get("depends_on", []),
            )
            for s in stages_def
        ]
        _validate_dag(stages)
    except ValueError as e:
        result = f"Pipeline validation failed: {e}"
        print(c("red", f"    {result}\n"))
        return result

    task = task_pool.submit_pipeline(
        goal       = goal,
        stages_def = stages_def,
        priority   = priority,
    )

    result = (
        f"Pipeline submitted.\n"
        f"  ID:     {task.id}\n"
        f"  Stages: {len(stages_def)}\n"
        f"  Goal:   {goal[:120]}\n"
        f"  Status: {task.status.value}"
    )
    lines   = result.splitlines()
    preview = "\n".join(f"    {l}" for l in lines[:8])
    print(c("out", preview) + "\n")
    return result
