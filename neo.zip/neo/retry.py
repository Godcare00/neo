# retry.py — exponential backoff with jitter for LLM API calls
#
# Wraps urllib calls with automatic retry on transient failures:
#   - 429 Too Many Requests  (rate limit)
#   - 500/502/503/504        (server errors)
#   - ConnectionResetError / TimeoutError (network blips)
#   - json.JSONDecodeError   (malformed 200 response — happens with some providers)
#
# Uses full-jitter exponential backoff:
#   sleep = random(0, min(cap, base * 2^attempt))
# This avoids thundering herd when multiple agents hit the limit simultaneously.

import json
import time
import random
import urllib.request
import urllib.error
from config import c

# Backoff config
RETRY_MAX_ATTEMPTS  = 5
RETRY_BASE_SECONDS  = 1.0
RETRY_CAP_SECONDS   = 60.0
RETRY_ON_STATUS     = {429, 500, 502, 503, 504}


class RetryExhausted(Exception):
    """Raised when all retry attempts are exhausted."""


def _backoff(attempt: int) -> float:
    """Full-jitter exponential backoff. attempt is 0-indexed."""
    cap   = RETRY_CAP_SECONDS
    base  = RETRY_BASE_SECONDS
    sleep = random.uniform(0, min(cap, base * (2 ** attempt)))
    return sleep


def urlopen_with_retry(req: urllib.request.Request,
                       timeout: int = 60) -> bytes:
    """
    Execute a urllib Request with automatic retry on transient errors.
    Returns the raw response bytes on success.
    Raises RetryExhausted if all attempts fail.
    Raises urllib.error.HTTPError for non-retryable HTTP errors (4xx except 429).
    """
    last_exc = None

    for attempt in range(RETRY_MAX_ATTEMPTS):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read()

            # Validate the response is parseable JSON before returning.
            # Some providers return 200 with malformed JSON on transient errors.
            try:
                json.loads(raw.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                last_exc = e
                sleep = _backoff(attempt)
                print(c("dim", f"  retry: malformed JSON response, "
                                f"attempt {attempt+1}/{RETRY_MAX_ATTEMPTS}, "
                                f"sleeping {sleep:.1f}s\n"))
                time.sleep(sleep)
                continue

            return raw

        except urllib.error.HTTPError as e:
            if e.code in RETRY_ON_STATUS:
                last_exc = e
                sleep = _backoff(attempt)
                retry_after = e.headers.get("Retry-After")
                if retry_after:
                    try:
                        sleep = max(sleep, float(retry_after))
                    except (ValueError, TypeError):
                        pass
                print(c("dim", f"  retry: HTTP {e.code}, attempt {attempt+1}/{RETRY_MAX_ATTEMPTS}, "
                                f"sleeping {sleep:.1f}s\n"))
                time.sleep(sleep)
                continue
            raise   # non-retryable (401, 404, etc.)

        except (ConnectionResetError, TimeoutError, OSError) as e:
            last_exc = e
            sleep = _backoff(attempt)
            print(c("dim", f"  retry: {type(e).__name__}, attempt {attempt+1}/{RETRY_MAX_ATTEMPTS}, "
                            f"sleeping {sleep:.1f}s\n"))
            time.sleep(sleep)
            continue

    raise RetryExhausted(
        f"All {RETRY_MAX_ATTEMPTS} retry attempts failed. Last error: {last_exc}"
    )
