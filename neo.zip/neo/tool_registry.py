# tool_registry.py — runtime registry for Neo's self-created tools
#
# Dynamic tools are stored as:
#   {
#     "name": "my_tool",
#     "description": "...",
#     "parameters": { ...JSON Schema... },
#     "code": "def run(args):\n    ..."   # Python source, must define run(args: dict) -> str
#   }
#
# They are persisted to tools_registry.json and hot-loaded on startup.

import os
import json
import textwrap
import traceback
from config import c

REGISTRY_FILE = os.path.join(os.path.dirname(__file__), "tools_registry.json")


class ToolRegistry:
    """Holds and executes dynamically created tools."""

    def __init__(self):
        self._tools: dict[str, dict] = {}   # name → {schema, code, fn}
        self._load()

    # ── Persistence ───────────────────────────────────────────────────────────

    def _load(self):
        if not os.path.exists(REGISTRY_FILE):
            return
        try:
            with open(REGISTRY_FILE) as f:
                saved = json.load(f)
            for entry in saved:
                self._compile_and_store(entry, persist=False)
            if self._tools:
                names = ", ".join(self._tools)
                print(c("dim", f"  ↺ loaded dynamic tools: {names}\n"))
        except Exception as e:
            print(c("red", f"  Warning: could not load tool registry: {e}\n"))

    def _save(self):
        entries = [
            {
                "name":        t["name"],
                "description": t["description"],
                "parameters":  t["parameters"],
                "code":        t["code"],
            }
            for t in self._tools.values()
        ]
        with open(REGISTRY_FILE, "w") as f:
            json.dump(entries, f, indent=2)

    # ── Compilation ───────────────────────────────────────────────────────────

    def _compile_and_store(self, entry: dict, persist: bool = True) -> str:
        name   = entry["name"]
        code   = textwrap.dedent(entry["code"])

        # Compile the code and extract the run() function
        ns = {}
        exec(compile(code, f"<tool:{name}>", "exec"), ns)   # noqa: S102

        if "run" not in ns:
            raise ValueError(f"Tool code for '{name}' must define a `run(args)` function.")

        schema = {
            "type": "function",
            "function": {
                "name":        name,
                "description": entry["description"],
                "parameters":  entry["parameters"],
            },
        }

        self._tools[name] = {
            "name":        name,
            "description": entry["description"],
            "parameters":  entry["parameters"],
            "code":        code,
            "schema":      schema,
            "fn":          ns["run"],
        }

        if persist:
            self._save()

        return name

    # ── Public API ────────────────────────────────────────────────────────────

    def create(self, name: str, description: str, parameters: dict, code: str) -> str:
        """Create a new tool. Raises if name already exists."""
        if name in self._tools:
            raise ValueError(
                f"Tool '{name}' already exists. Use upgrade_tool to modify it."
            )
        self._compile_and_store(
            {"name": name, "description": description, "parameters": parameters, "code": code}
        )
        return f"Tool '{name}' created and registered successfully."

    def upgrade(self, name: str, description: str = None,
                parameters: dict = None, code: str = None) -> str:
        """Upgrade an existing tool. Only provided fields are updated."""
        if name not in self._tools:
            available = ", ".join(self._tools) or "none"
            raise ValueError(f"Tool '{name}' not found. Available: {available}")

        existing = self._tools[name]
        entry = {
            "name":        name,
            "description": description  if description  is not None else existing["description"],
            "parameters":  parameters   if parameters   is not None else existing["parameters"],
            "code":        code         if code         is not None else existing["code"],
        }
        self._compile_and_store(entry)
        return f"Tool '{name}' upgraded successfully."

    def execute(self, name: str, args: dict) -> str:
        """Execute a registered dynamic tool."""
        tool = self._tools.get(name)
        if not tool:
            return f"Unknown dynamic tool: {name}"
        print(f"  {c('tool', f'⚡ {name}')}: {c('dim', str(args))}")
        try:
            result = str(tool["fn"](args))
            lines   = result.splitlines()
            preview = "\n".join(f"    {l}" for l in lines[:20])
            if len(lines) > 20:
                preview += f"\n    {c('dim', f'… ({len(lines) - 20} more lines)')}"
            print(c("out", preview) + "\n")
            return result
        except Exception:
            err = traceback.format_exc()
            print(c("red", f"    {err}\n"))
            return f"Tool '{name}' raised an exception:\n{err}"

    def schemas(self) -> list[dict]:
        """Return all dynamic tool schemas (for injection into the API call)."""
        return [t["schema"] for t in self._tools.values()]

    def names(self) -> list[str]:
        return list(self._tools.keys())

    def summary(self) -> str:
        if not self._tools:
            return "No dynamic tools registered yet."
        lines = [f"  - {name}: {t['description']}" for name, t in self._tools.items()]
        return "\n".join(lines)


# Singleton — shared across the whole process
registry = ToolRegistry()
