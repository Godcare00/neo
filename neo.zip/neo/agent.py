# agent.py — base Agent class

import json
import threading
import collections
import urllib.request
from config import API_URL, MODEL, c
from tools import execute_tool
from retry import urlopen_with_retry, urlopen_stream

MAX_TOOL_CALLS_PER_TURN = 40
MAX_IDENTICAL_REPEATS   = 3

_build_lock = threading.Lock()


def _normalise_for_fingerprint(fn: str, args: dict, result: str) -> str:
    """
    Normalise a tool result for repeat-detection fingerprinting.
    Strips values that legitimately differ each call (task IDs, timestamps)
    so the loop guard can detect logically repeated actions.
    """
    import re as _re
    # task_submit always returns a new ID — normalise to just the tool name + description
    if fn in ("task_submit", "pipeline_submit", "task_submit_coordinated"):
        return f"{fn}:{args.get('description','')[:80]}"
    # Strip IDs (hex, alphanumeric 6-16 chars) and timestamps from any result
    normalised = _re.sub(r'\b[0-9a-f]{6,16}\b', '<id>', result, flags=_re.IGNORECASE)
    normalised = _re.sub(r'\b[a-z0-9]{6,16}\b', '<id>', normalised, flags=_re.IGNORECASE)
    normalised = _re.sub(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}', '<ts>', normalised)
    return normalised


class Agent:
    name:        str  = "Agent"
    description: str  = "A general-purpose agent."
    color:       str  = "dim"
    tools:       list = []

    def __init__(self, api_key: str, agents: dict = None):
        self.api_key = api_key
        self.agents  = agents or {}

    @property
    def system_prompt(self) -> str:
        raise NotImplementedError

    # ── Non-streaming API call (with retry + JSON-decode retry) ──────────────

    def _call_api(self, messages: list, tools: list) -> dict:
        payload = json.dumps({
            "model":       MODEL,
            "messages":    messages,
            "tools":       tools or [],
            "tool_choice": "auto" if tools else "none",
        }).encode("utf-8")
        req = urllib.request.Request(
            API_URL, data=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type":  "application/json",
                "HTTP-Referer":  "https://github.com/neo-agent",
                "X-Title":       f"Neo - {self.name}",
            },
            method="POST",
        )
        raw  = urlopen_with_retry(req, timeout=120)
        data = json.loads(raw.decode("utf-8"))
        return data["choices"][0]["message"]

    # ── Streaming final reply ─────────────────────────────────────────────────

    def _call_api_stream(self, messages: list, tools: list) -> dict:
        """
        Send a SINGLE streaming request that handles BOTH tool calls and text.

        Returns a message dict identical to _call_api's format:
          {"content": "...", "tool_calls": [...]}

        Text chunks are printed to the terminal as they arrive so the user
        sees the reply incrementally. Tool-call deltas are accumulated silently.

        Falls back to _call_api on any streaming error.
        """
        payload = json.dumps({
            "model":       MODEL,
            "messages":    messages,
            "tools":       tools or [],
            "tool_choice": "auto" if tools else "none",
            "stream":      True,
        }).encode("utf-8")
        req = urllib.request.Request(
            API_URL, data=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type":  "application/json",
                "HTTP-Referer":  "https://github.com/neo-agent",
                "X-Title":       f"Neo - {self.name}",
                "Accept":        "text/event-stream",
            },
            method="POST",
        )

        text_parts: list[str]  = []
        tool_calls: list[dict] = []
        printed_prefix         = False
        stream_failed          = False

        try:
            resp = urlopen_stream(req, timeout=120)
        except Exception as _e:
            # Stream open failed — fall back only if NOT a hard exhaustion
            from retry import RetryExhausted
            if isinstance(_e, RetryExhausted):
                # Don't silently double-request; surface the failure
                raise
            return self._call_api(messages, tools)

        try:
            # Iterate line-by-line so tokens print as they arrive,
            # without buffering the entire response into memory first.
            for raw_line in resp:
                line = raw_line.decode("utf-8").strip()
                if not line or line == "data: [DONE]":
                    continue
                if not line.startswith("data: "):
                    continue
                try:
                    chunk = json.loads(line[6:])
                except json.JSONDecodeError:
                    continue

                delta = chunk.get("choices", [{}])[0].get("delta", {})

                # Text delta — print immediately
                text = delta.get("content") or ""
                if text:
                    if not printed_prefix:
                        # Print "Neo: " right before the FIRST token arrives,
                        # not before we even know if there will be text output.
                        print(f"  {c(self.color, self.name)}: ", end="", flush=True)
                        printed_prefix = True
                    text_parts.append(text)
                    print(text, end="", flush=True)

                # Tool-call delta — accumulate silently
                for tc_delta in (delta.get("tool_calls") or []):
                    idx = tc_delta.get("index", 0)
                    while len(tool_calls) <= idx:
                        tool_calls.append({
                            "id": "", "type": "function",
                            "function": {"name": "", "arguments": ""},
                        })
                    if tc_delta.get("id"):
                        tool_calls[idx]["id"] = tc_delta["id"]
                    fn = tc_delta.get("function", {})
                    if fn.get("name"):
                        tool_calls[idx]["function"]["name"] += fn["name"]
                    if fn.get("arguments"):
                        tool_calls[idx]["function"]["arguments"] += fn["arguments"]
        except Exception:
            stream_failed = True
        finally:
            try:
                resp.close()
            except Exception:
                pass

        if text_parts:
            print()  # newline after last streamed chunk

        if stream_failed and not text_parts and not tool_calls:
            # Stream failed partway with nothing received — fall back
            return self._call_api(messages, tools)

        msg: dict = {"content": "".join(text_parts).strip() or None}
        if tool_calls:
            msg["tool_calls"] = tool_calls
        return msg

    # ── Thread-safe tool list ─────────────────────────────────────────────────

    def _build_tools(self) -> list:
        with _build_lock:
            return list(self.tools)

    # ── Agentic loop ──────────────────────────────────────────────────────────

    def _run_loop(self, messages: list, stream: bool = False) -> str:
        from tool_log import log_call

        tool_call_count = 0
        recent          = collections.deque(maxlen=MAX_IDENTICAL_REPEATS)

        while True:
            tools = self._build_tools()
            print(c("dim", "  ..."), end="\r", flush=True)
            # Use streaming call when stream=True — single request handles
            # both tool-call accumulation and live text output.
            if stream:
                msg = self._call_api_stream(messages, tools)
            else:
                msg = self._call_api(messages, tools)
            print("      ", end="\r")

            # No tool calls — this is the final reply
            if not msg.get("tool_calls"):
                return (msg.get("content") or "").strip()

            messages.append(msg)

            for tc in msg["tool_calls"]:
                tool_call_count += 1
                if tool_call_count > MAX_TOOL_CALLS_PER_TURN:
                    cap_msg = (
                        f"[LOOP GUARD] Stopped after {MAX_TOOL_CALLS_PER_TURN} tool calls. "
                        f"Last: {tc['function']['name']}. Try a different approach."
                    )
                    print(c("red", f"  {cap_msg}\n"))
                    messages.append({
                        "role": "tool", "tool_call_id": tc["id"],
                        "name": tc["function"]["name"], "content": cap_msg,
                    })
                    bail = (self._call_api_stream(messages, []) if stream
                            else self._call_api(messages, tools=[]))
                    return (bail.get("content") or cap_msg).strip()

                fn   = tc["function"]["name"]
                args = json.loads(tc["function"]["arguments"] or "{}")
                result = execute_tool(fn, args, self.agents)
                log_call(fn, args, result, agent=self.name)

                # For fingerprinting, normalise results that contain
                # unique IDs (e.g. task_submit returns a new task ID
                # every call — strip it so repeated submissions are caught).
                fp_result = _normalise_for_fingerprint(fn, args, result)
                fp = (fn, json.dumps(args, sort_keys=True), fp_result)
                recent.append(fp)
                if len(recent) == MAX_IDENTICAL_REPEATS and len(set(recent)) == 1:
                    stuck = (
                        f"[LOOP GUARD] '{fn}' returned the same result "
                        f"{MAX_IDENTICAL_REPEATS} times: {result[:200]!r}. "
                        f"Stop retrying — try a different approach."
                    )
                    print(c("red", f"  {stuck}\n"))
                    messages.append({
                        "role": "tool", "tool_call_id": tc["id"],
                        "name": fn, "content": stuck,
                    })
                    bail = (self._call_api_stream(messages, []) if stream
                            else self._call_api(messages, tools=[]))
                    return (bail.get("content") or stuck).strip()

                messages.append({
                    "role": "tool", "tool_call_id": tc["id"],
                    "name": fn, "content": result,
                })

    def run(self, task: str, stream: bool = False) -> str:
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user",   "content": task},
        ]
        return self._run_loop(messages, stream=stream)

    def chat(self, messages: list, stream: bool = False) -> str:
        return self._run_loop(messages, stream=stream)
