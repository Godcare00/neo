# neo.py — Neo, the primary conversational agent

from agent import Agent
from tools import SHELL_TOOL, CREATE_TOOL, UPGRADE_TOOL, make_delegate_tool


class Neo(Agent):
    """
    Neo is the primary agent the user talks to. He thinks, converses,
    uses the shell himself when it's quick, delegates deeper work to
    sub-agents, and can create or upgrade his own tools on the fly.
    """

    name        = "Neo"
    description = "Primary conversational agent. Orchestrates tasks, delegates, and builds tools."
    color       = "neo"
    tools       = [SHELL_TOOL]  # base; rest injected dynamically

    @property
    def system_prompt(self) -> str:
        from tool_registry import registry

        agent_list = "\n".join(
            f"  - {name}: {ag.description}" for name, ag in self.agents.items()
        )
        dynamic = registry.summary()

        return (
            "You are Neo, a sharp and capable AI agent running on the user's machine.\n\n"
            "Your tools:\n"
            "  1. shell         — run shell commands for quick tasks.\n"
            "  2. delegate      — hand off work to a specialist sub-agent.\n"
            "  3. create_tool   — define and register a new callable Python tool permanently.\n"
            "  4. upgrade_tool  — rewrite or fix any existing dynamic tool in-place.\n"
            "  + any tools you've already created (listed below).\n\n"
            f"Your team:\n{agent_list}\n\n"
            f"Your dynamic tools:\n{dynamic}\n\n"
            "Guidelines:\n"
            "  - Use shell for fast one-off tasks.\n"
            "  - Use create_tool when a capability is missing and would be useful long-term.\n"
            "  - Use upgrade_tool to fix bugs or extend a tool you already made.\n"
            "  - Delegate to specialists for deep or multi-step work.\n"
            "  - Be direct, confident, and explain non-obvious actions.\n"
            "  - You remember everything said in this conversation."
        )

    def _build_tools(self) -> list:
        from tool_registry import registry
        return [
            SHELL_TOOL,
            make_delegate_tool(self.agents),
            CREATE_TOOL,
            UPGRADE_TOOL,
            *registry.schemas(),   # all previously created dynamic tools
        ]
