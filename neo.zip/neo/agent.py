# agent.py — base Agent class all agents inherit from

import json
import urllib.request
import urllib.error
from config import API_URL, MODEL, c
from tools import SHELL_TOOL, execute_tool


class Agent:
    """
    A self-contained LLM agent with its own identity, system prompt,
    tools, and agentic loop. Can be used standalone or as a sub-agent.
    """

    name:        str = "Agent"
    description: str = "A general-purpose agent."
    color:       str = "dim"
    tools:       list = []          # subclasses declare their tool schemas

    def __init__(self, api_key: str, agents: dict = None):
        self.api_key = api_key
        self.agents  = agents or {}   # sibling agents available for delegation

    @property
    def system_prompt(self) -> str:
        raise NotImplementedError

    # ── Low-level API call ────────────────────────────────────────────────────

    def _call_api(self, messages: list, tools: list) -> dict:
        payload = json.dumps({
            "model": MODEL,
            "messages": messages,
            "tools": tools or [],
            "tool_choice": "auto" if tools else "none",
        }).encode("utf-8")

        req = urllib.request.Request(
            API_URL,
            data=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://github.com/neo-agent",
                "X-Title": f"Neo — {self.name}",
            },
            method="POST",
        )

        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["choices"][0]["message"]

    # ── Agentic loop ──────────────────────────────────────────────────────────

    def _build_tools(self) -> list:
        """Subclasses can override to inject dynamic tools (e.g. delegate)."""
        return list(self.tools)

    def _run_loop(self, messages: list) -> str:
        tools = self._build_tools()
        while True:
            print(c("dim", "  ..."), end="\r", flush=True)
            msg = self._call_api(messages, tools)
            print("      ", end="\r")

            if not msg.get("tool_calls"):
                return (msg.get("content") or "").strip()

            messages.append(msg)

            for tc in msg["tool_calls"]:
                fn     = tc["function"]["name"]
                args   = json.loads(tc["function"]["arguments"] or "{}")
                result = execute_tool(fn, args, self.agents)

                messages.append({
                    "role":        "tool",
                    "tool_call_id": tc["id"],
                    "name":        fn,
                    "content":     result,
                })

    # ── Public interface ──────────────────────────────────────────────────────

    def run(self, task: str) -> str:
        """Run a one-shot task and return the response string."""
        messages = [
            {"role": "system",  "content": self.system_prompt},
            {"role": "user",    "content": task},
        ]
        return self._run_loop(messages)

    def chat(self, messages: list) -> str:
        """Continue a multi-turn conversation (messages includes system prompt)."""
        return self._run_loop(messages)
