# tools/shell.py — shell execution tool

import subprocess
from config import c

SCHEMA = {
    "type": "function",
    "function": {
        "name": "shell",
        "description": (
            "Execute a shell command on the user's machine and return stdout + stderr. "
            "Use for system tasks, running scripts, installing packages, inspecting state."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Shell command to run via /bin/sh."},
                "timeout": {"type": "integer", "description": "Max seconds to wait (default 30).", "default": 30},
            },
            "required": ["command"],
        },
    },
}


def execute(args: dict) -> str:
    command = args.get("command", "")
    timeout = args.get("timeout", 30)
    print(f"  {c('tool', 'shell')}: {c('dim', command)}")
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=timeout)
        output = ((result.stdout or "") + (result.stderr or "")).strip() or "(no output)"
        lines  = output.splitlines()
        preview = "\n".join(f"    {l}" for l in lines[:20])
        if len(lines) > 20:
            preview += f"\n    {c('dim', f'... ({len(lines) - 20} more lines)')}"
        print(c("out", preview) + "\n")
        return output
    except subprocess.TimeoutExpired:
        msg = f"Command timed out after {timeout}s"
        print(c("red", f"    {msg}\n"))
        return msg
    except Exception as e:
        msg = f"Error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg
