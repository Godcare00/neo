#!/usr/bin/env python3
# main.py — entry point for the Neo agent system

import os
import sys
import urllib.error

from config import c
from neo import Neo
from agents import Morpheus


def build_team(api_key: str) -> Neo:
    """Instantiate all agents and wire them together."""

    # Sub-agents (they don't need to know about each other for now)
    morpheus = Morpheus(api_key=api_key)

    # Neo gets the full roster
    team = {
        "Morpheus": morpheus,
    }

    neo = Neo(api_key=api_key, agents=team)
    return neo


def rollback(messages: list):
    """Remove everything back to (and including) the last user message."""
    while messages and messages[-1].get("role") != "user":
        messages.pop()
    if messages:
        messages.pop()


def main():
    api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not api_key:
        print(c("red", "\n  Error: OPENROUTER_API_KEY not set."))
        print(c("dim",  "  Run: export OPENROUTER_API_KEY=your_key_here\n"))
        sys.exit(1)

    neo      = build_team(api_key)
    messages = [{"role": "system", "content": neo.system_prompt}]

    print()
    print(c("bold", "  Neo") + c("dim", " — multi-agent system"))
    agents_line = "  " + "  ".join(
        c(name.lower(), f"+ {name}") for name in neo.agents
    )
    print(agents_line)
    print(c("dim", "  Type 'exit' or Ctrl+C to quit\n"))

    while True:
        try:
            user_input = input(c("user", "  You: ")).strip()
        except (KeyboardInterrupt, EOFError):
            print(c("dim", "\n\n  Goodbye.\n"))
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit", "bye"}:
            print(c("dim", "\n  Goodbye.\n"))
            break

        messages.append({"role": "user", "content": user_input})

        try:
            reply = neo.chat(messages)
            messages.append({"role": "assistant", "content": reply})
            print(f"  {c('neo', 'Neo')}: {reply}\n")

        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            print(c("red", f"\n  API error {e.code}: {body}\n"))
            rollback(messages)

        except Exception as e:
            print(c("red", f"\n  Error: {e}\n"))
            rollback(messages)


if __name__ == "__main__":
    main()
