# config.py — configuration loader and shared constants
#
# Loads .env from the project root (same directory as this file).
# Falls back to real environment variables if .env is absent.

import os

# ── .env loader (no external deps) ───────────────────────────────────────────

def _load_env(path: str):
    """Parse a .env file and populate os.environ for any key not already set."""
    if not os.path.exists(path):
        return
    with open(path) as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = val

_load_env(os.path.join(os.path.dirname(__file__), ".env"))

# ── Settings ──────────────────────────────────────────────────────────────────

API_URL    = "https://openrouter.ai/api/v1/chat/completions"
MODEL      = os.environ.get("NEO_MODEL", "arcee-ai/trinity-large-preview:free")
SERPAPI_KEY = os.environ.get("SERPAPI_KEY", "")

# ── Terminal colors ───────────────────────────────────────────────────────────

COLORS = {
    "neo":       "\033[96m",   # Cyan
    "morpheus":  "\033[95m",   # Magenta
    "alpha":     "\033[94m",   # Blue
    "beta":      "\033[96m",   # Cyan
    "cipher":    "\033[92m",   # Green
    "architect": "\033[93m",   # Yellow
    "ghost":     "\033[91m",   # Red
    "user":      "\033[92m",   # Green  — user input
    "tool":      "\033[93m",   # Yellow — tool calls
    "out":       "\033[2m",    # Dim    — tool output
    "dim":       "\033[2m",    # Dim
    "bold":      "\033[1m",    # Bold
    "reset":     "\033[0m",    # Reset
    "red":       "\033[91m",   # Red    — errors
}

def c(color: str, text: str) -> str:
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"
