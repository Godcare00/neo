# tools/archive_tools.py — tools that expose the Archive to agents

from config import c

# ── Schemas ───────────────────────────────────────────────────────────────────

ARCHIVE_SNAPSHOT_SCHEMA = {
    "type": "function",
    "function": {
        "name": "archive_snapshot",
        "description": (
            "Take a full snapshot of Neo's current infrastructure: all agents, tools, "
            "and source files with checksums. Call this after any structural change "
            "(new agent, new tool, file modified) to keep the archive current."
        ),
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

ARCHIVE_STATUS_SCHEMA = {
    "type": "function",
    "function": {
        "name": "archive_status",
        "description": "Get a high-level summary of Neo's current infrastructure state from the archive.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

ARCHIVE_GET_AGENT_SCHEMA = {
    "type": "function",
    "function": {
        "name": "archive_get_agent",
        "description": "Get detailed archived info about a specific agent (description, source file, prompt preview).",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Agent name."},
            },
            "required": ["name"],
        },
    },
}

ARCHIVE_GET_SOURCE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "archive_get_source",
        "description": "Look up a source file in the archive — returns checksum, size, and last modified time.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Full or partial file path, e.g. 'agents/cipher.py'."},
            },
            "required": ["path"],
        },
    },
}

ARCHIVE_DIFF_SCHEMA = {
    "type": "function",
    "function": {
        "name": "archive_diff",
        "description": (
            "Compare the archived source file checksums against the current files on disk. "
            "Returns a list of files that have been added, modified, or removed since the last snapshot. "
            "Use this to detect self-modifications or unexpected changes."
        ),
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

ARCHIVE_HISTORY_SCHEMA = {
    "type": "function",
    "function": {
        "name": "archive_history",
        "description": "Get the recent event history — tool creations, file modifications, snapshots, etc.",
        "parameters": {
            "type": "object",
            "properties": {
                "last_n": {"type": "integer", "description": "Number of recent events to return (default: 20)."},
            },
            "required": [],
        },
    },
}

ARCHIVE_GET_TOOLS_SCHEMA = {
    "type": "function",
    "function": {
        "name": "archive_get_tools",
        "description": "List all dynamic tools currently recorded in the archive.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

ARCHIVE_LOG_SCHEMA = {
    "type": "function",
    "function": {
        "name": "archive_log",
        "description": "Write a custom event to the archive history log. Use to record decisions, changes, or observations.",
        "parameters": {
            "type": "object",
            "properties": {
                "event":  {"type": "string", "description": "Short event label, e.g. 'self_modification'."},
                "detail": {"type": "string", "description": "Full description of what happened and why."},
            },
            "required": ["event", "detail"],
        },
    },
}

ARCHIVE_DUMP_SCHEMA = {
    "type": "function",
    "function": {
        "name": "archive_dump",
        "description": "Return the full archive as JSON. Use sparingly — it can be large.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

ALL_SCHEMAS = [
    ARCHIVE_SNAPSHOT_SCHEMA,
    ARCHIVE_STATUS_SCHEMA,
    ARCHIVE_GET_AGENT_SCHEMA,
    ARCHIVE_GET_SOURCE_SCHEMA,
    ARCHIVE_DIFF_SCHEMA,
    ARCHIVE_HISTORY_SCHEMA,
    ARCHIVE_GET_TOOLS_SCHEMA,
    ARCHIVE_LOG_SCHEMA,
    ARCHIVE_DUMP_SCHEMA,
]

# ── Executors ─────────────────────────────────────────────────────────────────

def execute(name: str, args: dict, agents: dict) -> str:
    from archive import archive
    from tools import WORKER_TOOLS

    print(f"  {c('tool', name)}: {c('dim', str(args)[:80])}")

    if name == "archive_snapshot":
        static_names = [t["function"]["name"] for t in WORKER_TOOLS]
        result = archive.snapshot(agents, static_names)

    elif name == "archive_status":
        result = archive.status()

    elif name == "archive_get_agent":
        result = archive.get_agent(args.get("name", ""))

    elif name == "archive_get_source":
        result = archive.get_source_file(args.get("path", ""))

    elif name == "archive_diff":
        result = archive.diff_source_files()

    elif name == "archive_history":
        result = archive.get_history(args.get("last_n", 20))

    elif name == "archive_get_tools":
        result = archive.get_dynamic_tools()

    elif name == "archive_log":
        archive.log_custom(args.get("event", "note"), args.get("detail", ""))
        result = "Event logged to archive."

    elif name == "archive_dump":
        result = archive.full_dump()

    else:
        result = f"Unknown archive tool: {name}"

    lines   = result.splitlines()
    preview = "\n".join(f"    {l}" for l in lines[:15])
    if len(lines) > 15:
        preview += f"\n    {c('dim', f'... ({len(lines)-15} more lines)')}"
    print(c("out", preview) + "\n")
    return result
