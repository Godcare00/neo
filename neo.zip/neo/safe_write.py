# safe_write.py — safe source file modification
#
# Any write to a .py file in the project root goes through SafeWriter:
#   1. PROTECTED files cannot be modified without explicit confirmation
#   2. New content is syntax-checked (ast.parse)
#   3. New content is import-checked (py_compile in a subprocess)
#   4. A timestamped backup is created first
#   5. Write is committed only if all checks pass
#   6. Rollback restores from backup if anything breaks post-write
#
# Non-.py files bypass SafeWriter entirely — they write normally.

import os
import re
import ast
import sys
import shutil
import subprocess
import datetime
import tempfile
from config import c, WORKSPACE

# Always resolve PROJECT_ROOT relative to this file's real location,
# not the cwd, so protection works regardless of where Neo is launched from.
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

# ── Protected files ───────────────────────────────────────────────────────────
# These files form Neo's core runtime. Writing them incorrectly can break
# the entire system. Any attempt to write them is blocked unless the caller
# passes confirmed=True explicitly.

PROTECTED_FILES = {
    "agent.py",
    "config.py",
    "main.py",
    "neo.py",
    "task_pool.py",
    "coordination.py",
    "pipeline.py",
    "safe_write.py",
    "tool_registry.py",
    "atomic_write.py",
    "json_utils.py",
    "tools/__init__.py",
    "tools/files.py",
    "tools/shell.py",
    "telegram_bot.py",
}

BACKUPS_DIR         = os.path.join(WORKSPACE, "source_backups")
MAX_BACKUPS_PER_FILE = 10   # keep only the N most recent backups per file


def _rel(path: str) -> str:
    """Return path relative to PROJECT_ROOT, or None if outside it."""
    try:
        return os.path.relpath(os.path.abspath(path), PROJECT_ROOT)
    except ValueError:
        return None


def _is_source_file(path: str) -> bool:
    return path.endswith(".py")


def _is_protected(rel_path: str) -> bool:
    # Normalise to forward slashes for cross-platform comparison
    norm = rel_path.replace(os.sep, "/")
    return norm in PROTECTED_FILES


def _backup(abs_path: str) -> str:
    """
    Copy abs_path to BACKUPS_DIR with a timestamp suffix.
    Rotates old backups, keeping at most MAX_BACKUPS_PER_FILE per file.
    Returns the new backup path.
    """
    os.makedirs(BACKUPS_DIR, exist_ok=True)
    ts   = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name = os.path.basename(abs_path)
    dest = os.path.join(BACKUPS_DIR, f"{name}.{ts}.bak")
    shutil.copy2(abs_path, dest)
    _rotate_backups(name)
    return dest


def _rotate_backups(filename: str):
    """Delete oldest backups for `filename`, keeping MAX_BACKUPS_PER_FILE."""
    try:
        all_baks = sorted(
            [f for f in os.listdir(BACKUPS_DIR) if f.startswith(f"{filename}.")],
        )
        while len(all_baks) > MAX_BACKUPS_PER_FILE:
            oldest = os.path.join(BACKUPS_DIR, all_baks.pop(0))
            try:
                os.unlink(oldest)
            except OSError:
                pass
    except Exception:
        pass


def _syntax_check(content: str, path: str) -> tuple[bool, str]:
    """Run ast.parse on content. Returns (ok, error_message)."""
    try:
        ast.parse(content, filename=path)
        return True, ""
    except SyntaxError as e:
        return False, f"SyntaxError at line {e.lineno}: {e.msg}"


def _compile_check(content: str, path: str) -> tuple[bool, str]:
    """
    Write content to a temp file and run py_compile in a subprocess.
    This catches import-time errors that ast.parse misses.
    """
    with tempfile.NamedTemporaryFile(
        suffix=".py", mode="w", encoding="utf-8", delete=False
    ) as tf:
        tf.write(content)
        tmp_path = tf.name

    try:
        result = subprocess.run(
            [sys.executable, "-m", "py_compile", tmp_path],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            # Replace temp path with real path in error message
            err = (result.stderr or result.stdout).strip()
            err = err.replace(tmp_path, path)
            return False, f"Compile error: {err}"
        return True, ""
    except subprocess.TimeoutExpired:
        return False, "Compile check timed out"
    except Exception as e:
        return False, f"Compile check error: {e}"
    finally:
        os.unlink(tmp_path)


# ── Public API ────────────────────────────────────────────────────────────────

class SafeWriteError(Exception):
    """Raised when a safe write is blocked or fails validation."""


def safe_write_file(path: str, content: str, confirmed: bool = False) -> str:
    """
    Write content to path with full safety checks for .py files.

    Args:
        path:      Destination file path.
        content:   Content to write.
        confirmed: Must be True to write PROTECTED_FILES.

    Returns a status string.
    Raises SafeWriteError if blocked or validation fails.
    """
    abs_path = os.path.abspath(path)
    rel      = _rel(abs_path)

    # ── Non-source files bypass all checks ───────────────────────────────────
    if not _is_source_file(abs_path):
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)
        with open(abs_path, "w", encoding="utf-8") as f:
            f.write(content)
        return f"Written {len(content)} bytes to {abs_path}"

    # ── Protected file guard ──────────────────────────────────────────────────
    if rel and _is_protected(rel) and not confirmed:
        raise SafeWriteError(
            f"'{rel}' is a PROTECTED core file.\n"
            f"To modify it, call safe_write_file with confirmed=True.\n"
            f"Protected files: {sorted(PROTECTED_FILES)}"
        )

    # ── Syntax check ─────────────────────────────────────────────────────────
    ok, err = _syntax_check(content, abs_path)
    if not ok:
        raise SafeWriteError(
            f"Syntax check FAILED for '{rel or abs_path}':\n  {err}\n"
            f"File was NOT written. Fix the syntax error and try again."
        )

    # ── Compile check ─────────────────────────────────────────────────────────
    ok, err = _compile_check(content, abs_path)
    if not ok:
        raise SafeWriteError(
            f"Compile check FAILED for '{rel or abs_path}':\n  {err}\n"
            f"File was NOT written."
        )

    # ── Backup existing file ──────────────────────────────────────────────────
    backup_path = None
    if os.path.isfile(abs_path):
        backup_path = _backup(abs_path)

    # ── Commit write ─────────────────────────────────────────────────────────
    from atomic_write import atomic_text
    atomic_text(abs_path, content)

    status = (
        f"Safely written {len(content)} bytes to {abs_path}.\n"
        + (f"Backup: {backup_path}" if backup_path else "No previous version to back up.")
    )
    print(c("dim", f"  safe_write: {abs_path} ({len(content)} bytes)"
                   + (f" | backup: {os.path.basename(backup_path)}" if backup_path else "") + "\n"))

    # Audit log for protected-file modifications
    if rel and _is_protected(rel) and confirmed:
        try:
            from tool_log import log_call
            log_call(
                "safe_write_confirmed",
                {"path": rel, "size": str(len(content)),
                 "backup": os.path.basename(backup_path) if backup_path else "none"},
                "PROTECTED FILE MODIFIED WITH confirmed=True",
                agent="safe_write",
            )
        except Exception:
            pass

    return status


def rollback_file(path: str) -> str:
    """
    Restore a file from its most recent backup.
    Returns a status string.
    """
    abs_path = os.path.abspath(path)
    name     = os.path.basename(abs_path)

    if not os.path.isdir(BACKUPS_DIR):
        return f"No backups directory found at {BACKUPS_DIR}"

    # Find all backups for this file, sorted newest first
    backups = sorted(
        [f for f in os.listdir(BACKUPS_DIR) if f.startswith(f"{name}.")],
        reverse=True,
    )
    if not backups:
        return f"No backups found for '{name}'"

    latest   = os.path.join(BACKUPS_DIR, backups[0])
    shutil.copy2(latest, abs_path)
    return f"Rolled back '{abs_path}' from backup '{backups[0]}'"


def list_backups(path: str = None) -> str:
    """List available backups, optionally filtered by file name."""
    if not os.path.isdir(BACKUPS_DIR):
        return "No backups directory found."

    files = sorted(os.listdir(BACKUPS_DIR), reverse=True)
    if path:
        name  = os.path.basename(path)
        files = [f for f in files if f.startswith(f"{name}.")]

    if not files:
        return "No backups found."

    lines = [f"Backups in {BACKUPS_DIR}:"]
    for f in files[:40]:
        size = os.path.getsize(os.path.join(BACKUPS_DIR, f))
        lines.append(f"  {f}  ({size:,} bytes)")
    if len(files) > 40:
        lines.append(f"  ... ({len(files) - 40} more)")
    return "\n".join(lines)
