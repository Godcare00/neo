#!/usr/bin/env python3
# main.py — entry point for the Neo agent system

import os
import sys
import urllib.error

from config import c
from neo import Neo
from agents import Morpheus, Alpha, Beta, Cipher, Architect, Ghost, Browser, Archivist


def build_team(api_key: str) -> Neo:
    team = {
        "Morpheus":  Morpheus (api_key=api_key),
        "Alpha":     Alpha    (api_key=api_key),
        "Beta":      Beta     (api_key=api_key),
        "Cipher":    Cipher   (api_key=api_key),
        "Architect": Architect(api_key=api_key),
        "Ghost":     Ghost    (api_key=api_key),
        "Browser":   Browser  (api_key=api_key),
        "Archivist": Archivist(api_key=api_key),
    }
    return Neo(api_key=api_key, agents=team)


def init_workspace():
    """Create the workspace directory if it doesn't exist and print its path."""
    from config import WORKSPACE
    os.makedirs(WORKSPACE, exist_ok=True)
    print(c("dim", f"  workspace: {WORKSPACE}\n"))


def initial_snapshot(neo: Neo):
    """Take a first-run archive snapshot so Archivist has a baseline."""
    from archive import archive
    from tools import WORKER_TOOLS
    static_names = [t["function"]["name"] for t in WORKER_TOOLS]
    try:
        result = archive.snapshot(neo.agents, static_names)
        print(c("dim", f"  archive: {result}\n"))
    except Exception as e:
        print(c("dim", f"  archive: snapshot skipped ({e})\n"))


def rollback(messages: list):
    while messages and messages[-1].get("role") != "user":
        messages.pop()
    if messages:
        messages.pop()


def main():
    api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    if not api_key:
        print(c("red", "\n  Error: OPENROUTER_API_KEY not set."))
        print(c("dim",  "  Add it to your .env file or export it in your shell.\n"))
        sys.exit(1)

    neo = build_team(api_key)
    init_workspace()
    initial_snapshot(neo)

    messages = [{"role": "system", "content": neo.system_prompt}]

    print()
    print(c("bold", "  Neo") + c("dim", " -- multi-agent system"))
    print("  " + "  ".join(c(name.lower(), f"+ {name}") for name in neo.agents))
    print(c("dim", "  Type 'exit' or Ctrl+C to quit\n"))

    while True:
        try:
            user_input = input(c("user", "  You: ")).strip()
        except (KeyboardInterrupt, EOFError):
            print(c("dim", "\n\n  Goodbye.\n"))
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit", "bye"}:
            print(c("dim", "\n  Goodbye.\n"))
            break

        messages.append({"role": "user", "content": user_input})

        try:
            reply = neo.chat(messages)
            messages.append({"role": "assistant", "content": reply})
            print(f"  {c('neo', 'Neo')}: {reply}\n")

        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            print(c("red", f"\n  API error {e.code}: {body}\n"))
            rollback(messages)

        except Exception as e:
            print(c("red", f"\n  Error: {e}\n"))
            rollback(messages)


if __name__ == "__main__":
    main()
