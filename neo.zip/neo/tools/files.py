# tools/files.py — file read / write / append tools

import os
from config import c

# ── Schemas ───────────────────────────────────────────────────────────────────

READ_FILE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "read_file",
        "description": (
            "Read the contents of a file and return them as a string. "
            "Optionally read only a range of lines. Use for inspecting source code, "
            "configs, logs, data files, or any text file on disk."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Absolute or relative path to the file.",
                },
                "start_line": {
                    "type": "integer",
                    "description": "First line to return, 1-indexed (optional, default: 1).",
                },
                "end_line": {
                    "type": "integer",
                    "description": "Last line to return, inclusive (optional, default: all).",
                },
            },
            "required": ["path"],
        },
    },
}

WRITE_FILE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "write_file",
        "description": (
            "Write content to a file, creating it if it doesn't exist and overwriting if it does. "
            "Use for saving code, configs, reports, or any generated content to disk. "
            "Parent directories are created automatically."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path":    {"type": "string", "description": "Path to write the file to."},
                "content": {"type": "string", "description": "Full content to write."},
            },
            "required": ["path", "content"],
        },
    },
}

APPEND_FILE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "append_file",
        "description": (
            "Append content to the end of a file. Creates the file if it doesn't exist. "
            "Use for adding to logs, growing data files, or extending existing documents."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path":    {"type": "string", "description": "Path to the file."},
                "content": {"type": "string", "description": "Content to append."},
            },
            "required": ["path", "content"],
        },
    },
}

# ── Executors ─────────────────────────────────────────────────────────────────

def read_file(args: dict) -> str:
    path       = args.get("path", "")
    start_line = args.get("start_line", 1)
    end_line   = args.get("end_line", None)
    print(f"  {c('tool', 'read_file')}: {c('dim', path)}")
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        total = len(lines)
        s = max(1, start_line) - 1
        e = end_line if end_line is not None else total
        selected = lines[s:e]
        result = "".join(selected)
        preview_lines = selected[:20]
        preview = "".join(f"    {l}" for l in preview_lines)
        if len(selected) > 20:
            preview += f"\n    {c('dim', f'... ({len(selected) - 20} more lines)')}"
        print(c("out", preview.rstrip()) + "\n")
        return result
    except FileNotFoundError:
        msg = f"File not found: {path}"
        print(c("red", f"    {msg}\n"))
        return msg
    except Exception as e:
        msg = f"Error reading {path}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def write_file(args: dict) -> str:
    path    = args.get("path", "")
    content = args.get("content", "")
    print(f"  {c('tool', 'write_file')}: {c('dim', path)}")
    try:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        size = os.path.getsize(path)
        msg = f"Written {size} bytes to {path}"
        print(c("out", f"    {msg}") + "\n")
        return msg
    except Exception as e:
        msg = f"Error writing {path}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def append_file(args: dict) -> str:
    path    = args.get("path", "")
    content = args.get("content", "")
    print(f"  {c('tool', 'append_file')}: {c('dim', path)}")
    try:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(content)
        size = os.path.getsize(path)
        msg = f"Appended to {path} (total size: {size} bytes)"
        print(c("out", f"    {msg}") + "\n")
        return msg
    except Exception as e:
        msg = f"Error appending to {path}: {e}"
        print(c("red", f"    {msg}\n"))
        return msg
