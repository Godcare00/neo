# tools/search.py — web search via SerpAPI

import json
import urllib.request
import urllib.parse
from config import c, SERPAPI_KEY

SCHEMA = {
    "type": "function",
    "function": {
        "name": "web_search",
        "description": (
            "Search the web using SerpAPI and return the top results. "
            "Use for current information, news, documentation lookups, research, "
            "or anything that requires up-to-date knowledge beyond your training. "
            "Returns titles, URLs, and snippets for each result."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query.",
                },
                "num_results": {
                    "type": "integer",
                    "description": "Number of results to return (default: 5, max: 10).",
                    "default": 5,
                },
            },
            "required": ["query"],
        },
    },
}


def execute(args: dict) -> str:
    query       = args.get("query", "").strip()
    num_results = min(int(args.get("num_results", 5)), 10)

    print(f"  {c('tool', 'web_search')}: {c('dim', query)}")

    if not SERPAPI_KEY:
        msg = "SERPAPI_KEY is not set. Add it to your .env file."
        print(c("red", f"    {msg}\n"))
        return msg

    if not query:
        return "No query provided."

    try:
        params = urllib.parse.urlencode({
            "q":       query,
            "api_key": SERPAPI_KEY,
            "num":     num_results,
            "engine":  "google",
        })
        url = f"https://serpapi.com/search?{params}"
        req = urllib.request.Request(url, headers={"User-Agent": "neo-agent/1.0"})

        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        results = []

        # Organic results
        for item in data.get("organic_results", [])[:num_results]:
            title   = item.get("title", "No title")
            link    = item.get("link", "")
            snippet = item.get("snippet", "")
            results.append(f"[{title}]\n{link}\n{snippet}")

        # Answer box (if present)
        if "answer_box" in data:
            box = data["answer_box"]
            answer = box.get("answer") or box.get("snippet") or ""
            if answer:
                results.insert(0, f"[Answer Box]\n{answer}")

        if not results:
            return "No results found."

        output = "\n\n".join(results)

        # Print preview
        preview_lines = output.splitlines()[:15]
        preview = "\n".join(f"    {l}" for l in preview_lines)
        if len(output.splitlines()) > 15:
            preview += f"\n    {c('dim', '...')}"
        print(c("out", preview) + "\n")

        return output

    except urllib.error.HTTPError as e:
        msg = f"SerpAPI HTTP error {e.code}: {e.reason}"
        print(c("red", f"    {msg}\n"))
        return msg
    except Exception as e:
        msg = f"Search error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg
