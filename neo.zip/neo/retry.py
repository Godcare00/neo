# retry.py — exponential backoff with jitter for LLM API calls
#
# Two entry points:
#   urlopen_with_retry(req)  — for regular JSON API calls (validates JSON)
#   urlopen_stream(req)      — for SSE streaming (returns the open response object)
#
# Retries on: 429, 500/502/503/504, ConnectionResetError, TimeoutError
# JSON-decode validation only applies to non-streaming calls.

import json
import time
import random
import urllib.request
import urllib.error
from config import c

RETRY_MAX_ATTEMPTS = 5
RETRY_BASE_SECONDS = 1.0
RETRY_CAP_SECONDS  = 60.0
RETRY_ON_STATUS    = {429, 500, 502, 503, 504}


class RetryExhausted(Exception):
    """Raised when all retry attempts are exhausted."""


def _backoff(attempt: int) -> float:
    """Full-jitter exponential backoff. attempt is 0-indexed."""
    return random.uniform(0, min(RETRY_CAP_SECONDS, RETRY_BASE_SECONDS * (2 ** attempt)))


def _sleep_with_msg(code_or_name: str, attempt: int, sleep: float):
    print(c("dim", f"  retry: {code_or_name}, attempt {attempt+1}/{RETRY_MAX_ATTEMPTS}, "
                   f"sleeping {sleep:.1f}s\n"))
    time.sleep(sleep)


def urlopen_with_retry(req: urllib.request.Request, timeout: int = 60) -> bytes:
    """
    Execute a JSON API request with automatic retry.
    Validates that the response is parseable JSON before returning.
    Returns raw response bytes.
    """
    last_exc = None

    for attempt in range(RETRY_MAX_ATTEMPTS):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read()

            # Validate JSON — some providers return 200 with malformed body
            try:
                json.loads(raw.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as e:
                last_exc = e
                _sleep_with_msg("malformed JSON", attempt, _backoff(attempt))
                continue

            return raw

        except urllib.error.HTTPError as e:
            if e.code in RETRY_ON_STATUS:
                last_exc = e
                sleep = _backoff(attempt)
                ra = e.headers.get("Retry-After")
                if ra:
                    try:
                        sleep = max(sleep, float(ra))
                    except (ValueError, TypeError):
                        pass
                _sleep_with_msg(f"HTTP {e.code}", attempt, sleep)
                continue
            raise   # non-retryable (401, 404, etc.)

        except (ConnectionResetError, TimeoutError, OSError) as e:
            last_exc = e
            _sleep_with_msg(type(e).__name__, attempt, _backoff(attempt))
            continue

    raise RetryExhausted(
        f"All {RETRY_MAX_ATTEMPTS} attempts failed. Last error: {last_exc}"
    )


def urlopen_stream(req: urllib.request.Request, timeout: int = 120):
    """
    Open a streaming (SSE) request with retry on connection errors.
    Returns an open response object — caller is responsible for reading
    and closing it (use as a context manager).

    Does NOT validate JSON — SSE responses are not JSON blobs.
    """
    last_exc = None

    for attempt in range(RETRY_MAX_ATTEMPTS):
        try:
            return urllib.request.urlopen(req, timeout=timeout)

        except urllib.error.HTTPError as e:
            if e.code in RETRY_ON_STATUS:
                last_exc = e
                _sleep_with_msg(f"HTTP {e.code}", attempt, _backoff(attempt))
                continue
            raise

        except (ConnectionResetError, TimeoutError, OSError) as e:
            last_exc = e
            _sleep_with_msg(type(e).__name__, attempt, _backoff(attempt))
            continue

    raise RetryExhausted(
        f"All {RETRY_MAX_ATTEMPTS} streaming attempts failed. Last error: {last_exc}"
    )
