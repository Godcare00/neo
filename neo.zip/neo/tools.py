# tools.py — tool definitions (schemas) and their executors

import subprocess
from config import c

# ── Shell tool ────────────────────────────────────────────────────────────────

SHELL_TOOL = {
    "type": "function",
    "function": {
        "name": "shell",
        "description": (
            "Execute a shell command on the user's machine and return stdout + stderr. "
            "Use for file operations, running scripts, checking system state, "
            "installing packages, or anything that benefits from real command execution."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to run (via /bin/sh).",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Max seconds to wait (default 30).",
                    "default": 30,
                },
            },
            "required": ["command"],
        },
    },
}


def run_shell(command: str, timeout: int = 30) -> str:
    print(f"  {c('tool', '⚙ shell')}: {c('dim', command)}")
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        output = ((result.stdout or "") + (result.stderr or "")).strip() or "(no output)"

        lines   = output.splitlines()
        preview = "\n".join(f"    {l}" for l in lines[:20])
        if len(lines) > 20:
            preview += f"\n    {c('dim', f'… ({len(lines) - 20} more lines)')}"
        print(c("out", preview) + "\n")

        return output
    except subprocess.TimeoutExpired:
        msg = f"Command timed out after {timeout}s"
        print(c("red", f"    {msg}\n"))
        return msg
    except Exception as e:
        msg = f"Error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


# ── Delegate tool (injected by Neo at runtime) ────────────────────────────────

def make_delegate_tool(agents: dict) -> dict:
    agent_descriptions = "\n".join(
        f"- {name}: {ag.description}" for name, ag in agents.items()
    )
    return {
        "type": "function",
        "function": {
            "name": "delegate",
            "description": (
                "Assign a task to one of your specialist sub-agents and get back their response.\n"
                f"Available agents:\n{agent_descriptions}"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "agent": {
                        "type": "string",
                        "enum": list(agents.keys()),
                        "description": "The name of the agent to delegate to.",
                    },
                    "task": {
                        "type": "string",
                        "description": "The full task or question to hand off.",
                    },
                },
                "required": ["agent", "task"],
            },
        },
    }


# ── create_tool schema ────────────────────────────────────────────────────────

CREATE_TOOL = {
    "type": "function",
    "function": {
        "name": "create_tool",
        "description": (
            "Create a brand-new callable tool and register it permanently. "
            "The tool becomes immediately available in future turns. "
            "You must supply the tool's name, a clear description, its JSON Schema parameters, "
            "and a Python code block that defines a `run(args: dict) -> str` function. "
            "The run() function receives the tool's arguments as a dict and must return a string. "
            "Standard library modules are available. "
            "Do not create tools that duplicate existing ones."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Snake_case tool name, e.g. 'read_file'. Must be unique.",
                },
                "description": {
                    "type": "string",
                    "description": "Clear description of what the tool does (shown to the model).",
                },
                "parameters": {
                    "type": "object",
                    "description": (
                        "JSON Schema for the tool's input parameters. "
                        "Must include 'type', 'properties', and 'required'."
                    ),
                },
                "code": {
                    "type": "string",
                    "description": (
                        "Python source code defining `run(args: dict) -> str`. "
                        "Example:\n"
                        "  import datetime\n"
                        "  def run(args):\n"
                        "      return str(datetime.datetime.now())\n"
                        "The function must return a plain string."
                    ),
                },
            },
            "required": ["name", "description", "parameters", "code"],
        },
    },
}


# ── upgrade_tool schema ───────────────────────────────────────────────────────

UPGRADE_TOOL = {
    "type": "function",
    "function": {
        "name": "upgrade_tool",
        "description": (
            "Upgrade an existing dynamic tool in-place. "
            "Only the fields you provide will be updated — omit fields you want to keep unchanged. "
            "The upgraded tool replaces the old one immediately and is persisted. "
            "Use this to fix bugs, improve logic, extend parameters, or rewrite descriptions."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "The exact name of the tool to upgrade.",
                },
                "description": {
                    "type": "string",
                    "description": "New description (optional — omit to keep existing).",
                },
                "parameters": {
                    "type": "object",
                    "description": "New JSON Schema parameters (optional — omit to keep existing).",
                },
                "code": {
                    "type": "string",
                    "description": "New Python source for run(args) (optional — omit to keep existing).",
                },
            },
            "required": ["name"],
        },
    },
}


# ── Executor registry ─────────────────────────────────────────────────────────

def execute_tool(name: str, args: dict, agents: dict) -> str:
    # Import here to avoid circular import at module load time
    from tool_registry import registry

    if name == "shell":
        return run_shell(args.get("command", ""), args.get("timeout", 30))

    if name == "delegate":
        agent_name = args.get("agent", "")
        task       = args.get("task", "")
        agent      = agents.get(agent_name)
        if not agent:
            return f"Unknown agent: {agent_name}"
        print(f"  {c('tool', '↪ delegate')} → {c(agent_name.lower(), agent_name)}: {c('dim', task)}\n")
        return agent.run(task)

    if name == "create_tool":
        try:
            return registry.create(
                name        = args["name"],
                description = args["description"],
                parameters  = args["parameters"],
                code        = args["code"],
            )
        except Exception as e:
            return f"create_tool failed: {e}"

    if name == "upgrade_tool":
        try:
            return registry.upgrade(
                name        = args["name"],
                description = args.get("description"),
                parameters  = args.get("parameters"),
                code        = args.get("code"),
            )
        except Exception as e:
            return f"upgrade_tool failed: {e}"

    # Fall through to dynamic registry
    if name in registry.names():
        return registry.execute(name, args)

    return f"Unknown tool: {name}"
