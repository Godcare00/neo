#!/usr/bin/env python3
# telegram_bot.py — Telegram entry point for Neo
#
# Usage:
#   python telegram_bot.py
#
# Requires:
#   pip install python-telegram-bot
#
# .env keys needed:
#   TELEGRAM_BOT_TOKEN   — from @BotFather
#   TELEGRAM_ALLOWED_IDS — comma-separated Telegram user IDs, e.g. 123456,789012

import os
import sys
import asyncio
import logging
import re
import urllib.error
from pathlib import Path

# ── Bootstrap path so local modules resolve ──────────────────────────────────
sys.path.insert(0, os.path.dirname(__file__))

from config import WORKSPACE

# Uploads land in workspace/uploads/<user_id>/
UPLOADS_DIR = os.path.join(WORKSPACE, "uploads")

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("neo.telegram")

# ── Auth ──────────────────────────────────────────────────────────────────────

def _load_allowed_ids() -> set[int]:
    raw = os.environ.get("TELEGRAM_ALLOWED_IDS", "").strip()
    if not raw:
        return set()
    ids = set()
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            ids.add(int(part))
    return ids

# ── File path detection ───────────────────────────────────────────────────────

# Matches absolute paths or workspace-relative paths that exist on disk
_PATH_RE = re.compile(r'(?:^|\s|["\'])(/[\w/.\-]+|workspace/[\w/.\-]+)(?:\s|["\']|$)')

def _extract_sendable_files(text: str) -> list[str]:
    """Find file paths in Neo's reply that exist on disk and are sendable."""
    found = []
    for m in _PATH_RE.finditer(text):
        candidate = m.group(1)
        # Resolve workspace-relative paths
        if not candidate.startswith("/"):
            candidate = os.path.join(os.path.dirname(__file__), candidate)
        candidate = os.path.abspath(candidate)
        if os.path.isfile(candidate) and os.path.getsize(candidate) < 50 * 1024 * 1024:
            if candidate not in found:
                found.append(candidate)
    return found

# ── Message splitting ─────────────────────────────────────────────────────────

TELEGRAM_LIMIT = 4096

def _split_message(text: str) -> list[str]:
    """Split text into Telegram-safe chunks, breaking on newlines where possible."""
    if len(text) <= TELEGRAM_LIMIT:
        return [text]
    chunks = []
    while text:
        if len(text) <= TELEGRAM_LIMIT:
            chunks.append(text)
            break
        split_at = text.rfind("\n", 0, TELEGRAM_LIMIT)
        if split_at == -1:
            split_at = TELEGRAM_LIMIT
        chunks.append(text[:split_at])
        text = text[split_at:].lstrip("\n")
    return chunks

# ── Core bot logic ────────────────────────────────────────────────────────────

class NeoBot:
    def __init__(self):
        from main import build_team, init_workspace, initial_snapshot
        import main as _main

        api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
        if not api_key:
            log.error("OPENROUTER_API_KEY not set. Add it to .env.")
            sys.exit(1)

        self.token       = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
        self.allowed_ids = _load_allowed_ids()

        if not self.token:
            log.error("TELEGRAM_BOT_TOKEN not set. Add it to .env.")
            sys.exit(1)
        if not self.allowed_ids:
            log.warning("TELEGRAM_ALLOWED_IDS not set — no one can message Neo!")

        log.info(f"Authorized users: {self.allowed_ids}")

        init_workspace()
        os.makedirs(UPLOADS_DIR, exist_ok=True)

        self.neo = build_team(api_key)
        initial_snapshot(self.neo)

        # Per-user conversation histories: {user_id: [messages]}
        self._histories: dict[int, list[dict]] = {}

    def _get_history(self, user_id: int) -> list[dict]:
        if user_id not in self._histories:
            self._histories[user_id] = [
                {"role": "system", "content": self.neo.system_prompt}
            ]
        return self._histories[user_id]

    def _reset_history(self, user_id: int):
        self._histories[user_id] = [
            {"role": "system", "content": self.neo.system_prompt}
        ]

    def _rollback(self, user_id: int):
        history = self._get_history(user_id)
        while history and history[-1].get("role") != "user":
            history.pop()
        if history:
            history.pop()

    async def _neo_reply(self, user_id: int, user_content: str) -> str:
        """Run Neo in a thread (blocking) and return his reply."""
        history = self._get_history(user_id)
        history.append({"role": "user", "content": user_content})
        loop = asyncio.get_event_loop()
        try:
            reply = await loop.run_in_executor(None, self.neo.chat, history)
            history.append({"role": "assistant", "content": reply})
            return reply
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            self._rollback(user_id)
            return f"API error {e.code}: {body}"
        except Exception as e:
            self._rollback(user_id)
            return f"Error: {e}"

    # ── Telegram handlers ─────────────────────────────────────────────────────

    async def on_message(self, update, context):
        from telegram import ChatAction
        user = update.effective_user
        chat_id = update.effective_chat.id

        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            log.warning(f"Blocked unauthorized user {user.id} (@{user.username})")
            return

        text = (update.message.text or "").strip()
        if not text:
            return

        log.info(f"[{user.id}] {text[:80]}")
        await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)

        reply = await self._neo_reply(user.id, text)

        # Send text in chunks
        for chunk in _split_message(reply):
            await update.message.reply_text(chunk)

        # Send any files Neo referenced
        for fpath in _extract_sendable_files(reply):
            try:
                await context.bot.send_document(
                    chat_id=chat_id,
                    document=open(fpath, "rb"),
                    filename=os.path.basename(fpath),
                    caption=f"📎 {os.path.basename(fpath)}",
                )
                log.info(f"Sent file: {fpath}")
            except Exception as e:
                log.warning(f"Could not send file {fpath}: {e}")

    async def on_attachment(self, update, context):
        """Handle incoming files, photos, audio, video."""
        from telegram import ChatAction
        user    = update.effective_user
        chat_id = update.effective_chat.id
        msg     = update.message

        if user.id not in self.allowed_ids:
            await msg.reply_text("Unauthorized.")
            return

        await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)

        # Determine the file object and a descriptive label
        tg_file = None
        label   = "file"
        caption = (msg.caption or "").strip()

        if msg.document:
            tg_file  = await msg.document.get_file()
            label    = msg.document.file_name or "document"
        elif msg.photo:
            tg_file  = await msg.photo[-1].get_file()  # highest resolution
            label    = "photo.jpg"
        elif msg.audio:
            tg_file  = await msg.audio.get_file()
            label    = msg.audio.file_name or "audio"
        elif msg.video:
            tg_file  = await msg.video.get_file()
            label    = msg.video.file_name or "video"
        elif msg.voice:
            tg_file  = await msg.voice.get_file()
            label    = "voice.ogg"
        else:
            await msg.reply_text("Unsupported attachment type.")
            return

        # Save to workspace/uploads/<user_id>/
        user_upload_dir = os.path.join(UPLOADS_DIR, str(user.id))
        os.makedirs(user_upload_dir, exist_ok=True)
        dest = os.path.join(user_upload_dir, label)

        # Avoid overwrites by appending a counter
        if os.path.exists(dest):
            base, ext = os.path.splitext(label)
            i = 1
            while os.path.exists(dest):
                dest = os.path.join(user_upload_dir, f"{base}_{i}{ext}")
                i += 1

        await tg_file.download_to_drive(dest)
        log.info(f"[{user.id}] saved attachment -> {dest}")

        # Tell Neo about the file
        user_content = (
            f"I just sent you a file. It has been saved to: {dest}\n"
            + (f"Caption: {caption}" if caption else "Please process or acknowledge it.")
        )

        reply = await self._neo_reply(user.id, user_content)

        for chunk in _split_message(reply):
            await msg.reply_text(chunk)

        for fpath in _extract_sendable_files(reply):
            try:
                await context.bot.send_document(
                    chat_id=chat_id,
                    document=open(fpath, "rb"),
                    filename=os.path.basename(fpath),
                    caption=f"📎 {os.path.basename(fpath)}",
                )
            except Exception as e:
                log.warning(f"Could not send file {fpath}: {e}")

    async def on_reset(self, update, context):
        """Clear conversation history for this user."""
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        self._reset_history(user.id)
        await update.message.reply_text("Conversation reset.")
        log.info(f"[{user.id}] reset conversation")

    async def on_start(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        await update.message.reply_text(
            "Neo online. Send me a message or a file.\n"
            "/reset — clear conversation history\n"
            "/status — show system status"
        )

    async def on_status(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        from archive import archive
        status = archive.status()
        history_len = len(self._get_history(user.id))
        text = f"*Neo Status*\n```\n{status}\n```\nConversation turns: {history_len}"
        await update.message.reply_text(text, parse_mode="Markdown")

    # ── Run ───────────────────────────────────────────────────────────────────

    def run(self):
        try:
            from telegram.ext import (
                ApplicationBuilder, CommandHandler,
                MessageHandler, filters,
            )
        except ImportError:
            log.error(
                "python-telegram-bot is not installed.\n"
                "Run: pip install python-telegram-bot"
            )
            sys.exit(1)

        app = ApplicationBuilder().token(self.token).build()

        app.add_handler(CommandHandler("start",  self.on_start))
        app.add_handler(CommandHandler("reset",  self.on_reset))
        app.add_handler(CommandHandler("status", self.on_status))

        # Text messages
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.on_message))

        # All attachment types
        app.add_handler(MessageHandler(
            filters.Document.ALL | filters.PHOTO | filters.AUDIO |
            filters.VIDEO | filters.VOICE,
            self.on_attachment,
        ))

        log.info("Neo Telegram bot starting (long-polling)...")
        app.run_polling(drop_pending_updates=True)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    bot = NeoBot()
    bot.run()
