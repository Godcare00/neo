# tools/meta.py — create_tool and upgrade_tool schemas

CREATE_TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "create_tool",
        "description": (
            "Create a new callable Python tool and register it permanently. "
            "Supply a name, description, JSON Schema parameters, and Python code "
            "defining `run(args: dict) -> str`. The tool is immediately available."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "name":        {"type": "string", "description": "Snake_case name, must be unique."},
                "description": {"type": "string", "description": "What this tool does."},
                "parameters":  {"type": "object", "description": "JSON Schema with type/properties/required."},
                "code":        {"type": "string", "description": "Python defining `def run(args: dict) -> str`."},
            },
            "required": ["name", "description", "parameters", "code"],
        },
    },
}

UPGRADE_TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "upgrade_tool",
        "description": (
            "Upgrade an existing dynamic tool in-place. "
            "Only provided fields are updated. Use to fix bugs, improve logic, or extend parameters."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "name":        {"type": "string", "description": "Exact name of the tool to upgrade."},
                "description": {"type": "string", "description": "New description (optional)."},
                "parameters":  {"type": "object", "description": "New JSON Schema (optional)."},
                "code":        {"type": "string", "description": "New run(args) source (optional)."},
            },
            "required": ["name"],
        },
    },
}
