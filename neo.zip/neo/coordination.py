# coordination.py — structured multi-agent coordination
#
# Architecture:
#   - CoordinationContext  : shared scratchpad all agents read/write
#   - Coordinator          : LLM call that plans rounds, assigns subtasks, decides done
#   - Worker               : each assigned agent runs once per round, writes results back
#   - Hard limits          : max rounds + max agents prevent runaway loops
#
# Flow:
#   1. Neo submits a coordinated task with a list of agents to involve
#   2. Coordinator (LLM call) reads the task + context, produces a round plan:
#        { "subtasks": [{"agent": ..., "brief": ...}], "done": bool, "summary": ... }
#   3. Workers run in parallel, each with their brief + shared context as input
#   4. Results written to shared context
#   5. Repeat from step 2 until done=true or max_rounds reached
#   6. Final summary returned

import os
import json
import uuid
import threading
import datetime
import urllib.request
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from config import c, WORKSPACE, API_URL, MODEL
from json_utils import parse_llm_json as _parse_json_response

MAX_ROUNDS        = 6    # hard ceiling on coordinator rounds
MAX_AGENTS        = 4    # max agents per coordination session
MAX_WORKERS       = 8    # thread pool size for parallel worker execution
WORKER_TIMEOUT    = 300  # max seconds a single worker agent may run (5 min)


def _now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def _llm_call(system: str, user: str, api_key: str, max_tokens: int = 1500) -> str:
    """Make a single LLM call, return raw content string."""
    payload = json.dumps({
        "model":    MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user",   "content": user},
        ],
        "max_tokens": max_tokens,
    }).encode("utf-8")

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
            "HTTP-Referer":  "https://github.com/neo-agent",
            "X-Title":       "Neo - Coordinator",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        data = json.loads(resp.read().decode("utf-8"))

    raw = (data["choices"][0]["message"].get("content") or "").strip()
    return raw




# ── Shared Memory ─────────────────────────────────────────────────────────────

class CoordinationContext:
    """
    The shared scratchpad for a coordination session.
    All agents read from and write to this object.
    Thread-safe for concurrent worker access.
    """

    def __init__(self, task_id: str, goal: str, agents: list[str]):
        self.task_id    = task_id
        self.goal       = goal
        self.agents     = agents        # agent names involved
        self.round      = 0
        self.created_at = _now()

        # Shared state
        self._lock      = threading.Lock()
        self.messages   : list[dict] = []   # {round, agent, content, timestamp}
        self.artifacts  : dict[str, str] = {}  # name -> description/path
        self.decisions  : list[dict] = []   # coordinator decisions per round
        self.subtask_results: dict[str, str] = {}  # agent -> last result

    def post(self, agent: str, content: str):
        """An agent posts a message/result to shared memory."""
        with self._lock:
            self.messages.append({
                "round":     self.round,
                "agent":     agent,
                "content":   content,
                "timestamp": _now(),
            })
            self.subtask_results[agent] = content

    def add_artifact(self, name: str, description: str):
        """Register a produced artifact (file, data, etc.)."""
        with self._lock:
            self.artifacts[name] = description

    def log_decision(self, decision: dict):
        with self._lock:
            self.decisions.append({"round": self.round, **decision})

    def context_summary(self) -> str:
        """
        Render the current shared context as a readable string for agents
        and the coordinator to consume.
        """
        lines = [
            f"=== COORDINATION CONTEXT (Task {self.task_id}) ===",
            f"Goal: {self.goal}",
            f"Round: {self.round} / {MAX_ROUNDS}",
            f"Agents: {', '.join(self.agents)}",
            "",
        ]

        if self.artifacts:
            lines.append("ARTIFACTS PRODUCED:")
            for name, desc in self.artifacts.items():
                lines.append(f"  - {name}: {desc}")
            lines.append("")

        if self.messages:
            lines.append("SHARED MEMORY (agent messages this session):")
            for m in self.messages[-20:]:  # last 20 to avoid bloat
                lines.append(f"  [{m['round']}] {m['agent']}: {m['content'][:300]}")
            lines.append("")

        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "task_id":        self.task_id,
            "goal":           self.goal,
            "agents":         self.agents,
            "round":          self.round,
            "created_at":     self.created_at,
            "messages":       self.messages[-50:],
            "artifacts":      self.artifacts,
            "decisions":      self.decisions,
        }


# ── Coordinator LLM prompts ───────────────────────────────────────────────────

COORDINATOR_SYSTEM = """You are the Coordinator for a multi-agent task session.

Your job each round:
1. Review the shared context (what agents have done so far).
2. Decide what subtasks each agent should do next — OR declare the task done.
3. Return a JSON plan.

Rules:
- Each agent gets AT MOST ONE subtask per round.
- Write a complete, self-contained brief for each subtask — the agent has no memory of previous rounds except what is in the shared context.
- Include relevant file paths, artifacts, and results from previous rounds in each brief.
- If the goal is achieved, set "done": true and write a final "summary".
- If you cannot make progress (agents keep failing, missing resources, etc.), set "done": true and explain in summary.
- Never assign more than {max_agents} agents per round.
- Be decisive. Don't assign the same subtask twice if it already succeeded.

Respond with ONLY a JSON object:
{{
  "done": false,
  "summary": null,
  "subtasks": [
    {{
      "agent": "<agent name>",
      "brief": "<complete self-contained brief for this agent this round>"
    }}
  ]
}}

If done=true, set summary to a clear completion message and subtasks to [].
""".format(max_agents=MAX_AGENTS)


# ── Coordinator logic ─────────────────────────────────────────────────────────

class Coordinator:
    def __init__(self, api_key: str, agents_roster: dict):
        self.api_key       = api_key
        self.agents_roster = agents_roster  # {name: Agent}

    def plan_round(self, ctx: CoordinationContext) -> dict:
        """
        Ask the LLM coordinator to plan the next round.
        Returns {done, summary, subtasks: [{agent, brief}]}
        """
        agent_roster_str = "\n".join(
            f"  - {name}: {ag.description}"
            for name, ag in self.agents_roster.items()
            if name in ctx.agents
        )
        user_content = (
            f"{ctx.context_summary()}\n"
            f"WORKSPACE: {WORKSPACE}\n\n"
            f"AVAILABLE AGENTS THIS SESSION:\n{agent_roster_str}\n\n"
            f"Plan the next round of work, or declare done if the goal is achieved."
        )

        raw  = _llm_call(COORDINATOR_SYSTEM, user_content, self.api_key)
        plan = _parse_json_response(raw)

        # Validate + sanitize
        if not isinstance(plan.get("subtasks"), list):
            plan["subtasks"] = []
        # Remove subtasks for agents not in session
        plan["subtasks"] = [
            s for s in plan["subtasks"]
            if s.get("agent") in ctx.agents
        ][:MAX_AGENTS]

        return plan


# ── Worker execution ──────────────────────────────────────────────────────────

def _run_worker(agent_name: str, brief: str, ctx: CoordinationContext,
                agents_roster: dict) -> tuple[str, str]:
    """
    Run one worker agent for one round. Returns (agent_name, result).
    The agent gets the shared context prepended to its brief.
    """
    agent = agents_roster.get(agent_name)
    if not agent:
        return agent_name, f"[ERROR] Agent '{agent_name}' not found in roster."

    # Inject shared context into the brief so agent knows what others have done
    full_brief = (
        f"{ctx.context_summary()}\n"
        f"YOUR SUBTASK THIS ROUND:\n"
        f"{brief}\n\n"
        f"IMPORTANT:\n"
        f"  - Read any referenced files with read_file before acting on them.\n"
        f"  - Save outputs to: {WORKSPACE}\n"
        f"  - End your response with: RESULT SUMMARY: <one paragraph of what you produced>\n"
    )

    print(f"  {c('tool', 'coord')} [{ctx.task_id}] round {ctx.round} "
          f"-> {c(agent_name.lower(), agent_name)}: {c('dim', brief[:60])}\n")
    import concurrent.futures as _cf
    try:
        with _cf.ThreadPoolExecutor(max_workers=1) as _ex:
            future = _ex.submit(agent.run, full_brief)
            try:
                result = future.result(timeout=WORKER_TIMEOUT)
            except _cf.TimeoutError:
                result = f"[TIMEOUT] {agent_name} exceeded {WORKER_TIMEOUT}s limit."
                print(c("red", f"  coord [{ctx.task_id}]: {agent_name} timed out\n"))
        ctx.post(agent_name, result)
        return agent_name, result
    except Exception as e:
        err = f"[ERROR] {agent_name} failed: {e}"
        ctx.post(agent_name, err)
        return agent_name, err


# ── Main coordination runner ──────────────────────────────────────────────────

def run_coordination(task_id: str, goal: str, agent_names: list[str],
                     agents_roster: dict, api_key: str,
                     file_refs: list[str] = None) -> str:
    """
    Run a full multi-agent coordination session.

    Returns the final summary string.
    """
    # Clamp agent list
    agent_names = [n for n in agent_names if n in agents_roster][:MAX_AGENTS]
    if not agent_names:
        return "[ERROR] No valid agents specified for coordination."

    ctx         = CoordinationContext(task_id, goal, agent_names)
    coordinator = Coordinator(api_key, agents_roster)
    executor    = ThreadPoolExecutor(max_workers=MAX_WORKERS)

    # Seed context with file refs if provided
    if file_refs:
        for fp in file_refs:
            if os.path.isfile(fp):
                ctx.add_artifact(os.path.basename(fp),
                                 f"Input file: {fp} ({os.path.getsize(fp):,} bytes)")

    print(c("dim", f"  coord [{task_id}]: starting — goal: {goal[:70]}\n"
                   f"  coord [{task_id}]: agents: {', '.join(agent_names)}\n"))

    final_summary = None

    for round_num in range(1, MAX_ROUNDS + 1):
        ctx.round = round_num
        print(c("dim", f"  coord [{task_id}]: round {round_num}/{MAX_ROUNDS} — coordinator planning...\n"))

        try:
            plan = coordinator.plan_round(ctx)
        except Exception as e:
            final_summary = f"Coordinator failed in round {round_num}: {e}"
            print(c("red", f"  coord [{task_id}]: {final_summary}\n"))
            break

        ctx.log_decision(plan)

        if plan.get("done"):
            final_summary = plan.get("summary") or "Task completed."
            print(c("dim", f"  coord [{task_id}]: done — {final_summary[:80]}\n"))
            break

        subtasks = plan.get("subtasks", [])
        if not subtasks:
            final_summary = "Coordinator returned no subtasks and did not declare done."
            print(c("red", f"  coord [{task_id}]: {final_summary}\n"))
            break

        # Run all subtasks in parallel
        futures = {
            executor.submit(_run_worker, s["agent"], s["brief"], ctx, agents_roster): s
            for s in subtasks
        }
        for future in as_completed(futures):
            agent_name, result = future.result()
            status = "[OK]" if not result.startswith("[ERROR]") else "[FAIL]"
            print(c("dim", f"  coord [{task_id}]: {status} {agent_name} round {round_num}\n"))

    else:
        # Exhausted all rounds
        final_summary = (
            f"Coordination reached the maximum of {MAX_ROUNDS} rounds. "
            f"Goal: {goal[:100]}. "
            f"Last round results: "
            + "; ".join(f"{k}: {v[:100]}" for k, v in ctx.subtask_results.items())
        )
        print(c("red", f"  coord [{task_id}]: max rounds reached\n"))

    executor.shutdown(wait=True)   # wait for all in-flight workers before returning
    return final_summary or "No result."
