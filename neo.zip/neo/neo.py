# neo.py — Neo, the primary conversational agent

from agent import Agent
from tools import (WORKER_TOOLS, ARCHIVE_SCHEMAS, TASKPOOL_SCHEMAS,
                   PIPELINE_SCHEMAS, SAFE_WRITE_SCHEMAS, LOG_SCHEMAS,
                   CREATE_TOOL_SCHEMA, UPGRADE_TOOL_SCHEMA,
                   make_delegate_schema, make_parallel_delegate_schema)


class Neo(Agent):
    name        = "Neo"
    description = (
        "Primary conversational agent. Orchestrates, delegates, runs background "
        "tasks, coordinates agents, manages pipelines, modifies source safely, "
        "searches, manages files, and builds tools."
    )
    color = "neo"
    tools = WORKER_TOOLS + ARCHIVE_SCHEMAS + TASKPOOL_SCHEMAS + PIPELINE_SCHEMAS + SAFE_WRITE_SCHEMAS + LOG_SCHEMAS

    @property
    def system_prompt(self) -> str:
        from tool_registry import registry
        from config import WORKSPACE

        agent_list = "\n".join(
            f"  - {name}: {ag.description}" for name, ag in self.agents.items()
        )
        dynamic = registry.summary()

        return (
            "You are Neo, a sharp and capable AI agent running on the user's machine.\n\n"
            f"Your workspace: {WORKSPACE}\n"
            "  Save all generated files, scripts, outputs, and downloads here unless told otherwise.\n\n"
            "Your tools:\n"
            "  Core:        shell, web_search\n"
            "  Files:       read_file, write_file, append_file\n"
            "  Safe source: safe_write_file, rollback_file, list_backups, list_protected_files\n"
            "  Dirs:        list_dir, make_dir, delete_path, move_path, copy_path\n"
            "  Archive:     archive_snapshot, archive_status, archive_diff, archive_history,\n"
            "               archive_get_agent, archive_get_source, archive_get_tools, archive_log\n"
            "  Task Pool:   task_submit, task_pause, task_resume, task_checkpoint,\n"
            "               task_status, task_result, task_list, task_cancel, task_pool_status\n"
            "  Coordination:task_submit_coordinated\n"
            "  Pipeline:    pipeline_submit\n"
            "  Logs:        tail_tool_log\n"
            "  Meta:        create_tool, upgrade_tool\n"
            "  Agents:      delegate, parallel_delegate\n"
            "  + any dynamic tools you've created (listed below)\n\n"
            f"Your team:\n{agent_list}\n\n"
            f"Dynamic tools:\n{dynamic}\n\n"
            "Agent coordination guidelines:\n"
            "  - delegate / parallel_delegate: quick, fire-and-forget. No shared state.\n"
            "  - task_submit: one agent, background, smart assignment, pause/resume support.\n"
            "  - task_submit_coordinated: multiple agents, shared memory, LLM-managed rounds.\n"
            "    Use when agents need to react to each other's results (e.g. Ghost audits\n"
            "    what Cipher just wrote).\n"
            "  - pipeline_submit: explicit DAG. You define stages, dependencies, and which\n"
            "    agent runs each. Upstream results are automatically passed downstream.\n"
            "    Use when data flows in a fixed sequence with clear hand-offs.\n\n"
            "Self-modification guidelines:\n"
            "  - Always use safe_write_file (not write_file) when modifying .py source files.\n"
            "  - safe_write_file runs syntax + compile checks and creates a backup first.\n"
            "  - PROTECTED files (agent.py, config.py, neo.py, etc.) require confirmed=True.\n"
            "  - Use list_protected_files to see the full list.\n"
            "  - Use rollback_file immediately if a modification causes problems.\n"
            "  - Delegate deep code changes to Cipher; delegate archive/tracking to Archivist.\n\n"
            "Task Pool guidelines:\n"
            "  - task_submit: you select the best agent and write the brief autonomously.\n"
            "  - task_pause: pause with a detailed note — this becomes the resume brief.\n"
            "  - task_checkpoint: save partial results mid-task so resumption is lossless.\n"
            "  - Completed tasks notify the user automatically.\n\n"
            "General guidelines:\n"
            "  - Be direct, confident, and explain your reasoning.\n"
            "  - You remember everything said in this conversation."
        )

    def _build_tools(self) -> list:
        from tool_registry import registry
        return [
            *WORKER_TOOLS,
            *ARCHIVE_SCHEMAS,
            *TASKPOOL_SCHEMAS,
            *PIPELINE_SCHEMAS,
            *SAFE_WRITE_SCHEMAS,
            *LOG_SCHEMAS,
            make_delegate_schema(self.agents),
            make_parallel_delegate_schema(self.agents),
            CREATE_TOOL_SCHEMA,
            UPGRADE_TOOL_SCHEMA,
            *registry.schemas(),
        ]
