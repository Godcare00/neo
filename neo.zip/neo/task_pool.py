# task_pool.py — Neo's concurrent task pool
#
# Tasks are assigned by Neo himself via an LLM call — no keyword tables.
# Neo reads each agent's description, reasons about the task, and decides
# who gets it and what brief to give them.
#
# Supports pause/resume: a paused task stores Neo's notes on where it left
# off, and resumes with a tailored brief so the agent picks up seamlessly.
#
# Persists to workspace/tasks.json.

import os
import re
import json
import uuid
import threading
import datetime
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from enum import Enum
from config import c, WORKSPACE, API_URL, MODEL
from retry import urlopen_with_retry
from atomic_write import atomic_json

TASKS_FILE  = os.path.join(WORKSPACE, "tasks.json")
MAX_WORKERS           = 8
MAX_PERSISTED_TASKS   = 500   # keep only the last N tasks on disk


class TaskStatus(str, Enum):
    PENDING   = "pending"
    ASSIGNING = "assigning"   # Neo is choosing agent + writing brief
    RUNNING   = "running"
    PAUSED    = "paused"
    DONE      = "done"
    FAILED    = "failed"
    CANCELLED = "cancelled"


def _now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def _extract_file_refs(text: str) -> list[str]:
    """Extract file paths mentioned in text that actually exist on disk."""
    pattern = re.compile(r'(/[\w/.\-]+|workspace/[\w/.\-]+|\./[\w/.\-]+)')
    found = []
    for m in pattern.finditer(text):
        candidate = m.group(1)
        if not candidate.startswith("/"):
            candidate = os.path.join(os.path.dirname(__file__), candidate)
        candidate = os.path.abspath(candidate)
        if os.path.isfile(candidate) and candidate not in found:
            found.append(candidate)
    return found


# ── LLM-based agent selection and briefing ───────────────────────────────────

SELECTION_SYSTEM = """You are Neo's task dispatcher.
Given a task description and a roster of available agents, you must:
1. Select the single best agent for the task.
2. Write a complete, self-contained task brief for that agent.

The brief must include:
- The full task description
- Workspace path and where to save outputs
- Every confirmed file path (listed below) with sizes — instruct the agent to read_file them directly
- Clear output expectations
- An explicit instruction: "Do NOT guess or hallucinate file contents — use read_file to read every file before acting on it."

Respond with ONLY a JSON object, no markdown fences, no explanation:
{
  "agent": "<agent name>",
  "rationale": "<one sentence why this agent>",
  "brief": "<the full brief to send to the agent>"
}"""

RESUME_SYSTEM = """You are Neo's task dispatcher resuming a paused task.
Given the original task, the pause note (what was done and where work stopped),
and the agent roster, you must:
1. Select the best agent to continue (may differ from the original).
2. Write a resume brief that tells the agent exactly where to pick up.

The resume brief must include:
- What has already been done (from the pause note)
- What remains to be done
- All relevant file paths with their sizes
- The same anti-hallucination instruction: read_file everything before acting.

Respond with ONLY a JSON object:
{
  "agent": "<agent name>",
  "rationale": "<one sentence>",
  "brief": "<full resume brief>"
}"""


def _sanitize_json_string(raw: str) -> dict:
    """
    Robustly extract and clean a JSON object from an LLM response.

    Handles:
      - Markdown fences (```json ... ```)
      - content=None / empty string (tool-call responses with no text)
      - Literal control characters inside string values (tabs, newlines, etc.)
      - Truncated or otherwise malformed output — falls back to regex extraction
    """
    if not raw:
        raise ValueError("LLM returned empty content")

    # 1. Strip markdown fences
    raw = re.sub(r"^```(?:json)?\s*", "", raw.strip(), flags=re.MULTILINE)
    raw = re.sub(r"\s*```\s*$",       "", raw,          flags=re.MULTILINE)
    raw = raw.strip()

    # 2. Find the outermost { ... } block
    start = raw.find("{")
    end   = raw.rfind("}")
    if start == -1 or end == -1 or end <= start:
        raise ValueError(f"No JSON object found in response: {raw[:200]!r}")
    raw = raw[start:end + 1]

    # 3. Try parsing as-is (fast path — works when the model behaves)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass

    # 4. Sanitize literal control characters inside JSON string values
    sanitized = _escape_control_chars_in_strings(raw)
    try:
        return json.loads(sanitized)
    except json.JSONDecodeError:
        pass

    # 5. Last resort: pull the three fields we need with regex
    return _regex_extract_fields(raw)


def _escape_control_chars_in_strings(s: str) -> str:
    """
    Walk the raw JSON character-by-character and replace any literal
    control character (0x00-0x1f) that appears inside a quoted string
    with its proper JSON escape sequence.  Leaves structural whitespace
    (spaces, newlines between tokens) untouched.
    """
    result    = []
    in_string = False
    i         = 0
    while i < len(s):
        ch = s[i]
        if in_string:
            if ch == "\\":
                # Consume escape sequence as-is
                result.append(ch)
                i += 1
                if i < len(s):
                    result.append(s[i])
            elif ch == '"':
                in_string = False
                result.append(ch)
            elif ord(ch) < 0x20:
                # Literal control char inside a string — escape it
                _escapes = {"\t": "\\t", "\n": "\\n", "\r": "\\r"}
                result.append(_escapes.get(ch, f"\\u{ord(ch):04x}"))
            else:
                result.append(ch)
        else:
            if ch == '"':
                in_string = True
            result.append(ch)
        i += 1
    return "".join(result)


def _regex_extract_fields(raw: str) -> dict:
    """
    Last-resort field extraction when json.loads fails even after sanitization.
    Pulls agent / rationale / brief using regex on the raw string.
    """
    def _get(key):
        m = re.search(
            rf'"{key}"\s*:\s*"((?:[^"\\]|\\.)*)"',
            raw, re.DOTALL
        )
        return m.group(1) if m else ""

    agent     = _get("agent").strip()
    rationale = _get("rationale").strip()
    brief     = _get("brief").strip()

    if not agent:
        raise ValueError(f"Could not extract agent from response: {raw[:300]!r}")
    return {"agent": agent, "rationale": rationale, "brief": brief}


def _llm_select(task_description: str, agents: dict, file_refs: list[str],
                api_key: str, pause_note: str = None) -> dict:
    """
    Ask the LLM to pick the best agent and write a brief.
    Returns {agent, rationale, brief}.

    Fault-tolerant: handles None/empty content, literal control characters
    in JSON string values, markdown fences, truncated output, and tool-call
    responses that carry no text content.
    """
    agent_roster = "\n".join(
        f"  - {name}: {ag.description}" for name, ag in agents.items()
    )

    file_section = ""
    if file_refs:
        file_lines = "\n".join(
            f"  - {fp}  ({os.path.getsize(fp):,} bytes)"
            for fp in file_refs if os.path.isfile(fp)
        )
        file_section = f"\nCONFIRMED FILES ON DISK:\n{file_lines}"

    if pause_note:
        user_content = (
            f"ORIGINAL TASK:\n{task_description}\n\n"
            f"PAUSE NOTE (what was done / where we stopped):\n{pause_note}\n\n"
            f"WORKSPACE: {WORKSPACE}{file_section}\n\n"
            f"AGENT ROSTER:\n{agent_roster}"
        )
        system = RESUME_SYSTEM
    else:
        user_content = (
            f"TASK:\n{task_description}\n\n"
            f"WORKSPACE: {WORKSPACE}{file_section}\n\n"
            f"AGENT ROSTER:\n{agent_roster}"
        )
        system = SELECTION_SYSTEM

    payload = json.dumps({
        "model":    MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user",   "content": user_content},
        ],
        "max_tokens": 1200,
    }).encode("utf-8")

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type":  "application/json",
            "HTTP-Referer":  "https://github.com/neo-agent",
            "X-Title":       "Neo - TaskDispatcher",
        },
        method="POST",
    )

    raw  = urlopen_with_retry(req, timeout=60)
    data = json.loads(raw.decode("utf-8"))

    # Safely extract content — may be None if model returned a tool-call
    message = data["choices"][0]["message"]
    raw     = message.get("content") or ""

    # If empty but tool_calls exist, try extracting from the arguments blob
    if not raw and message.get("tool_calls"):
        for tc in message["tool_calls"]:
            args = tc.get("function", {}).get("arguments", "")
            if args:
                raw = args
                break

    return _sanitize_json_string(raw)


# ── Task ──────────────────────────────────────────────────────────────────────

class Task:
    def __init__(self, description: str, submitted_by: str = "user", priority: int = 5):
        self.id              = str(uuid.uuid4())[:8]
        self.description     = description
        self.submitted_by    = submitted_by
        self.priority        = priority
        self.assigned_agent  : str        = None
        self.assignment_rationale: str    = None   # why Neo picked this agent
        self.brief           : str        = None   # the brief Neo wrote
        self.status          : TaskStatus = TaskStatus.PENDING
        self.result          : str        = None
        self.error           : str        = None
        self.created_at      : str        = _now()
        self.started_at      : str        = None
        self.finished_at     : str        = None
        self.paused_at       : str        = None
        self.resumed_at      : str        = None
        self.file_refs       : list       = []
        self.pause_note      : str        = None   # written by whoever pauses
        self.progress_log    : list       = []     # [{timestamp, note}]
        self.checkpoint      : str        = None   # last saved intermediate result

    def log_progress(self, note: str):
        self.progress_log.append({"timestamp": _now(), "note": note})

    def to_dict(self) -> dict:
        return {
            "id":                   self.id,
            "description":          self.description,
            "submitted_by":         self.submitted_by,
            "priority":             self.priority,
            "assigned_agent":       self.assigned_agent,
            "assignment_rationale": self.assignment_rationale,
            "brief":                self.brief,
            "status":               self.status.value,
            "result":               self.result,
            "error":                self.error,
            "created_at":           self.created_at,
            "started_at":           self.started_at,
            "finished_at":          self.finished_at,
            "paused_at":            self.paused_at,
            "resumed_at":           self.resumed_at,
            "file_refs":            self.file_refs,
            "pause_note":           self.pause_note,
            "progress_log":         self.progress_log,
            "checkpoint":           self.checkpoint,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Task":
        t = cls.__new__(cls)
        t.__dict__.update(d)
        t.status       = TaskStatus(d["status"])
        t.file_refs    = d.get("file_refs", [])
        t.progress_log = d.get("progress_log", [])
        return t


# ── Task Pool ─────────────────────────────────────────────────────────────────

class TaskPool:
    def __init__(self):
        self._tasks:   dict[str, Task] = {}
        self._busy:    set[str]        = set()
        self._lock     = threading.Lock()
        self._executor = ThreadPoolExecutor(max_workers=MAX_WORKERS,
                                            thread_name_prefix="neo-task")
        self._agents:  dict  = {}
        self._api_key: str   = ""
        self._on_done        = None

        os.makedirs(WORKSPACE, exist_ok=True)
        self._load()

    def set_agents(self, agents: dict):
        self._agents = agents

    def set_api_key(self, api_key: str):
        self._api_key = api_key

    def set_on_done(self, callback):
        self._on_done = callback

    # ── Persistence ───────────────────────────────────────────────────────────

    def _load(self):
        if not os.path.exists(TASKS_FILE):
            return
        try:
            with open(TASKS_FILE) as f:
                saved = json.load(f)
            for d in saved:
                t = Task.from_dict(d)
                if t.status in (TaskStatus.RUNNING, TaskStatus.ASSIGNING):
                    t.status      = TaskStatus.FAILED
                    t.error       = "Interrupted by restart"
                    t.finished_at = _now()
                    t.log_progress("Interrupted by process restart")
                self._tasks[t.id] = t
            if self._tasks:
                active = sum(1 for t in self._tasks.values()
                             if t.status in (TaskStatus.PENDING, TaskStatus.RUNNING,
                                             TaskStatus.PAUSED))
                print(c("dim", f"  task pool: {len(self._tasks)} tasks loaded "
                                f"({active} pending/running/paused)\n"))
        except Exception as e:
            print(c("red", f"  task pool: load error: {e}\n"))

    def _save(self):
        try:
            tasks = list(self._tasks.values())
            # Keep all active tasks; prune oldest terminal ones if over cap
            active   = [t for t in tasks if t.status.value
                        in ("pending","assigning","running","paused")]
            terminal = [t for t in tasks if t.status.value
                        not in ("pending","assigning","running","paused")]
            terminal.sort(key=lambda t: t.created_at)
            keep = active + terminal[-(MAX_PERSISTED_TASKS - len(active)):]
            atomic_json(TASKS_FILE, [t.to_dict() for t in keep])
        except Exception as e:
            print(c("red", f"  task pool: save error: {e}"))

    # ── Submission ────────────────────────────────────────────────────────────

    def submit(self, description: str, submitted_by: str = "neo",
               priority: int = 5) -> Task:
        task           = Task(description, submitted_by, priority)
        task.file_refs = _extract_file_refs(description)

        with self._lock:
            self._tasks[task.id] = task
            self._save()

        self._executor.submit(self._run_task, task.id)
        print(c("dim", f"  task {task.id}: queued — '{description[:60]}'\n"))
        return task

    # ── Pause ─────────────────────────────────────────────────────────────────

    def pause(self, task_id: str, pause_note: str) -> str:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return f"Task {task_id} not found."
            if task.status not in (TaskStatus.PENDING, TaskStatus.RUNNING,
                                   TaskStatus.ASSIGNING):
                return f"Task {task_id} is {task.status.value} — cannot pause."
            task.pause_note = pause_note
            task.status     = TaskStatus.PAUSED
            task.paused_at  = _now()
            self._busy.discard(task.assigned_agent or "")
            task.log_progress(f"Paused: {pause_note}")
            self._save()
        print(c("dim", f"  task {task_id}: paused\n"))
        return f"Task {task_id} paused. Resume with task_resume."

    # ── Resume ────────────────────────────────────────────────────────────────

    def resume(self, task_id: str, additional_context: str = "") -> str:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return f"Task {task_id} not found."
            if task.status != TaskStatus.PAUSED:
                return f"Task {task_id} is {task.status.value} — only paused tasks can be resumed."
            task.status     = TaskStatus.PENDING
            task.resumed_at = _now()
            if additional_context:
                task.pause_note = (task.pause_note or "") + f"\n\nAdditional context: {additional_context}"
            task.log_progress("Resumed")
            self._save()

        self._executor.submit(self._run_task, task.id, is_resume=True)
        print(c("dim", f"  task {task_id}: resuming\n"))
        return f"Task {task_id} queued for resumption."

    # ── Execution ─────────────────────────────────────────────────────────────

    def _run_task(self, task_id: str, is_resume: bool = False):
        # ── Phase 1: mark as ASSIGNING ────────────────────────────────────────
        with self._lock:
            task = self._tasks.get(task_id)
            if not task or task.status == TaskStatus.CANCELLED:
                return
            task.status = TaskStatus.ASSIGNING
            self._save()

        print(c("dim", f"  task {task.id}: Neo selecting agent...\n"))

        # LLM selection happens outside the lock (it's a slow network call)
        try:
            decision = _llm_select(
                task_description = task.description,
                agents           = self._agents,
                file_refs        = task.file_refs,
                api_key          = self._api_key,
                pause_note       = task.pause_note if is_resume else None,
            )
            raw_name = decision["agent"]
        except Exception as e:
            with self._lock:
                task.status      = TaskStatus.FAILED
                task.error       = f"Agent selection failed: {e}"
                task.finished_at = _now()
                if task.assigned_agent:
                    self._busy.discard(task.assigned_agent)
                task.log_progress(f"Selection failed: {e}")
                self._save()
            print(c("red", f"  task {task.id}: selection failed — {e}\n"))
            self._fire_callback(task)
            return

        # ── Phase 2: validate agent + mark busy atomically ────────────────────
        # Both the agent-name validation and _busy.add() happen inside the same
        # lock acquisition so no other thread can steal the same agent between
        # the check and the add.
        with self._lock:
            if raw_name not in self._agents:
                # LLM hallucinated — pick best available
                raw_name = next(
                    (n for n in self._agents if n not in self._busy),
                    list(self._agents.keys())[0]
                )
                decision["rationale"] = (
                    f"(fallback — LLM suggested unknown agent) "
                    f"{decision.get('rationale','')}"
                )
            agent_name = raw_name
            task.assigned_agent        = agent_name
            task.assignment_rationale  = decision.get("rationale", "")
            task.brief                 = decision.get("brief", task.description)
            task.status                = TaskStatus.RUNNING
            task.started_at            = task.started_at or _now()
            self._busy.add(agent_name)
            task.log_progress(f"Assigned to {agent_name}: {task.assignment_rationale}")
            self._save()

        agent = self._agents[agent_name]
        print(f"  {c('tool', 'task')} {c('dim', task.id)} -> "
              f"{c(agent_name.lower(), agent_name)}: "
              f"{c('dim', task.description[:50])}\n"
              f"  {c('dim', 'rationale:')} {c('dim', task.assignment_rationale)}\n")

        try:
            result = agent.run(task.brief)
            with self._lock:
                task.result      = result
                task.status      = TaskStatus.DONE
                task.finished_at = _now()
                self._busy.discard(agent_name)
                task.log_progress("Completed successfully")
                self._save()
            print(c("dim", f"  task {task.id}: done ({agent_name})\n"))

        except Exception as e:
            with self._lock:
                task.error       = str(e)
                task.status      = TaskStatus.FAILED
                task.finished_at = _now()
                self._busy.discard(agent_name)
                task.log_progress(f"Failed: {e}")
                self._save()
            print(c("red", f"  task {task.id}: failed — {e}\n"))

        self._fire_callback(task)

    def _fire_callback(self, task: Task):
        if self._on_done:
            try:
                self._on_done(task)
            except Exception:
                pass


    def submit_coordinated(self, goal: str, agent_names: list,
                           submitted_by: str = "neo", priority: int = 5) -> "Task":
        """
        Submit a task that runs as a multi-agent coordination session.
        The coordination engine manages rounds, shared memory, and completion.
        """
        from coordination import run_coordination

        description = f"[COORDINATED] {goal}"
        task        = Task(description, submitted_by, priority)
        task.file_refs = _extract_file_refs(goal)

        # Store the coordination config inside the task for the runner
        task._coord_agents = agent_names
        task._coord_goal   = goal

        with self._lock:
            self._tasks[task.id] = task
            self._save()

        self._executor.submit(self._run_coordinated_task, task.id)
        print(c("dim", f"  task {task.id}: coordinated task queued — {len(agent_names)} agents\n"))
        return task

    def _run_coordinated_task(self, task_id: str):
        """Background runner for coordinated tasks."""
        from coordination import run_coordination

        with self._lock:
            task = self._tasks.get(task_id)
            if not task or task.status == TaskStatus.CANCELLED:
                return
            task.status     = TaskStatus.RUNNING
            task.started_at = _now()
            # Mark all coord agents as busy
            for name in getattr(task, '_coord_agents', []):
                self._busy.add(name)
            task.log_progress(f"Coordinated session starting with agents: "
                              f"{getattr(task, '_coord_agents', [])}")
            self._save()

        try:
            result = run_coordination(
                task_id       = task.id,
                goal          = getattr(task, '_coord_goal', task.description),
                agent_names   = getattr(task, '_coord_agents', []),
                agents_roster = self._agents,
                api_key       = self._api_key,
                file_refs     = task.file_refs,
            )
            with self._lock:
                task.result      = result
                task.status      = TaskStatus.DONE
                task.finished_at = _now()
                for name in getattr(task, '_coord_agents', []):
                    self._busy.discard(name)
                task.log_progress("Coordination session completed")
                self._save()
            print(c("dim", f"  task {task.id}: coordinated task done\n"))

        except Exception as e:
            with self._lock:
                task.error       = str(e)
                task.status      = TaskStatus.FAILED
                task.finished_at = _now()
                for name in getattr(task, '_coord_agents', []):
                    self._busy.discard(name)
                task.log_progress(f"Coordination failed: {e}")
                self._save()
            print(c("red", f"  task {task.id}: coordinated task failed — {e}\n"))

        self._fire_callback(task)


    # ── Query ─────────────────────────────────────────────────────────────────


    def submit_pipeline(self, goal: str, stages_def: list,
                        submitted_by: str = "neo", priority: int = 5) -> "Task":
        from pipeline import run_pipeline
        description = f"[PIPELINE] {goal}"
        task        = Task(description, submitted_by, priority)
        task.file_refs = _extract_file_refs(goal)
        task._pipeline_stages_def = stages_def
        task._pipeline_goal       = goal
        with self._lock:
            self._tasks[task.id] = task
            self._save()
        self._executor.submit(self._run_pipeline_task, task.id)
        print(c("dim", f"  task {task.id}: pipeline queued -- {len(stages_def)} stages\n"))
        return task

    def _run_pipeline_task(self, task_id: str):
        from pipeline import run_pipeline
        with self._lock:
            task = self._tasks.get(task_id)
            if not task or task.status == TaskStatus.CANCELLED:
                return
            task.status     = TaskStatus.RUNNING
            task.started_at = _now()
            task.log_progress(f"Pipeline starting: {len(getattr(task, '_pipeline_stages_def', []))} stages")
            self._save()
        try:
            result = run_pipeline(
                pipeline_id   = task.id,
                goal          = getattr(task, "_pipeline_goal", task.description),
                stages_def    = getattr(task, "_pipeline_stages_def", []),
                agents_roster = self._agents,
                api_key       = self._api_key,
                file_refs     = task.file_refs,
            )
            with self._lock:
                task.result      = result
                task.status      = TaskStatus.DONE
                task.finished_at = _now()
                task.log_progress("Pipeline completed")
                self._save()
            print(c("dim", f"  task {task.id}: pipeline done\n"))
        except Exception as e:
            with self._lock:
                task.error       = str(e)
                task.status      = TaskStatus.FAILED
                task.finished_at = _now()
                task.log_progress(f"Pipeline failed: {e}")
                self._save()
            print(c("red", f"  task {task.id}: pipeline failed -- {e}\n"))
        self._fire_callback(task)

    def get(self, task_id: str) -> Task | None:
        return self._tasks.get(task_id)

    def list_tasks(self, status: str = None, last_n: int = 20) -> list[Task]:
        tasks = sorted(self._tasks.values(), key=lambda t: t.created_at, reverse=True)
        if status:
            tasks = [t for t in tasks if t.status.value == status]
        return tasks[:last_n]

    def cancel(self, task_id: str) -> str:
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return f"Task {task_id} not found."
            if task.status == TaskStatus.RUNNING:
                return f"Task {task_id} is running — cannot cancel mid-execution. Use task_pause first."
            if task.status not in (TaskStatus.PENDING, TaskStatus.ASSIGNING, TaskStatus.PAUSED):
                return f"Task {task_id} is {task.status.value} — nothing to cancel."
            task.status      = TaskStatus.CANCELLED
            task.finished_at = _now()
            task.log_progress("Cancelled")
            self._save()
        return f"Task {task_id} cancelled."

    def add_checkpoint(self, task_id: str, checkpoint: str) -> str:
        """Store intermediate progress so a resumed task can continue from here."""
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return f"Task {task_id} not found."
            task.checkpoint = checkpoint
            task.log_progress(f"Checkpoint saved: {checkpoint[:80]}")
            self._save()
        return f"Checkpoint saved for task {task_id}."

    def status_summary(self) -> str:
        counts = {s: 0 for s in TaskStatus}
        for t in self._tasks.values():
            counts[t.status] += 1
        return (
            f"pending={counts[TaskStatus.PENDING]}  "
            f"assigning={counts[TaskStatus.ASSIGNING]}  "
            f"running={counts[TaskStatus.RUNNING]}  "
            f"paused={counts[TaskStatus.PAUSED]}  "
            f"done={counts[TaskStatus.DONE]}  "
            f"failed={counts[TaskStatus.FAILED]}  "
            f"cancelled={counts[TaskStatus.CANCELLED]}"
        )

    def format_task(self, task: Task, full: bool = False) -> str:
        icons = {"pending":"⏳","assigning":"🤔","running":"⚙",
                 "paused":"⏸","done":"✓","failed":"✗","cancelled":"⊘"}
        icon  = icons.get(task.status.value, "?")
        lines = [
            f"{icon} [{task.id}] {task.status.value.upper()}",
            f"  Task:      {task.description[:120]}",
            f"  Agent:     {task.assigned_agent or 'unassigned'}",
        ]
        if task.assignment_rationale:
            lines.append(f"  Rationale: {task.assignment_rationale}")
        lines.append(f"  Created:   {task.created_at}")
        if task.started_at:
            lines.append(f"  Started:   {task.started_at}")
        if task.paused_at:
            lines.append(f"  Paused:    {task.paused_at}")
        if task.resumed_at:
            lines.append(f"  Resumed:   {task.resumed_at}")
        if task.finished_at:
            lines.append(f"  Finished:  {task.finished_at}")
        if task.file_refs:
            lines.append(f"  Files:     {', '.join(task.file_refs)}")
        if task.pause_note:
            lines.append(f"  Pause note:{task.pause_note[:200]}")
        if task.checkpoint:
            lines.append(f"  Checkpoint:{task.checkpoint[:200]}")
        if full:
            if task.progress_log:
                lines.append("\n  Progress log:")
                for entry in task.progress_log:
                    lines.append(f"    [{entry['timestamp']}] {entry['note']}")
            if task.brief:
                lines.append(f"\n  Brief (sent to agent):\n{task.brief[:600]}")
            if task.result:
                lines.append(f"\n  Result:\n{task.result}")
            elif task.error:
                lines.append(f"\n  Error: {task.error}")
        return "\n".join(lines)


    def shutdown(self, wait: bool = True):
        """Gracefully shut down the executor. Call on process exit."""
        try:
            self._executor.shutdown(wait=wait, cancel_futures=not wait)
            print(c("dim", "  task pool: shutdown complete\n"))
        except Exception as e:
            print(c("red", f"  task pool: shutdown error: {e}\n"))


# Singleton
task_pool = TaskPool()
