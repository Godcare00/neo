# conversation_store.py — persistent conversation history
#
# Saves and loads per-user (or per-session) message histories to
# workspace/conversations/<user_id>.json so context survives restarts.
#
# Message histories include the system prompt as their first entry.
# On load, the system prompt is replaced with the current live one
# so config changes take effect without manual clearing.

import os
import json
import datetime
import threading
from config import WORKSPACE
from atomic_write import atomic_json

CONV_DIR      = os.path.join(WORKSPACE, "conversations")
MAX_MESSAGES  = 200   # cap per user to avoid unbounded growth
_lock         = threading.Lock()


def _path(user_id: str) -> str:
    return os.path.join(CONV_DIR, f"{user_id}.json")


def _now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def load(user_id: str, system_prompt: str) -> list[dict]:
    """
    Load conversation history for user_id.
    Always uses the current system_prompt (config changes apply immediately).
    Returns a fresh history if none exists.
    """
    os.makedirs(CONV_DIR, exist_ok=True)
    path = _path(user_id)
    try:
        with _lock:
            with open(path) as f:
                data = json.load(f)
        messages = data.get("messages", [])
        # Always replace the stored system prompt with the live one
        if messages and messages[0].get("role") == "system":
            messages[0]["content"] = system_prompt
        elif not messages:
            messages = [{"role": "system", "content": system_prompt}]
        else:
            messages.insert(0, {"role": "system", "content": system_prompt})
        return messages
    except (FileNotFoundError, json.JSONDecodeError):
        return [{"role": "system", "content": system_prompt}]


def save(user_id: str, messages: list[dict]):
    """Persist the current message history for user_id."""
    os.makedirs(CONV_DIR, exist_ok=True)
    # Trim to cap before saving
    trimmed = _trim(messages)
    data = {
        "user_id":    str(user_id),
        "updated_at": _now(),
        "messages":   trimmed,
    }
    path = _path(user_id)
    try:
        with _lock:
            atomic_json(path, data)
    except Exception:
        pass   # persistence failure must never crash the agent


def clear(user_id: str, system_prompt: str) -> list[dict]:
    """Delete stored history and return a fresh conversation."""
    path = _path(user_id)
    try:
        with _lock:
            if os.path.exists(path):
                os.remove(path)
    except Exception:
        pass
    return [{"role": "system", "content": system_prompt}]


def _trim(messages: list[dict]) -> list[dict]:
    """Keep system prompt + last MAX_MESSAGES-1 non-system messages."""
    system = [m for m in messages if m.get("role") == "system"][:1]
    rest   = [m for m in messages if m.get("role") != "system"]
    return system + rest[-(MAX_MESSAGES - 1):]


def list_users() -> list[str]:
    """Return all user IDs that have stored conversations."""
    try:
        return [f[:-5] for f in os.listdir(CONV_DIR) if f.endswith(".json")]
    except FileNotFoundError:
        return []
