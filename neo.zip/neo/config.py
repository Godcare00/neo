# config.py — shared constants and terminal colors

API_URL = "https://openrouter.ai/api/v1/chat/completions"
MODEL   = "arcee-ai/trinity-large-preview:free"

COLORS = {
    "neo":      "\033[96m",   # Cyan      — Neo
    "morpheus": "\033[95m",   # Magenta   — Morpheus
    "user":     "\033[92m",   # Green     — user input
    "tool":     "\033[93m",   # Yellow    — tool calls
    "out":      "\033[2m",    # Dim       — tool output
    "dim":      "\033[2m",    # Dim       — misc subtle text
    "bold":     "\033[1m",    # Bold
    "reset":    "\033[0m",    # Reset
    "red":      "\033[91m",   # Red       — errors
}

def c(color: str, text: str) -> str:
    return f"{COLORS.get(color, '')}{text}{COLORS['reset']}"
