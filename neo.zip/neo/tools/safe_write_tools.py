# tools/safe_write_tools.py — safe source file modification tools

from config import c

SAFE_WRITE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "safe_write_file",
        "description": (
            "Write content to a file with full safety checks for Python source files. "
            "For .py files: runs syntax check (ast.parse) and compile check (py_compile) "
            "before writing. Creates a timestamped backup of any existing file. "
            "PROTECTED core files (agent.py, config.py, neo.py, task_pool.py, etc.) "
            "require confirmed=true. "
            "Non-.py files are written directly without checks. "
            "Use this instead of write_file whenever modifying source code."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "File path to write. Relative paths resolve to workspace.",
                },
                "content": {
                    "type": "string",
                    "description": "Full content to write.",
                },
                "confirmed": {
                    "type": "boolean",
                    "description": (
                        "Must be true to write PROTECTED core files. "
                        "Do not set true unless you have carefully verified the content. "
                        "Default: false."
                    ),
                    "default": False,
                },
            },
            "required": ["path", "content"],
        },
    },
}

ROLLBACK_SCHEMA = {
    "type": "function",
    "function": {
        "name": "rollback_file",
        "description": (
            "Restore a source file from its most recent backup. "
            "Use immediately if a safe_write produced a broken file."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Path of the file to roll back.",
                },
            },
            "required": ["path"],
        },
    },
}

LIST_BACKUPS_SCHEMA = {
    "type": "function",
    "function": {
        "name": "list_backups",
        "description": "List available source file backups. Optionally filter by file name.",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "File path to filter backups for (optional — omit for all).",
                },
            },
            "required": [],
        },
    },
}

PROTECTED_FILES_SCHEMA = {
    "type": "function",
    "function": {
        "name": "list_protected_files",
        "description": "List all files that require confirmed=true to modify via safe_write_file.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

ALL_SCHEMAS = [
    SAFE_WRITE_SCHEMA,
    ROLLBACK_SCHEMA,
    LIST_BACKUPS_SCHEMA,
    PROTECTED_FILES_SCHEMA,
]


def execute(name: str, args: dict) -> str:
    from safe_write import (safe_write_file, rollback_file,
                            list_backups, PROTECTED_FILES, SafeWriteError)

    print(f"  {c('tool', name)}: {c('dim', str(args)[:80])}")

    try:
        if name == "safe_write_file":
            result = safe_write_file(
                path      = args["path"],
                content   = args["content"],
                confirmed = args.get("confirmed", False),
            )

        elif name == "rollback_file":
            result = rollback_file(args["path"])

        elif name == "list_backups":
            result = list_backups(args.get("path"))

        elif name == "list_protected_files":
            result = (
                "Protected files (require confirmed=True to modify):\n"
                + "\n".join(f"  - {f}" for f in sorted(PROTECTED_FILES))
            )

        else:
            result = f"Unknown safe_write tool: {name}"

    except SafeWriteError as e:
        result = f"BLOCKED: {e}"
        print(c("red", f"    {str(e)[:200]}\n"))
        return result

    except Exception as e:
        result = f"Error in {name}: {e}"
        print(c("red", f"    {result}\n"))
        return result

    lines   = result.splitlines()
    preview = "\n".join(f"    {l}" for l in lines[:10])
    if len(lines) > 10:
        preview += f"\n    {c('dim', f'... ({len(lines)-10} more lines)')}"
    print(c("out", preview) + "\n")
    return result
