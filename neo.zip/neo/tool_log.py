# tool_log.py — append-only JSONL tool call log
#
# Every tool call (name, args, result, agent, timestamp) is appended to
# workspace/tool_calls.jsonl. This gives a persistent, grep-able audit trail
# for debugging agent runs long after the terminal has scrolled.
#
# The log is capped at MAX_LOG_LINES to prevent unbounded growth.

import os
import json
import datetime
import threading
from config import WORKSPACE

LOG_FILE      = os.path.join(WORKSPACE, "tool_calls.jsonl")
MAX_LOG_LINES = 10_000
_lock       = threading.Lock()   # protects append writes
_trim_lock  = threading.Lock()   # protects read-rewrite during trim


def _now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


def log_call(tool: str, args: dict, result: str, agent: str = "unknown"):
    """Append one tool call record to the log file."""
    record = {
        "ts":     _now(),
        "agent":  agent,
        "tool":   tool,
        "args":   {k: str(v)[:200] for k, v in args.items()},
        "result": result[:500] if result else "",
    }
    try:
        os.makedirs(WORKSPACE, exist_ok=True)
        with _lock:
            with open(LOG_FILE, "a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        # Trim outside the lock — it's a background cleanup, not latency-critical.
        # A small race on line count is acceptable; we just avoid blocking writers.
        _trim_if_needed()
    except Exception:
        pass   # logging must never crash the agent


def _trim_if_needed():
    """Trim to MAX_LOG_LINES using its own separate lock.
    Called outside _lock so writers are never blocked by trim I/O."""
    try:
        with _trim_lock:
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
            if len(lines) > MAX_LOG_LINES:
                from atomic_write import atomic_text
                atomic_text(LOG_FILE, "".join(lines[-MAX_LOG_LINES:]))
    except Exception:
        pass


def tail(n: int = 50) -> str:
    """Return the last n tool call records as formatted text."""
    try:
        with _lock:
            with open(LOG_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
        recent = lines[-n:]
        if not recent:
            return "Tool log is empty."
        rows = []
        for line in recent:
            try:
                r = json.loads(line)
                rows.append(
                    f"[{r['ts']}] {r['agent']}.{r['tool']}("
                    + ", ".join(f"{k}={v!r:.40}" for k, v in r["args"].items())
                    + f") -> {r['result'][:80]!r}"
                )
            except Exception:
                rows.append(line.strip())
        return "\n".join(rows)
    except FileNotFoundError:
        return "Tool log not found."
    except Exception as e:
        return f"Error reading tool log: {e}"
