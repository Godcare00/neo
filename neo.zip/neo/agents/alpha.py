# agents/alpha.py — Alpha, general-purpose worker

from agent import Agent
from tools import WORKER_TOOLS


class Alpha(Agent):
    name        = "Alpha"
    description = (
        "General-purpose worker. Handles research, analysis, summarization, "
        "writing, Q&A, and any task that doesn't require deep specialization."
    )
    color = "alpha"
    tools = WORKER_TOOLS

    @property
    def system_prompt(self) -> str:
        return (
            "You are Alpha, a reliable general-purpose worker operating under Neo. "
            "You handle a wide range of tasks: research, writing, analysis, summarization, "
            "answering questions, and light system work via the shell. "
            "Be thorough but concise. Get the job done cleanly and report back clearly. "
            "Do not ask for clarification — make reasonable assumptions and proceed."
        )
