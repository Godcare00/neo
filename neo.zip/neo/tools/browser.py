# tools/browser.py — browser automation tools via Playwright
#
# Requires: pip install playwright && playwright install chromium
#
# A single Browser singleton manages one persistent browser context
# across all tool calls within a session. The browser agent can open
# pages, interact with elements, extract content, and take screenshots.

import os
import base64
import atexit
import threading
from config import c

# ── Lazy Playwright singleton ─────────────────────────────────────────────────

_lock    = threading.Lock()
_browser = None   # playwright Browser instance
_page    = None   # active Page instance
_pw      = None   # Playwright instance


def _get_page():
    """Return the active page, launching the browser if needed."""
    global _browser, _page, _pw
    with _lock:
        if _page is None:
            try:
                from playwright.sync_api import sync_playwright
            except ImportError:
                raise RuntimeError(
                    "Playwright is not installed. Run:\n"
                    "  pip install playwright\n"
                    "  playwright install chromium"
                )
            _pw      = sync_playwright().start()
            _browser = _pw.chromium.launch(headless=True)
            _page    = _browser.new_page()
            _page.set_extra_http_headers({"User-Agent": "Mozilla/5.0 (neo-agent)"})
        return _page


def _close_browser():
    global _browser, _page, _pw
    with _lock:
        if _page:
            try: _page.close()
            except: pass
            _page = None
        if _browser:
            try: _browser.close()
            except: pass
            _browser = None
        if _pw:
            try: _pw.stop()
            except: pass
            _pw = None


# Register cleanup on process exit so Chromium doesn't leak
atexit.register(_close_browser)


# ── Schemas ───────────────────────────────────────────────────────────────────

NAVIGATE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_navigate",
        "description": "Navigate the browser to a URL and return the page title and current URL.",
        "parameters": {
            "type": "object",
            "properties": {
                "url":     {"type": "string",  "description": "URL to navigate to."},
                "timeout": {"type": "integer", "description": "Timeout in ms (default 30000)."},
            },
            "required": ["url"],
        },
    },
}

EXTRACT_TEXT_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_extract_text",
        "description": (
            "Extract visible text content from the current page or a specific element. "
            "Use after navigating to a page to read its content."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "selector": {
                    "type": "string",
                    "description": "CSS selector to extract text from (default: body).",
                },
                "max_chars": {
                    "type": "integer",
                    "description": "Max characters to return (default: 8000).",
                },
            },
            "required": [],
        },
    },
}

CLICK_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_click",
        "description": "Click an element on the current page by CSS selector or visible text.",
        "parameters": {
            "type": "object",
            "properties": {
                "selector": {"type": "string", "description": "CSS selector of the element to click."},
                "text":     {"type": "string", "description": "Visible text of the element to click (alternative to selector)."},
            },
            "required": [],
        },
    },
}

TYPE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_type",
        "description": "Type text into an input field on the current page.",
        "parameters": {
            "type": "object",
            "properties": {
                "selector": {"type": "string", "description": "CSS selector of the input field."},
                "text":     {"type": "string", "description": "Text to type."},
                "clear":    {"type": "boolean","description": "Clear existing content first (default: true)."},
            },
            "required": ["selector", "text"],
        },
    },
}

SCREENSHOT_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_screenshot",
        "description": (
            "Take a screenshot of the current page and save it to a file. "
            "Returns the file path. Useful for verifying page state."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "path":     {"type": "string",  "description": "File path to save the screenshot (default: screenshot.png)."},
                "full_page":{"type": "boolean", "description": "Capture full scrollable page (default: false)."},
            },
            "required": [],
        },
    },
}

SCROLL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_scroll",
        "description": "Scroll the page up or down by a number of pixels.",
        "parameters": {
            "type": "object",
            "properties": {
                "direction": {"type": "string",  "enum": ["up", "down"], "description": "Scroll direction."},
                "pixels":    {"type": "integer", "description": "Pixels to scroll (default: 500)."},
            },
            "required": ["direction"],
        },
    },
}

EVAL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_eval",
        "description": "Execute JavaScript in the current page context and return the result.",
        "parameters": {
            "type": "object",
            "properties": {
                "script": {"type": "string", "description": "JavaScript expression or statement to evaluate."},
            },
            "required": ["script"],
        },
    },
}

BACK_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_back",
        "description": "Navigate back to the previous page in browser history.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

CLOSE_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_close",
        "description": "Close the browser session. Call when done with all browser tasks.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

GET_URL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "browser_get_url",
        "description": "Return the current page URL and title.",
        "parameters": {"type": "object", "properties": {}, "required": []},
    },
}

ALL_SCHEMAS = [
    NAVIGATE_SCHEMA, EXTRACT_TEXT_SCHEMA, CLICK_SCHEMA, TYPE_SCHEMA,
    SCREENSHOT_SCHEMA, SCROLL_SCHEMA, EVAL_SCHEMA, BACK_SCHEMA,
    CLOSE_SCHEMA, GET_URL_SCHEMA,
]

# ── Executors ─────────────────────────────────────────────────────────────────

def browser_navigate(args: dict) -> str:
    url     = args.get("url", "")
    timeout = args.get("timeout", 30000)
    print(f"  {c('tool', 'browser_navigate')}: {c('dim', url)}")
    try:
        page = _get_page()
        page.goto(url, timeout=timeout, wait_until="domcontentloaded")
        title   = page.title()
        cur_url = page.url
        result  = f"Navigated to: {cur_url}\nTitle: {title}"
        print(c("out", f"    {result}") + "\n")
        return result
    except Exception as e:
        msg = f"Navigation error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def browser_extract_text(args: dict) -> str:
    selector  = args.get("selector", "body")
    max_chars = args.get("max_chars", 8000)
    print(f"  {c('tool', 'browser_extract_text')}: {c('dim', selector)}")
    try:
        page = _get_page()
        el   = page.query_selector(selector)
        if not el:
            return f"No element found for selector: {selector}"
        text = el.inner_text()
        if len(text) > max_chars:
            text = text[:max_chars] + f"\n... (truncated at {max_chars} chars)"
        lines   = text.splitlines()
        preview = "\n".join(f"    {l}" for l in lines[:15])
        if len(lines) > 15:
            preview += f"\n    {c('dim', f'... ({len(lines)-15} more lines)')}"
        print(c("out", preview) + "\n")
        return text
    except Exception as e:
        msg = f"Extract error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def browser_click(args: dict) -> str:
    selector = args.get("selector", "")
    text     = args.get("text", "")
    target   = selector or f"text={text}"
    print(f"  {c('tool', 'browser_click')}: {c('dim', target)}")
    try:
        page = _get_page()
        if text and not selector:
            page.get_by_text(text, exact=False).first.click()
        else:
            page.click(selector)
        page.wait_for_load_state("domcontentloaded")
        result = f"Clicked '{target}'. Current URL: {page.url}"
        print(c("out", f"    {result}") + "\n")
        return result
    except Exception as e:
        msg = f"Click error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def browser_type(args: dict) -> str:
    selector = args.get("selector", "")
    text     = args.get("text", "")
    clear    = args.get("clear", True)
    print(f"  {c('tool', 'browser_type')}: {c('dim', f'{selector} <- {repr(text)}')}")
    try:
        page = _get_page()
        if clear:
            page.fill(selector, text)
        else:
            page.type(selector, text)
        result = f"Typed into '{selector}'"
        print(c("out", f"    {result}") + "\n")
        return result
    except Exception as e:
        msg = f"Type error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def browser_screenshot(args: dict) -> str:
    path      = args.get("path", "screenshot.png")
    full_page = args.get("full_page", False)
    print(f"  {c('tool', 'browser_screenshot')}: {c('dim', path)}")
    try:
        page = _get_page()
        page.screenshot(path=path, full_page=full_page)
        size   = os.path.getsize(path)
        result = f"Screenshot saved to {os.path.abspath(path)} ({size:,} bytes)"
        print(c("out", f"    {result}") + "\n")
        return result
    except Exception as e:
        msg = f"Screenshot error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def browser_scroll(args: dict) -> str:
    direction = args.get("direction", "down")
    pixels    = args.get("pixels", 500)
    dy        = pixels if direction == "down" else -pixels
    print(f"  {c('tool', 'browser_scroll')}: {c('dim', f'{direction} {pixels}px')}")
    try:
        page   = _get_page()
        page.evaluate(f"window.scrollBy(0, {dy})")
        result = f"Scrolled {direction} {pixels}px"
        print(c("out", f"    {result}") + "\n")
        return result
    except Exception as e:
        msg = f"Scroll error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def browser_eval(args: dict) -> str:
    script = args.get("script", "")
    print(f"  {c('tool', 'browser_eval')}: {c('dim', script[:80])}")
    try:
        page   = _get_page()
        result = str(page.evaluate(script))
        print(c("out", f"    {result[:200]}") + "\n")
        return result
    except Exception as e:
        msg = f"Eval error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def browser_back(args: dict) -> str:
    print(f"  {c('tool', 'browser_back')}")
    try:
        page = _get_page()
        page.go_back(wait_until="domcontentloaded")
        result = f"Back. Current URL: {page.url}"
        print(c("out", f"    {result}") + "\n")
        return result
    except Exception as e:
        msg = f"Back error: {e}"
        print(c("red", f"    {msg}\n"))
        return msg


def browser_close(args: dict) -> str:
    print(f"  {c('tool', 'browser_close')}")
    _close_browser()
    print(c("out", "    Browser session closed.\n"))
    return "Browser session closed."


def browser_get_url(args: dict) -> str:
    print(f"  {c('tool', 'browser_get_url')}")
    try:
        page   = _get_page()
        result = f"URL: {page.url}\nTitle: {page.title()}"
        print(c("out", f"    {result}") + "\n")
        return result
    except Exception as e:
        return f"Error: {e}"


EXECUTORS = {
    "browser_navigate":     browser_navigate,
    "browser_extract_text": browser_extract_text,
    "browser_click":        browser_click,
    "browser_type":         browser_type,
    "browser_screenshot":   browser_screenshot,
    "browser_scroll":       browser_scroll,
    "browser_eval":         browser_eval,
    "browser_back":         browser_back,
    "browser_close":        browser_close,
    "browser_get_url":      browser_get_url,
}
