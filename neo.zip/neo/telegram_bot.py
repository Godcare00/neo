#!/usr/bin/env python3
# telegram_bot.py — Telegram entry point for Neo
#
# Usage:   python telegram_bot.py
# Requires: pip install python-telegram-bot
#
# .env keys:
#   TELEGRAM_BOT_TOKEN   — from @BotFather
#   TELEGRAM_ALLOWED_IDS — comma-separated Telegram user IDs

import os
import sys
import asyncio
import logging
import re
import urllib.error

sys.path.insert(0, os.path.dirname(__file__))

from config import WORKSPACE
import conversation_store

UPLOADS_DIR     = os.path.join(WORKSPACE, "uploads")
MAX_INPUT_CHARS = 8_000   # reject messages longer than this
MAX_INPUT_MSG   = f"Message too long (max {MAX_INPUT_CHARS:,} characters). Please shorten it."

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("neo.telegram")

# ── Auth ──────────────────────────────────────────────────────────────────────

def _load_allowed_ids() -> set[int]:
    """
    Load the authorized user ID list.
    Re-reads .env on every call so adding a user takes effect immediately
    without restarting the bot.
    """
    # Re-parse .env directly so changes are picked up at runtime
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    raw_ids  = ""
    if os.path.exists(env_path):
        with open(env_path) as _ef:
            for _line in _ef:
                _line = _line.strip()
                if _line.startswith("TELEGRAM_ALLOWED_IDS") and "=" in _line:
                    raw_ids = _line.split("=", 1)[1].strip().strip('"').strip("'")
                    break
    # Fall back to environment variable if not in .env
    if not raw_ids:
        raw_ids = os.environ.get("TELEGRAM_ALLOWED_IDS", "")
    ids = set()
    for part in raw_ids.split(","):
        part = part.strip()
        if part.isdigit():
            ids.add(int(part))
    return ids

# ── File path detection ───────────────────────────────────────────────────────

_PATH_RE = re.compile(
    r"(?:^|[\s:('\"`,\[])"
    r"(/[\w./\-]+|workspace/[\w./\-]+)",
    re.MULTILINE,
)

def _extract_sendable_files(text: str) -> list[str]:
    found = []
    for m in _PATH_RE.finditer(text):
        candidate = m.group(1).rstrip(".,;:)")
        if not candidate:
            continue
        if not candidate.startswith("/"):
            candidate = os.path.join(os.path.dirname(__file__), candidate)
        candidate = os.path.abspath(candidate)
        if (os.path.isfile(candidate)
                and os.path.getsize(candidate) < 50 * 1024 * 1024
                and candidate not in found):
            found.append(candidate)
    return found

# ── Message splitting ─────────────────────────────────────────────────────────

TELEGRAM_LIMIT = 4096

def _split_message(text: str) -> list[str]:
    if len(text) <= TELEGRAM_LIMIT:
        return [text]
    chunks = []
    while text:
        if len(text) <= TELEGRAM_LIMIT:
            chunks.append(text)
            break
        split_at = text.rfind("\n", 0, TELEGRAM_LIMIT)
        if split_at == -1:
            split_at = TELEGRAM_LIMIT
        chunks.append(text[:split_at])
        text = text[split_at:].lstrip("\n")
    return chunks

def _sanitise_reply(text: str) -> str:
    """
    Strip internal markup that must never appear in user-facing Telegram messages:
      - <tool_call>...</tool_call> blocks (model reasoning leaked into content)
      - <tool_result>...</tool_result> blocks
      - Any other <...> XML-style blocks that look like internal scaffolding
    Returns the cleaned text, or a placeholder if nothing remains.
    """
    import re
    # Remove tool_call / tool_result blocks (possibly multi-line)
    text = re.sub(r'<tool_call>[\s\S]*?</tool_call>', '', text, flags=re.IGNORECASE)
    text = re.sub(r'<tool_result>[\s\S]*?</tool_result>', '', text, flags=re.IGNORECASE)
    # Remove any other self-closing or paired XML-ish tags that look internal
    text = re.sub(r'</?(?:tool_call|tool_result|function_call|function_response)\b[^>]*>', '', text, flags=re.IGNORECASE)
    text = text.strip()
    return text or '(no text response)'


# ── Bot ───────────────────────────────────────────────────────────────────────

class NeoBot:
    def __init__(self):
        from main import build_team, init_workspace, initial_snapshot, init_task_pool

        api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
        if not api_key:
            log.error("OPENROUTER_API_KEY not set.")
            sys.exit(1)

        self.token       = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
        self.allowed_ids = _load_allowed_ids()

        if not self.token:
            log.error("TELEGRAM_BOT_TOKEN not set.")
            sys.exit(1)
        if not self.allowed_ids:
            log.warning("TELEGRAM_ALLOWED_IDS not set — no one can message Neo!")

        log.info(f"Authorized users: {self.allowed_ids}")

        init_workspace()
        os.makedirs(UPLOADS_DIR, exist_ok=True)

        self.neo       = build_team(api_key)
        self._api_key  = api_key
        self._app      = None   # set in run()

        initial_snapshot(self.neo)

        # _polling_loop is set via post_init (runs inside the polling event loop)
        # so run_coroutine_threadsafe always targets the correct loop.
        self._polling_loop: asyncio.AbstractEventLoop | None = None

        def on_task_done(task):
            """Push task completion to all authorized users."""
            if not self._app or not self._polling_loop:
                return
            icon   = "✅" if task.status.value == "done" else "❌"
            status = task.status.value.upper()
            text   = (
                f"{icon} *Task {task.id}* — {status}\n"
                f"Agent: {task.assigned_agent}\n"
                f"Task: {task.description[:120]}\n\n"
                f"Use /task\\_result {task.id} for full output."
            )

            # Build a summary to inject into Neo's conversation history
            # so he is aware of what was accomplished.
            summary = (
                f"[BACKGROUND TASK COMPLETED]\n"
                f"Task ID:  {task.id}\n"
                f"Agent:    {task.assigned_agent}\n"
                f"Status:   {status}\n"
                f"Task:     {task.description[:200]}\n"
                + (f"Result preview:\n{(task.result or '')[:600]}"
                   if task.result else f"Error: {task.error or 'unknown'}")
            )

            async def _push():
                for uid in self.allowed_ids:
                    try:
                        await self._app.bot.send_message(
                            chat_id=uid, text=text, parse_mode="Markdown"
                        )
                    except Exception as e:
                        log.warning(f"Could not notify {uid}: {e}")
                    # Inject into this user's conversation history so Neo
                    # knows about the completed task in future replies.
                    try:
                        msgs = conversation_store.load(str(uid), self.neo.system_prompt)
                        msgs.append({"role": "assistant", "content": summary})
                        conversation_store.save(str(uid), msgs)
                    except Exception as e:
                        log.warning(f"Could not inject task result into history for {uid}: {e}")

            asyncio.run_coroutine_threadsafe(_push(), self._polling_loop)

        init_task_pool(self.neo, notify_fn=on_task_done, api_key=api_key)

        # Per-user sent-file dedup sets and conversation locks
        self._sent_files: dict[int, set]                   = {}
        self._user_locks: dict[int, asyncio.Lock]          = {}

    def _get_user_lock(self, user_id: int) -> asyncio.Lock:
        """Return the per-user asyncio Lock, creating it if needed."""
        if user_id not in self._user_locks:
            self._user_locks[user_id] = asyncio.Lock()
        return self._user_locks[user_id]

    # ── Conversation state (persisted) ────────────────────────────────────────

    def _get_history(self, user_id: int) -> list[dict]:
        uid = str(user_id)
        return conversation_store.load(uid, self.neo.system_prompt)

    def _save_history(self, user_id: int, messages: list[dict]):
        conversation_store.save(str(user_id), messages)

    def _reset_history(self, user_id: int) -> list[dict]:
        self._sent_files.pop(user_id, None)
        return conversation_store.clear(str(user_id), self.neo.system_prompt)

    def _rollback(self, messages: list[dict]):
        while messages and messages[-1].get("role") != "user":
            messages.pop()
        if messages:
            messages.pop()

    # ── Neo reply ─────────────────────────────────────────────────────────────

    async def _neo_reply(self, messages: list[dict]) -> str:
        """
        Call Neo and return his reply.
        Appends the assistant message to `messages` on success.
        Rolls back the user message on failure so history stays clean.
        The caller is responsible for appending the user message BEFORE calling.
        """
        loop = asyncio.get_running_loop()
        try:
            reply = await loop.run_in_executor(None, self.neo.chat, messages)
            messages.append({"role": "assistant", "content": reply})
            return reply
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            self._rollback(messages)   # removes the dangling user message
            return f"API error {e.code}: {body}"
        except Exception as e:
            self._rollback(messages)
            return f"Error: {e}"

    async def _send_reply(self, update, context, reply: str,
                          already_sent: set = None):
        chat_id = update.effective_chat.id
        reply   = _sanitise_reply(reply)   # strip leaked tool_call blocks
        for chunk in _split_message(reply):
            await update.message.reply_text(chunk)
        for fpath in _extract_sendable_files(reply):
            if already_sent is not None:
                if fpath in already_sent:
                    continue
                already_sent.add(fpath)
            try:
                loop      = asyncio.get_running_loop()
                file_bytes = await loop.run_in_executor(
                    None, lambda p=fpath: open(p, "rb").read()
                )
                await context.bot.send_document(
                    chat_id=chat_id,
                    document=file_bytes,
                    filename=os.path.basename(fpath),
                    caption=f"📎 {os.path.basename(fpath)}",
                )
                log.info(f"Sent file: {fpath}")
            except Exception as e:
                log.warning(f"Could not send file {fpath}: {e}")

    # ── Handlers ──────────────────────────────────────────────────────────────

    async def on_message(self, update, context):
        from telegram.constants import ChatAction
        user = update.effective_user
        self.allowed_ids = _load_allowed_ids()  # reload in case .env changed
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        text = (update.message.text or "").strip()
        if not text:
            return
        if len(text) > MAX_INPUT_CHARS:
            await update.message.reply_text(MAX_INPUT_MSG)
            return
        log.info(f"[{user.id}] {text[:80]}")
        await context.bot.send_chat_action(
            chat_id=update.effective_chat.id, action=ChatAction.TYPING
        )
        # Load history under lock, but release BEFORE the blocking LLM call
        # so Neo can still reply to new messages while a task is running.
        async with self._get_user_lock(user.id):
            messages = self._get_history(user.id)
            messages.append({"role": "user", "content": text})
        # LLM call happens outside the lock
        reply = await self._neo_reply(messages)
        # Re-acquire to save the updated history
        async with self._get_user_lock(user.id):
            self._save_history(user.id, messages)
            sent = self._sent_files.setdefault(user.id, set())
        await self._send_reply(update, context, reply, already_sent=sent)

    async def on_attachment(self, update, context):
        from telegram.constants import ChatAction
        user = update.effective_user
        msg  = update.message
        if user.id not in self.allowed_ids:
            await msg.reply_text("Unauthorized.")
            return
        await context.bot.send_chat_action(
            chat_id=update.effective_chat.id, action=ChatAction.TYPING
        )
        tg_file = None
        label   = "file"
        caption = (msg.caption or "").strip()
        if msg.document:
            tg_file = await msg.document.get_file()
            label   = msg.document.file_name or "document"
        elif msg.photo:
            tg_file = await msg.photo[-1].get_file()
            label   = "photo.jpg"
        elif msg.audio:
            tg_file = await msg.audio.get_file()
            label   = msg.audio.file_name or "audio"
        elif msg.video:
            tg_file = await msg.video.get_file()
            label   = msg.video.file_name or "video"
        elif msg.voice:
            tg_file = await msg.voice.get_file()
            label   = "voice.ogg"
        else:
            await msg.reply_text("Unsupported attachment type.")
            return

        # Sanitise filename — strip path separators to prevent traversal attacks.
        # A crafted filename like "../../etc/passwd" becomes "passwd".
        label = os.path.basename(label.replace("\\", "/")) or "file"
        # Strip leading dots so files can't be hidden or overwrite dotfiles
        label = label.lstrip(".") or "file"

        user_upload_dir = os.path.join(UPLOADS_DIR, str(user.id))
        os.makedirs(user_upload_dir, exist_ok=True)
        dest = os.path.join(user_upload_dir, label)
        # Verify resolved path is inside the upload directory
        if not os.path.abspath(dest).startswith(os.path.abspath(user_upload_dir)):
            await msg.reply_text("Invalid filename.")
            return
        if os.path.exists(dest):
            base, ext = os.path.splitext(label)
            i = 1
            while os.path.exists(dest):
                dest = os.path.join(user_upload_dir, f"{base}_{i}{ext}")
                i += 1
        await tg_file.download_to_drive(dest)
        log.info(f"[{user.id}] saved attachment -> {dest}")

        user_content = (
            f"I just sent you a file saved at: {dest}\n"
            + (f"Caption: {caption}" if caption else "Please process or acknowledge it.")
        )
        async with self._get_user_lock(user.id):
            messages = self._get_history(user.id)
            messages.append({"role": "user", "content": user_content})
        reply = await self._neo_reply(messages)
        async with self._get_user_lock(user.id):
            self._save_history(user.id, messages)
            sent = self._sent_files.setdefault(user.id, set())
        await self._send_reply(update, context, reply, already_sent=sent)

    async def on_start(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        await update.message.reply_text(
            "Neo online.\n\n"
            "/reset       — clear conversation history\n"
            "/status      — system + task pool status\n"
            "/tasks        — list recent tasks\n"
            "/task_result <id> — get full task output\n"
            "/clear_log   — clear tool call log"
        )

    async def on_reset(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        self._reset_history(user.id)
        await update.message.reply_text("Conversation reset.")

    async def on_status(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        from archive import archive
        from task_pool import task_pool
        arch  = archive.status()
        pool  = task_pool.status_summary()
        busy  = ", ".join(sorted(task_pool._busy)) or "none"
        turns = len(self._get_history(user.id))
        text  = (
            f"*Neo Status*\n```\n{arch}\n\n"
            f"Task pool: {pool}\nBusy agents: {busy}\n"
            f"Conversation turns: {turns}\n```"
        )
        await update.message.reply_text(text, parse_mode="Markdown")

    async def on_tasks(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        from task_pool import task_pool
        tasks = task_pool.list_tasks(last_n=10)
        if not tasks:
            await update.message.reply_text("No tasks yet.")
            return
        icons = {"pending":"⏳","assigning":"🤔","running":"⚙️",
                 "paused":"⏸","done":"✅","failed":"❌","cancelled":"⊘"}
        lines = [
            f"{icons.get(t.status.value,'?')} `{t.id}` {t.status.value}"
            f" — {t.description[:60]}"
            for t in tasks
        ]
        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")

    async def on_task_result(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        if not context.args:
            await update.message.reply_text("Usage: /task_result <task_id>")
            return
        task_id = context.args[0].strip()
        from task_pool import task_pool
        task = task_pool.get(task_id)
        if not task:
            await update.message.reply_text(f"Task '{task_id}' not found.")
            return
        formatted = task_pool.format_task(task, full=True)
        for chunk in _split_message(formatted):
            await update.message.reply_text(chunk)
        # Also send any files mentioned in the result
        if task.result:
            sent = self._sent_files.setdefault(user.id, set())
            for fpath in _extract_sendable_files(task.result):
                if fpath in sent:
                    continue
                sent.add(fpath)
                try:
                    loop = asyncio.get_running_loop()
                    file_bytes = await loop.run_in_executor(
                        None, lambda p=fpath: open(p, "rb").read()
                    )
                    await context.bot.send_document(
                        chat_id=update.effective_chat.id,
                        document=file_bytes,
                        filename=os.path.basename(fpath),
                        caption=f"📎 {os.path.basename(fpath)}",
                    )
                except Exception as e:
                    log.warning(f"Could not send task result file {fpath}: {e}")

    async def on_clear_log(self, update, context):
        user = update.effective_user
        if user.id not in self.allowed_ids:
            await update.message.reply_text("Unauthorized.")
            return
        from tool_log import LOG_FILE
        try:
            if os.path.exists(LOG_FILE):
                os.remove(LOG_FILE)
            await update.message.reply_text("Tool call log cleared.")
        except Exception as e:
            await update.message.reply_text(f"Error: {e}")

    # ── Run ───────────────────────────────────────────────────────────────────

    async def _post_init(self, app):
        """Called by python-telegram-bot after the polling loop starts.
        Captures the running event loop so cross-thread callbacks work."""
        self._polling_loop = asyncio.get_running_loop()

    def run(self):
        try:
            from telegram.ext import (
                ApplicationBuilder, CommandHandler, MessageHandler, filters,
            )
        except ImportError:
            log.error("python-telegram-bot not installed. Run: pip install python-telegram-bot")
            sys.exit(1)

        self._app = (ApplicationBuilder()
                     .token(self.token)
                     .post_init(self._post_init)
                     .build())

        self._app.add_handler(CommandHandler("start",       self.on_start))
        self._app.add_handler(CommandHandler("reset",       self.on_reset))
        self._app.add_handler(CommandHandler("status",      self.on_status))
        self._app.add_handler(CommandHandler("tasks",       self.on_tasks))
        self._app.add_handler(CommandHandler("task_result", self.on_task_result))
        self._app.add_handler(CommandHandler("clear_log",   self.on_clear_log))
        self._app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND, self.on_message
        ))
        self._app.add_handler(MessageHandler(
            filters.Document.ALL | filters.PHOTO | filters.AUDIO |
            filters.VIDEO | filters.VOICE,
            self.on_attachment,
        ))

        log.info("Neo Telegram bot starting (long-polling)...")
        self._app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    NeoBot().run()
