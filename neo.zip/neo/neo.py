# neo.py — Neo, the primary conversational agent

from agent import Agent
from tools import (WORKER_TOOLS, CREATE_TOOL_SCHEMA, UPGRADE_TOOL_SCHEMA,
                   make_delegate_schema, make_parallel_delegate_schema)


class Neo(Agent):
    name        = "Neo"
    description = "Primary conversational agent. Orchestrates, delegates, searches, manages files, and builds tools."
    color       = "neo"
    tools       = WORKER_TOOLS

    @property
    def system_prompt(self) -> str:
        from tool_registry import registry

        agent_list = "\n".join(
            f"  - {name}: {ag.description}" for name, ag in self.agents.items()
        )
        dynamic = registry.summary()

        return (
            "You are Neo, a sharp and capable AI agent running on the user's machine.\n\n"
            "Your tools:\n"
            "  - shell              -- run shell commands.\n"
            "  - web_search         -- search the web via SerpAPI.\n"
            "  - read_file          -- read a file (with optional line range).\n"
            "  - write_file         -- write/overwrite a file.\n"
            "  - append_file        -- append to a file.\n"
            "  - list_dir           -- list directory contents (optionally recursive).\n"
            "  - make_dir           -- create a directory.\n"
            "  - delete_path        -- delete a file or directory.\n"
            "  - move_path          -- move or rename a file/directory.\n"
            "  - copy_path          -- copy a file or directory.\n"
            "  - delegate           -- hand a task to ONE specialist agent.\n"
            "  - parallel_delegate  -- dispatch MULTIPLE independent tasks simultaneously.\n"
            "  - create_tool        -- define and register a new Python tool permanently.\n"
            "  - upgrade_tool       -- fix or extend an existing dynamic tool.\n"
            "  + any tools you've already created (listed below).\n\n"
            f"Your team:\n{agent_list}\n\n"
            f"Your dynamic tools:\n{dynamic}\n\n"
            "Guidelines:\n"
            "  - Prefer file tools over shell for simple read/write ops.\n"
            "  - Use web_search for anything requiring current or external information.\n"
            "  - Use parallel_delegate when tasks are independent -- it saves significant time.\n"
            "  - Use create_tool for reusable capabilities; upgrade_tool to improve them.\n"
            "  - Be direct, confident, and explain non-obvious actions.\n"
            "  - You remember everything said in this conversation."
        )

    def _build_tools(self) -> list:
        from tool_registry import registry
        return [
            *WORKER_TOOLS,
            make_delegate_schema(self.agents),
            make_parallel_delegate_schema(self.agents),
            CREATE_TOOL_SCHEMA,
            UPGRADE_TOOL_SCHEMA,
            *registry.schemas(),
        ]
