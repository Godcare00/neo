# tools/delegate.py — serial and parallel agent delegation

from concurrent.futures import ThreadPoolExecutor, as_completed
from config import c


def make_delegate_schema(agents: dict) -> dict:
    descriptions = "\n".join(f"- {n}: {a.description}" for n, a in agents.items())
    return {
        "type": "function",
        "function": {
            "name": "delegate",
            "description": (
                "Assign a task to ONE specialist sub-agent (serial). "
                "For multiple independent tasks, use parallel_delegate.\n"
                f"Available agents:\n{descriptions}"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "agent": {
                        "type": "string",
                        "enum": list(agents.keys()),
                        "description": "Agent to delegate to.",
                    },
                    "task": {"type": "string", "description": "Task to hand off."},
                },
                "required": ["agent", "task"],
            },
        },
    }


def make_parallel_delegate_schema(agents: dict) -> dict:
    descriptions = "\n".join(f"- {n}: {a.description}" for n, a in agents.items())
    return {
        "type": "function",
        "function": {
            "name": "parallel_delegate",
            "description": (
                "Dispatch multiple independent tasks to different agents simultaneously. "
                "All run in parallel; results returned together. "
                "Do NOT use when one task depends on another's result.\n"
                f"Available agents:\n{descriptions}"
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "tasks": {
                        "type": "array",
                        "description": "List of {agent, task} pairs to run in parallel.",
                        "items": {
                            "type": "object",
                            "properties": {
                                "agent": {
                                    "type": "string",
                                    "enum": list(agents.keys()),
                                },
                                "task": {"type": "string"},
                            },
                            "required": ["agent", "task"],
                        },
                        "minItems": 2,
                    },
                },
                "required": ["tasks"],
            },
        },
    }


def run_delegate(args: dict, agents: dict) -> str:
    agent_name = args.get("agent", "")
    task       = args.get("task", "")
    agent      = agents.get(agent_name)
    if not agent:
        return f"Unknown agent: {agent_name}"
    print(f"  {c('tool', 'delegate')} -> {c(agent_name.lower(), agent_name)}: {c('dim', task)}\n")
    return agent.run(task)


def run_parallel_delegate(args: dict, agents: dict) -> str:
    tasks = args.get("tasks", [])
    if not tasks:
        return "parallel_delegate: no tasks provided."

    print(f"  {c('tool', 'parallel_delegate')}: dispatching {len(tasks)} tasks\n")
    for t in tasks:
        print(f"    {c('dim', '->')} {c(t['agent'].lower(), t['agent'])}: {c('dim', t['task'])}")
    print()

    results, errors = {}, {}

    def run_one(agent_name, task):
        agent = agents.get(agent_name)
        if not agent:
            return agent_name, None, f"Unknown agent: {agent_name}"
        try:
            return agent_name, agent.run(task), None
        except Exception as e:
            return agent_name, None, str(e)

    with ThreadPoolExecutor(max_workers=len(tasks)) as pool:
        futures = {pool.submit(run_one, t["agent"], t["task"]): t for t in tasks}
        for future in as_completed(futures):
            name, result, error = future.result()
            if error:
                errors[name] = error
            else:
                results[name] = result

    lines = []
    for t in tasks:
        name = t["agent"]
        lines.append(f"=== {name} ===")
        lines.append(results[name] if name in results else f"[ERROR] {errors.get(name, 'unknown')}")
        lines.append("")

    print(c("dim", f"  parallel_delegate complete: {len(results)} succeeded, {len(errors)} failed\n"))
    return "\n".join(lines).strip()
