# pipeline.py — DAG-based multi-agent pipeline
#
# A Pipeline is a directed acyclic graph of PipelineStages.
# Each stage declares which prior stages it depends on. The engine
# executes stages in dependency order, passes results from upstream
# stages into downstream stage briefs, and runs independent stages
# concurrently.
#
# Flow:
#   1. Neo defines stages via task_submit_pipeline
#   2. Engine resolves execution order from the DAG
#   3. Stages with no unmet dependencies run immediately (in parallel)
#   4. As each stage finishes, its result is stored and downstream
#      stages whose dependencies are now all met are dispatched
#   5. Final summary of all stage results returned when DAG is complete

import os
import re
import json
import uuid
import threading
import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from config import c, WORKSPACE, API_URL, MODEL

MAX_PIPELINE_STAGES  = 12
MAX_STAGE_WORKERS    = 8
STAGE_TIMEOUT        = 300  # max seconds a single pipeline stage may run


def _now() -> str:
    return datetime.datetime.now().isoformat(timespec="seconds")


# ── Stage ─────────────────────────────────────────────────────────────────────

class PipelineStage:
    """One node in the pipeline DAG."""

    def __init__(self, name: str, description: str,
                 agent: str, depends_on: list[str] = None):
        self.name        = name          # unique within the pipeline
        self.description = description   # what this stage does
        self.agent       = agent         # which agent runs it
        self.depends_on  = depends_on or []  # names of stages that must finish first
        self.status      = "pending"     # pending | running | done | failed
        self.result      = None
        self.error       = None
        self.started_at  = None
        self.finished_at = None
        self.brief       = None          # final brief sent to agent

    def to_dict(self) -> dict:
        return {
            "name":        self.name,
            "description": self.description,
            "agent":       self.agent,
            "depends_on":  self.depends_on,
            "status":      self.status,
            "result":      (self.result or "")[:500],
            "error":       self.error,
            "started_at":  self.started_at,
            "finished_at": self.finished_at,
        }


# ── DAG validation ────────────────────────────────────────────────────────────

def _validate_dag(stages: list[PipelineStage]) -> None:
    """Raise ValueError if the dependency graph has cycles or unknown refs."""
    names = {s.name for s in stages}
    for s in stages:
        for dep in s.depends_on:
            if dep not in names:
                raise ValueError(
                    f"Stage '{s.name}' depends on unknown stage '{dep}'"
                )
    # Cycle detection via DFS
    visiting, visited = set(), set()

    def dfs(name):
        if name in visiting:
            raise ValueError(f"Cycle detected involving stage '{name}'")
        if name in visited:
            return
        visiting.add(name)
        stage = next(s for s in stages if s.name == name)
        for dep in stage.depends_on:
            dfs(dep)
        visiting.remove(name)
        visited.add(name)

    for s in stages:
        dfs(s.name)


# ── Brief builder ─────────────────────────────────────────────────────────────

def _build_stage_brief(stage: PipelineStage, goal: str,
                        upstream_results: dict[str, str],
                        file_refs: list[str]) -> str:
    """Build a complete brief for a stage, injecting upstream results."""
    lines = [
        f"=== PIPELINE STAGE BRIEF ===",
        f"",
        f"Pipeline goal: {goal}",
        f"Your stage:    {stage.name}",
        f"Your task:     {stage.description}",
        f"",
        f"WORKSPACE: {WORKSPACE}",
        f"  Save all outputs here.",
        f"",
    ]

    if upstream_results:
        lines += ["UPSTREAM RESULTS (from stages you depend on):"]
        for dep_name in stage.depends_on:
            res = upstream_results.get(dep_name, "(no result)")
            lines += [f"  --- {dep_name} ---", f"  {res[:800]}", ""]
        lines.append("")

    if file_refs:
        lines += ["INPUT FILES (confirmed on disk):"]
        for fp in file_refs:
            if os.path.isfile(fp):
                lines.append(f"  - {fp}  ({os.path.getsize(fp):,} bytes)")
        lines += [
            "",
            "Use read_file to read them — do NOT guess their contents.",
            "",
        ]

    lines += [
        "OUTPUT INSTRUCTIONS:",
        "  - Complete your stage fully.",
        "  - If you produce files, state their exact paths.",
        "  - End with: STAGE RESULT: <one paragraph summary of what you produced>",
        "",
        "=== END BRIEF ===",
    ]
    return "\n".join(lines)


# ── Pipeline runner ───────────────────────────────────────────────────────────

def run_pipeline(pipeline_id: str, goal: str,
                 stages_def: list[dict],
                 agents_roster: dict,
                 api_key: str,
                 file_refs: list[str] = None) -> str:
    """
    Execute a pipeline DAG. Returns a final summary of all stage results.

    stages_def: list of {name, description, agent, depends_on?}
    """
    file_refs = file_refs or []

    # Build stage objects
    stages = []
    for d in stages_def[:MAX_PIPELINE_STAGES]:
        stages.append(PipelineStage(
            name        = d["name"],
            description = d["description"],
            agent       = d["agent"],
            depends_on  = d.get("depends_on", []),
        ))

    # Validate DAG
    _validate_dag(stages)

    by_name   = {s.name: s for s in stages}
    results   = {}          # name -> result string
    lock      = threading.Lock()
    executor  = ThreadPoolExecutor(max_workers=MAX_STAGE_WORKERS)

    print(c("dim", f"  pipeline [{pipeline_id}]: {len(stages)} stages, goal: {goal[:60]}\n"))

    def stage_is_ready(s: PipelineStage) -> bool:
        return (s.status == "pending"
                and all(by_name[d].status == "done" for d in s.depends_on))

    def run_stage(stage: PipelineStage):
        with lock:
            stage.status     = "running"
            stage.started_at = _now()

        agent = agents_roster.get(stage.agent)
        if not agent:
            with lock:
                stage.status      = "failed"
                stage.error       = f"Agent '{stage.agent}' not in roster"
                stage.finished_at = _now()
            print(c("red", f"  pipeline [{pipeline_id}]: stage '{stage.name}' — "
                            f"unknown agent '{stage.agent}'\n"))
            return

        with lock:
            upstream = {d: results.get(d, "") for d in stage.depends_on}

        brief = _build_stage_brief(stage, goal, upstream, file_refs)
        stage.brief = brief

        print(f"  {c('tool', 'pipeline')} [{pipeline_id}] "
              f"{c('dim', stage.name)} -> {c(stage.agent.lower(), stage.agent)}: "
              f"{c('dim', stage.description[:50])}\n")

        import concurrent.futures as _cf
        try:
            with _cf.ThreadPoolExecutor(max_workers=1) as _ex:
                fut = _ex.submit(agent.run, brief)
                try:
                    result = fut.result(timeout=STAGE_TIMEOUT)
                except _cf.TimeoutError:
                    result = f"[TIMEOUT] Stage '{stage.name}' exceeded {STAGE_TIMEOUT}s."
                    print(c("red", f"  pipeline [{pipeline_id}]: stage '{stage.name}' timed out\n"))
            with lock:
                stage.status      = "done"
                stage.result      = result
                stage.finished_at = _now()
                results[stage.name] = result
            print(c("dim", f"  pipeline [{pipeline_id}]: stage '{stage.name}' done\n"))
        except Exception as e:
            with lock:
                stage.status      = "failed"
                stage.error       = str(e)
                stage.finished_at = _now()
                results[stage.name] = f"[FAILED] {e}"
            print(c("red", f"  pipeline [{pipeline_id}]: stage '{stage.name}' "
                            f"failed — {e}\n"))

    # Dispatch loop: keep dispatching ready stages until nothing left
    futures = {}
    while True:
        with lock:
            ready = [s for s in stages if stage_is_ready(s)]
            failed = [s for s in stages if s.status == "failed"]
            done   = [s for s in stages if s.status == "done"]

        # Fail entire pipeline if any non-leaf failure blocks a downstream stage
        for s in stages:
            if s.status == "pending":
                for dep in s.depends_on:
                    if by_name[dep].status == "failed":
                        with lock:
                            s.status = "failed"
                            s.error  = f"Upstream stage '{dep}' failed"

        with lock:
            ready = [s for s in stages if stage_is_ready(s)]

        if not ready:
            # Check if we're done (all stages terminal)
            with lock:
                terminal = all(s.status in ("done", "failed") for s in stages)
            if terminal:
                break
            # Wait for in-flight futures
            if futures:
                from concurrent.futures import wait as _wait
                done_futures, _ = _wait(list(futures.keys()), timeout=1)
                for f in done_futures:
                    futures.pop(f, None)
            continue

        for stage in ready:
            with lock:
                stage.status = "running"  # pre-mark to avoid double-dispatch
            try:
                f = executor.submit(run_stage, stage)
                futures[f] = stage
            except Exception as e:
                # Executor rejected (e.g. shutdown) — mark stage failed
                with lock:
                    stage.status = "failed"
                    stage.error  = f"Dispatch failed: {e}"
                    stage.finished_at = _now()

    executor.shutdown(wait=True)

    # Build summary
    summary_lines = [f"Pipeline [{pipeline_id}] complete.", f"Goal: {goal}", ""]
    for s in stages:
        icon = "✓" if s.status == "done" else "✗"
        summary_lines.append(f"{icon} {s.name} ({s.agent}): {s.status}")
        if s.result:
            summary_lines.append(f"   {s.result[:300]}")
        elif s.error:
            summary_lines.append(f"   ERROR: {s.error}")
        summary_lines.append("")

    return "\n".join(summary_lines)
