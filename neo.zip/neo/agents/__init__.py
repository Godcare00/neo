from agents.morpheus  import Morpheus
from agents.alpha     import Alpha
from agents.beta      import Beta
from agents.cipher    import Cipher
from agents.architect import Architect
from agents.ghost     import Ghost
from agents.archivist import Archivist

__all__ = ["Morpheus", "Alpha", "Beta", "Cipher", "Architect", "Ghost", "Browser", "Archivist"]


def __getattr__(name: str):
    """Lazy-load Browser so missing Playwright doesn't break the whole package."""
    if name == "Browser":
        from agents.browser import Browser
        return Browser
    raise AttributeError(f"module 'agents' has no attribute {name!r}")
