# tools/__init__.py — unified tool export and executor
#
# All tool schemas are imported here for use in agent _build_tools().
# execute_tool() is the single dispatch point for all tool calls.

from tools.shell     import SCHEMA         as SHELL_SCHEMA
from tools.files     import (READ_FILE_SCHEMA, WRITE_FILE_SCHEMA, APPEND_FILE_SCHEMA)
from tools.directory import (LIST_DIR_SCHEMA, MAKE_DIR_SCHEMA, DELETE_PATH_SCHEMA,
                             MOVE_PATH_SCHEMA, COPY_PATH_SCHEMA)
from tools.search    import SCHEMA         as WEB_SEARCH_SCHEMA
from tools.meta      import CREATE_TOOL_SCHEMA, UPGRADE_TOOL_SCHEMA
from tools.delegate  import (make_delegate_schema, make_parallel_delegate_schema,
                             run_delegate, run_parallel_delegate)

# Convenience bundle: tools every sub-agent gets
WORKER_TOOLS = [
    SHELL_SCHEMA,
    READ_FILE_SCHEMA,
    WRITE_FILE_SCHEMA,
    APPEND_FILE_SCHEMA,
    LIST_DIR_SCHEMA,
    MAKE_DIR_SCHEMA,
    DELETE_PATH_SCHEMA,
    MOVE_PATH_SCHEMA,
    COPY_PATH_SCHEMA,
    WEB_SEARCH_SCHEMA,
]


def execute_tool(name: str, args: dict, agents: dict) -> str:
    """Single dispatch point for all tool calls."""
    from tool_registry import registry
    import tools.shell     as _shell
    import tools.files     as _files
    import tools.directory as _dir
    import tools.search    as _search

    # Shell
    if name == "shell":
        return _shell.execute(args)

    # Files
    if name == "read_file":
        return _files.read_file(args)
    if name == "write_file":
        return _files.write_file(args)
    if name == "append_file":
        return _files.append_file(args)

    # Directory
    if name == "list_dir":
        return _dir.list_dir(args)
    if name == "make_dir":
        return _dir.make_dir(args)
    if name == "delete_path":
        return _dir.delete_path(args)
    if name == "move_path":
        return _dir.move_path(args)
    if name == "copy_path":
        return _dir.copy_path(args)

    # Web search
    if name == "web_search":
        return _search.execute(args)

    # Delegation
    if name == "delegate":
        return run_delegate(args, agents)
    if name == "parallel_delegate":
        return run_parallel_delegate(args, agents)

    # Meta tools
    if name == "create_tool":
        try:
            return registry.create(
                name        = args["name"],
                description = args["description"],
                parameters  = args["parameters"],
                code        = args["code"],
            )
        except Exception as e:
            return f"create_tool failed: {e}"

    if name == "upgrade_tool":
        try:
            return registry.upgrade(
                name        = args["name"],
                description = args.get("description"),
                parameters  = args.get("parameters"),
                code        = args.get("code"),
            )
        except Exception as e:
            return f"upgrade_tool failed: {e}"

    # Dynamic registry
    if name in registry.names():
        return registry.execute(name, args)

    return f"Unknown tool: {name}"
