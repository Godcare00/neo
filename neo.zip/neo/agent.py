# agent.py — base Agent class all agents inherit from

import json
import collections
import urllib.request
from config import API_URL, MODEL, c
from tools import execute_tool

# Maximum tool calls allowed in a single agent turn.
# Prevents runaway loops where the agent retries the same failing command forever.
MAX_TOOL_CALLS_PER_TURN = 40

# If the same (tool, args, result) triple repeats this many times consecutively,
# the loop is considered stuck and aborted with a clear error message.
MAX_IDENTICAL_REPEATS = 3


class Agent:
    """
    A self-contained LLM agent with its own identity, system prompt,
    tools, and agentic loop. Can be used standalone or as a sub-agent.
    """

    name:        str  = "Agent"
    description: str  = "A general-purpose agent."
    color:       str  = "dim"
    tools:       list = []

    def __init__(self, api_key: str, agents: dict = None):
        self.api_key = api_key
        self.agents  = agents or {}

    @property
    def system_prompt(self) -> str:
        raise NotImplementedError

    def _call_api(self, messages: list, tools: list) -> dict:
        payload = json.dumps({
            "model":       MODEL,
            "messages":    messages,
            "tools":       tools or [],
            "tool_choice": "auto" if tools else "none",
        }).encode("utf-8")

        req = urllib.request.Request(
            API_URL,
            data=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type":  "application/json",
                "HTTP-Referer":  "https://github.com/neo-agent",
                "X-Title":       f"Neo - {self.name}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data["choices"][0]["message"]

    def _build_tools(self) -> list:
        return list(self.tools)

    def _run_loop(self, messages: list) -> str:
        tool_call_count = 0

        # Tracks (tool_name, args_json, result) for consecutive-repeat detection.
        # Using a deque so we only keep the last N entries cheaply.
        recent = collections.deque(maxlen=MAX_IDENTICAL_REPEATS)

        while True:
            tools = self._build_tools()
            print(c("dim", "  ..."), end="\r", flush=True)
            msg = self._call_api(messages, tools)
            print("      ", end="\r")

            if not msg.get("tool_calls"):
                return (msg.get("content") or "").strip()

            messages.append(msg)

            for tc in msg["tool_calls"]:
                # ── Hard cap ──────────────────────────────────────────────────
                tool_call_count += 1
                if tool_call_count > MAX_TOOL_CALLS_PER_TURN:
                    cap_msg = (
                        f"[LOOP GUARD] Stopped after {MAX_TOOL_CALLS_PER_TURN} tool calls "
                        f"in one turn. Last tool: {tc['function']['name']}. "
                        f"The task may require a different approach."
                    )
                    print(c("red", f"  {cap_msg}\n"))
                    messages.append({
                        "role":         "tool",
                        "tool_call_id": tc["id"],
                        "name":         tc["function"]["name"],
                        "content":      cap_msg,
                    })
                    # Force the model to respond with text by removing all tools
                    bail_msg = self._call_api(messages, tools=[])
                    return (bail_msg.get("content") or cap_msg).strip()

                fn     = tc["function"]["name"]
                args   = json.loads(tc["function"]["arguments"] or "{}")
                result = execute_tool(fn, args, self.agents)

                # ── Identical-repeat detection ────────────────────────────────
                fingerprint = (fn, json.dumps(args, sort_keys=True), result)
                recent.append(fingerprint)

                if (len(recent) == MAX_IDENTICAL_REPEATS
                        and len(set(recent)) == 1):
                    stuck_msg = (
                        f"[LOOP GUARD] Tool '{fn}' returned the same result "
                        f"{MAX_IDENTICAL_REPEATS} times in a row: "
                        f"{result[:200]!r}. Stopping retry loop — "
                        f"the approach is not working. Try something different."
                    )
                    print(c("red", f"  {stuck_msg}\n"))
                    messages.append({
                        "role":         "tool",
                        "tool_call_id": tc["id"],
                        "name":         fn,
                        "content":      stuck_msg,
                    })
                    bail_msg = self._call_api(messages, tools=[])
                    return (bail_msg.get("content") or stuck_msg).strip()

                messages.append({
                    "role":         "tool",
                    "tool_call_id": tc["id"],
                    "name":         fn,
                    "content":      result,
                })

    def run(self, task: str) -> str:
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user",   "content": task},
        ]
        return self._run_loop(messages)

    def chat(self, messages: list) -> str:
        return self._run_loop(messages)
